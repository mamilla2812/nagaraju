﻿Function PromptUser(){
    $UserPrompt = DrawMessageBox "GLIDE" "Pulse Check" "All"
    $GlidePath="$PSScriptRoot\GLIDE\Code\GLIDE_Setup.ps1"
    $PulsePath="$PSScriptRoot\GLIDE_Pulse_Check\GLIDE_PulseInstall.ps1"

    Switch ($UserPrompt){
        "Yes" {
            &$GlidePath
        }
        "No" {
            &$PulsePath
        }
        "OK"{
            &$GlidePath
            &$PulsePath
        }
        "Cancel"{
             write-host "CANCEL" -BackgroundColor Red
        }

    }
}

Function DrawMessageBox($ButtonText1,$ButtonText2,$ButtonText3){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "GLIDE Automatic Installation"
    $objForm.Size = New-Object System.Drawing.Size(400,200) 
    $objForm.StartPosition = "CenterScreen"

    $objForm.KeyPreview = $True
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        {$objForm.Close()}})
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {$objForm.Close()}})

    $Button1 = New-Object System.Windows.Forms.Button
    $Button1.Location = New-Object System.Drawing.Size(50,100)
    $Button1.Size = New-Object System.Drawing.Size(90,30)
    $Button1.Text = $ButtonText1
    $Button1.DialogResult = "Yes"
    $Button1.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button1)

    $Button2 = New-Object System.Windows.Forms.Button
    $Button2.Location = New-Object System.Drawing.Size(150,100)
    $Button2.Size = New-Object System.Drawing.Size(90,30)
    $Button2.Text = $ButtonText2
    $Button2.DialogResult = "No"
    $Button2.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button2)

    $Button3 = New-Object System.Windows.Forms.Button
    $Button3.Location = New-Object System.Drawing.Size(250,100)
    $Button3.Size = New-Object System.Drawing.Size(90,30)
    $Button3.Text = $ButtonText3
    $Button3.DialogResult = "OK"
    $Button3.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button3)

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(55,45) 
    $objLabel.Size = New-Object System.Drawing.Size(295,80)
    $objLabel.font = New-Object System.Drawing.Font("Microsoft Sans Serif",9,[System.Drawing.FontStyle]::Regular)
    $objLabel.Text = "Which tool would you like to install?`n"
    $objForm.Controls.Add($objLabel)

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    Return $objForm.ShowDialog()
}

PromptUser