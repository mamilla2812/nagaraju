﻿param(

    [string]$param
    
    )



$Version = "1.0"

write-host "Welcome to GLIDE - Automatic Deployment v$version" -BackgroundColor White -ForegroundColor black
write-host "----------------------------------------`n" -BackgroundColor White -ForegroundColor black

if (!($PSScriptRoot)){
    $PSScriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
}

Function GetShortDate() {
    
    $TempDate = get-date
    $TempMonth = $tempDate.Month
    $TempDay = $tempDate.Day
    $TempYear = $TempDate.Year
    $TempTime = Get-date -Format HHmm
    $TempMonth = Switch($TempMonth){
        1 {"JAN"}
        2 {"FEB"}
        3 {"MAR"}
        4 {"APR"}
        5 {"MAY"}
        6 {"JUN"}
        7 {"JUL"}
        8 {"AUG"}
        9 {"SEP"}
        10 {"OCT"}
        11 {"NOV"}
        12 {"DEC"}
    }

    $Date = "$TempDay$TempMonth$TempYear" + "_" + "$TempTime"
    $Date

}

Function CheckServerList(){
    
    write-host "Checking for GLIDE_ServerList.csv at $RootDir\ConfigurationFiles\GLIDE_ServerList.csv" -BackgroundColor White -ForegroundColor Black
    if (Test-Path "$RootDir\ConfigurationFiles\GLIDE_ServerList.csv"){
        $ServerList = import-csv "$RootDir\ConfigurationFiles\GLIDE_ServerList.csv"
        write-host "GLIDE_ServerList.csv already exists." -BackgroundColor Green -ForegroundColor White
    }else{
        write-host "GLIDE_ServerList.csv does not exist. Creating file." -BackgroundColor Green -ForegroundColor White
        "ServerName,InstanceName,DatabaseName" > "$RootDir\ConfigurationFiles\GLIDE_ServerList.csv"
    }
    
}

Function BuildInstanceList(){

    $ServerList = import-csv "$RootDir\ConfigurationFiles\GLIDE_ServerList.csv"

    $InstanceArray = @()

    foreach($row in $ServerList){

        $server = $row.ServerName
        if (!($row.InstanceName -eq "" -or $row.InstanceName -eq $null)){
            if ($Row.InstanceName -like "*,*"){
                If ($Row.InstanceName -like ",*"){
                    $instance = $Server + $Row.InstanceName
                }else{
                    $instance = $Server + "\" + $Row.InstanceName
                }
            }else{
                $instance = $Server + "\" + $Row.InstanceName
            }
        }else{
            $instance = $Server
        }
        #$instance += "TEST"
        $InstanceArray += $instance

    }
    return $InstanceArray
}

Function RunGlideInstall($InstanceArray, $RootDir, $InstallStatusFile){
    foreach ($instance in $InstanceArray){
        Write-Host "Attempting to install GLIDE on $instance" -BackgroundColor white -ForegroundColor Black
        $InstanceFileName = $instance.Replace("\","-")
        $FilePath = $RootDir + "\Reports\CurrentReports\GLIDE_InstallLog_$InstanceFileName`_$date.txt"
        $Timestamp = Get-Date
        Try{
            Invoke-Sqlcmd -InputFile $SQLInstall -ServerInstance $instance -ErrorAction Stop -Verbose 4> $FilePath
            
            if ((!(Test-Path $FilePath)) -or (gc $FilePath).Length -eq 0){
            
            write-host "GLIDE Install Failed" -BackgroundColor Red
            "Automatic deployment of GLIDE Failed!
Error thrown when attempting to invoke-Sqlcmd.
This can occur for the following reasons:
 - Connectivity to remote instance cannot be made
 - Installed PowerShell version is less than v3.0
 - Install script is not present." > $FilePath
        
        "$Timestamp : $Instance : GLIDE Install Failed" >> $InstallStatusFile
        }else{
            write-host "GLIDE Install Succeeded" -BackgroundColor Green -ForegroundColor Black
            "$Timestamp : $Instance : GLIDE Install Succeeded" >> $InstallStatusFile
        }
        }Catch{
            "SCRIPT EXECUTION FAILED HERE." >> $FilePath
            "Error Message:" >> $FilePath
            $Error[0].Exception >> $FilePath
            write-host "GLIDE Install Failed" -BackgroundColor Red
            "$Timestamp : $Instance : GLIDE Install Failed - Error occurred during execution of the script. See individual log file for details." >> $InstallStatusFile
        }
    }
}

Function DrawMessageBox($ButtonText1,$ButtonText2,$ButtonText3,$LabelText){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "GLIDE Automatic Installation"
    $objForm.Size = New-Object System.Drawing.Size(400,200) 
    $objForm.StartPosition = "CenterScreen"

    $objForm.KeyPreview = $True
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        {$objForm.Close()}})
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {$objForm.Close()}})

    $Button1 = New-Object System.Windows.Forms.Button
    $Button1.Location = New-Object System.Drawing.Size(50,100)
    $Button1.Size = New-Object System.Drawing.Size(90,30)
    $Button1.Text = $ButtonText1
    $Button1.DialogResult = "Yes"
    $Button1.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button1)

    $Button2 = New-Object System.Windows.Forms.Button
    $Button2.Location = New-Object System.Drawing.Size(150,100)
    $Button2.Size = New-Object System.Drawing.Size(90,30)
    $Button2.Text = $ButtonText2
    $Button2.DialogResult = "No"
    $Button2.Enabled = $False
    $Button2.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button2)

    $Button3 = New-Object System.Windows.Forms.Button
    $Button3.Location = New-Object System.Drawing.Size(250,100)
    $Button3.Size = New-Object System.Drawing.Size(90,30)
    $Button3.Text = $ButtonText3
    $Button3.DialogResult = "OK"
    $Button3.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button3)

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(55,45) 
    $objLabel.Size = New-Object System.Drawing.Size(295,80)
    $objLabel.font = New-Object System.Drawing.Font("Microsoft Sans Serif",9,[System.Drawing.FontStyle]::Regular)
    $objLabel.Text = "How would you like to load the server list?`n"
    $objForm.Controls.Add($objLabel)

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    Return $objForm.ShowDialog()

}

Function GenerateDynamicCheckBoxForm($CheckBoxLabels){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $CheckBoxCounter = 1
    $RowCounter = 1
    $objForm = New-Object System.Windows.Forms.Form
    $button1 = New-Object System.Windows.Forms.Button
    $listBox1 = New-Object System.Windows.Forms.ListBox
    $InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState
    
    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "GLIDE Automatic Installation"
    $objForm.Size = New-Object System.Drawing.Size(600,550) 
    $objForm.StartPosition = "CenterScreen"

    # When we create a new textbox, we add it to an array for easy reference later
    $CheckBoxes = foreach($Label in $CheckBoxLabels) {
        $CheckBox = New-Object System.Windows.Forms.CheckBox        
        $CheckBox.UseVisualStyleBackColor = $True
        $System_Drawing_Size = New-Object System.Drawing.Size
        $System_Drawing_Size.Width = 120
        $System_Drawing_Size.Height = 30
        $CheckBox.Size = $System_Drawing_Size
        $CheckBox.TabIndex = 2
        $CheckBox.Checked = $TRUE
        # Assign text based on the input
        $CheckBox.Text = $Label

        $System_Drawing_Point = New-Object System.Drawing.Point
        $System_Drawing_Point.X = 27 + (($RowCounter - 1) * 150) 
        # Make sure to vertically space them dynamically, counter comes in handy
        $System_Drawing_Point.Y = 113 + (($CheckBoxCounter - 1) * 31)
        If ($System_Drawing_Point.Y -gt 430){
            $RowCounter++
            $System_Drawing_Point.X = 27 + (($RowCounter - 1) * 150)
            $CheckBoxCounter = 1
            $System_Drawing_Point.Y = 113 + (($CheckBoxCounter - 1) * 31)   
        }
        $CheckBox.Location = $System_Drawing_Point
        $CheckBox.DataBindings.DefaultDataSourceUpdateMode = 0

        # Give it a unique name based on our counter
        $CheckBox.Name = "CheckBox$CheckBoxCounter$RowCounter"

        # Add it to the form
        $objForm.Controls.Add($CheckBox)
        # return object ref to array
        $CheckBox
        # increment our counter
        $CheckBoxCounter++

    }

    $Button1 = New-Object System.Windows.Forms.Button
    $Button1.Location = New-Object System.Drawing.Size(145,460)
    $Button1.Size = New-Object System.Drawing.Size(90,30)
    $Button1.Text = "Install!"
    $Button1.Add_Click({
        $Script:InstanceArray = @()
        foreach($CheckBox in $CheckBoxes){
            if($CheckBox.Checked){
                $Script:InstanceArray += $CheckBox.Text
            }
        }
        $objForm.Close()
    })
    $objForm.Controls.Add($Button1) 

    $Button2 = New-Object System.Windows.Forms.Button
    $Button2.Location = New-Object System.Drawing.Size(255,460)
    $Button2.Size = New-Object System.Drawing.Size(90,30)
    $Button2.Text = "Select All"
    $Button2.Add_Click({
        foreach($CheckBox in $CheckBoxes){
            $CheckBox.Checked = $TRUE
        }
    })
    $objForm.Controls.Add($Button2)

    $Button3 = New-Object System.Windows.Forms.Button
    $Button3.Location = New-Object System.Drawing.Size(365,460)
    $Button3.Size = New-Object System.Drawing.Size(90,30)
    $Button3.Text = "De-Select All"
    $Button3.Add_Click({
        foreach($CheckBox in $CheckBoxes){
            $CheckBox.Checked = $False
        }
    })
    $objForm.Controls.Add($Button3)

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(120,45) 
    $objLabel.Size = New-Object System.Drawing.Size(450,80)
    $objLabel.font = New-Object System.Drawing.Font("Microsoft Sans Serif",12,[System.Drawing.FontStyle]::Regular)
    $objLabel.Text = "Please select the instances where you`n      wish to install/upgrade GLIDE.`n"
    $objForm.Controls.Add($objLabel)

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    #Show the Form
    [void] $objForm.ShowDialog()
    return $InstanceArray
}

Function ValidateInput($ImportedFile, $FilePath){
    $ServerList = @()
    foreach ($line in $ImportedFile){
        if ($line -match '[^a-z0-9\\,]+'){
            write-host "$Line - not added to server list"
        }else{
            if ($line -like "*,*"){
                $Port = $line.Split(",")[1]
                If ($line -like "*\*"){
                    $ServerList += $line.Split("\")[0] + ",`"" + $line.Split("\")[1] + $Port + "`""
                }else{
                    $ServerList += $line.Split(",")[0] + ",`"," + $Port + "`""
                }
            }elseif (!($line -like "")){
                $ServerList += $line.Replace("\",",")
            }
        }
    }
    foreach($line in $ServerList){
        $line >> $filepath
    }
}

Function PopulateServerList($filepath){
    $ServerList = @()
    $ImportedFile = @()
    "ServerName,InstanceName,DatabaseName" > $filepath

    $UserPrompt = DrawMessageBox "From File" "Bulk Copy" "Line by Line" "How would you like to load the server list?"
    Switch ($UserPrompt){
        "Yes" {
            [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    
            $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
            $OpenFileDialog.initialDirectory = $initialDirectory
            $OpenFileDialog.filter = "txt (*.txt)| *.txt"
            $OpenFileDialog.ShowDialog() | Out-Null
            if (!($OpenFileDialog.FileName -eq "")){
                $ImportedFile = gc $OpenFileDialog.FileName
            }else{
                return -1
            }
            ValidateInput $ImportedFile $filepath
        }
        "No" {
            $ServerList = "ServerName,InstanceName,DatabaseName"
            $ServerList += (read-host).Split("`n")
            ValidateInput $ServerList $filepath
        }
        "OK"{
            write-host "Enter each line in the following format: ServerName\InstanceName" -BackgroundColor Yellow -ForegroundColor Black
            write-host "(Add \DatabaseName at end of line if GLIDE or EDS database is not present)." -BackgroundColor Yellow -ForegroundColor Black
            write-host "Strike enter with no input to complete the list." -BackgroundColor Yellow -ForegroundColor Black
            While($Input){
                $Input = @()
                $Input += read-host
                ValidateInput $input $filepath
            }
        }
        "Cancel"{
             write-host "CANCEL" -BackgroundColor Red
        }

    }
}

Function PopulateHostInstance($FilePath){
    
    $Input = $Env:COMPUTERNAME

    [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
    $result = [Microsoft.VisualBasic.Interaction]::MsgBox("Is the GLIDE database stored on the default instance of $Input`?", 'YesNo,Question', "GLIDE Automatic Installation") 
    If ($result -eq "No"){
        $Input = @()
        write-host "Please enter the instance where the GLIDE Database is/will be installed." -BackgroundColor Yellow -ForegroundColor Black
        write-host "Syntax: ServerName\InstanceName" -BackgroundColor Yellow -ForegroundColor Black
        $Input += read-host
    }
    $Input>$filepath
}

Function PopulateEmailConfiguration($FilePath){

    write-host "Please enter the configuration required for emails." -BackgroundColor Yellow -ForegroundColor Black
    write-host "Syntax: ServerGroup,Customer,SMTPServer,`"To@Address1,To@Address2`",From@Address" -BackgroundColor Yellow -ForegroundColor Black
    $Input = read-host
    "ServerGroup,Customer,SMTPServer,ToAddress,FromAddress" > $filepath
    $input >> $filepath

}
function CheckDirectoryStructure($LocalFilepath){

    $Year = (get-date).Year
    
    if (!(test-path "$LocalFilepath\Reports\ArchivedReports\$year")){
        new-item "$LocalFilepath\Reports\ArchivedReports\$year" -ItemType Directory | out-null
    }
    if (!(test-path "$LocalFilepath\Reports\CurrentReports")){
        new-item "$LocalFilepath\Reports\CurrentReports" -ItemType Directory | out-null
    }

    #Used to test if folders are missing
    if (!((Get-ChildItem -Path "$LocalFilepath\Reports\ArchivedReports\$year\").count -eq 13)){
        $PresentDirectories = @()
        $ExpectedDirectories = @()
        $MissingDirectories = @()
        $presentDirectoriesArr = @()
        $PresentDirectories = get-childitem -path "$LocalFilepath\Reports\ArchivedReports\$year\"
        $ExpectedDirectories += "01JAN"
        $ExpectedDirectories += "02FEB"
        $ExpectedDirectories += "03MAR"
        $ExpectedDirectories += "04APR"
        $ExpectedDirectories += "05MAY"
        $ExpectedDirectories += "06JUN"
        $ExpectedDirectories += "07JUL"
        $ExpectedDirectories += "08AUG"
        $ExpectedDirectories += "09SEP"
        $ExpectedDirectories += "10OCT"
        $ExpectedDirectories += "11NOV"
        $ExpectedDirectories += "12DEC"
        $ExpectedDirectories += "OtherFiles"
        foreach ($element in $PresentDirectories){
            $PresentDirectoriesArr += $element.Name
        }
        $MissingDirectories = $ExpectedDirectories | where {$PresentDirectoriesArr -notcontains $_}


        foreach ($Directory in $MissingDirectories){
            new-item "$LocalFilepath\Reports\ArchivedReports\$year\$Directory" -ItemType Directory | out-null
        }
    }
    
}

Function Get-ScheduledTask($ComputerName){

    $var = @()
    $var += "TaskName,Next Run Time,Status"
    $var += (schtasks.exe /query /fo csv | where {$_ -notlike "*TaskName*Next Run Time*Status*"})
    $var = ConvertFrom-Csv $var
    return $var
}

Function CreateScheduledTasks($GlidePath, $LogPathSchTask) {

    Write-Host "Creating required scheduled tasks" -BackgroundColor White -ForegroundColor Black
    #Creates the scheduled tasks required for GLIDE to run
    #runs each scheduled task
    #disables scheduled tasks except PULSE CHECKS and DAILY JOB (if primary server)
    $glidePath = "Powershell.exe " + $glidePath
    $TaskNameOld = "GLIDE_Daily_Jobs"
    $TaskNameNew = "GLIDE.ps_Daily_Report"
    $ComputerName = $env:COMPUTERNAME
    $AllTasks = Get-ScheduledTask $ComputerName
    $TaskExists = $AllTasks | Where-Object {$_.TaskName -like "*$TaskNameNew*"}

    if(!($taskExists)) {
            
        #write-host "Please enter the account the the scheduled tasks will run under
        #create thescheduled tasks
        if ($param -eq "Automatic"){
            CreateTaskAuto $TaskNameNew $glidePath $LogPathSchTask 06:30
        }else{
            CreateTaskUserPrompt $TaskNameNew $glidePath $LogPathSchTask 06:30
            schtasks.exe /run /tn $TaskNameNew | out-file $LogPathSchTask -append
        }
        #runs the task initially
    }
    $taskExists = $AllTasks | Where-Object {$_.Name -like "*$TaskNameOld*"}
    if ($taskExists){

        schtasks.exe /CHANGE /TN $TaskNameOld /DISABLE | out-file $LogPathSchTask -append
    }
       
} 

Function CreateTaskUserPrompt($TaskName, $FilePath, $LogPath, $StartTime){

    $ServiceAccount = Get-Credential -Message "Please enter the account that the scheduled tasks will run under."
    $user = $ServiceAccount.UserName
    $servicePW = $ServiceAccount.GetNetworkCredential().Password
    schtasks.exe /create /tn $TaskName /ru $user /rp $servicePW /RL HIGHEST /sc DAILY /tr $FilePath /ST $StartTime  | out-file $LogPath

}

Function CreateTaskAuto($TaskName, $FilePath, $LogPath, $StartTime){

    schtasks.exe /create /tn $TaskName /RL HIGHEST /sc DAILY /tr $FilePath /ST $StartTime  | out-file $LogPath

}

$date = GetShortDate
$RootDir = (get-item "$PSScriptRoot\").Parent.FullName
$FilePathServerList = "$RootDir\ConfigurationFiles\GLIDE_ServerList.csv"
$FilePathHostInstance = "$RootDir\ConfigurationFiles\GLIDE_HostInstance.txt"
$FilePathEmailConfiguration = "$RootDir\ConfigurationFiles\GLIDE_EmailConfiguration.csv"
$SQLInstall = "$RootDir\Code\Install_GLIDE_SQL_2012.sql"
$GlidePS1Path = "$RootDir\Code\GLIDE_DailyReport.ps1"
$LogPathSchTask = "$RootDir\Reports\CurrentReports\GLIDE_InstallLog_ScheduledTasks$date.txt"
$InstallStatusFile = "$RootDir\Reports\CurrentReports\GLIDE_InstallStatus_$date.txt"

CheckDirectoryStructure "$RootDir"

if (!($param -eq "Automatic")){

    if (Test-Path $FilePathServerList){

    Write-Host "Checking if server list exists" -BackgroundColor White -ForegroundColor Black
    
    [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
    $result = [Microsoft.VisualBasic.Interaction]::MsgBox("ServerList.csv detected. Would you like to rewrite it?", 'YesNo,Question', "GLIDE Automatic Installation") 
    if ($result -eq "Yes"){
        PopulateServerList $FilePathServerList
    }

    }else{
        PopulateServerList $FilePathServerList
    }

    if (Test-Path $FilePathHostInstance){
    
        Write-Host "Checking if host server file exists" -BackgroundColor White -ForegroundColor Black

        [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
        $result = [Microsoft.VisualBasic.Interaction]::MsgBox("HostInstance.txt detected. Would you like to rewrite it?", 'YesNo,Question', "GLIDE Automatic Installation") 
        if ($result -eq "Yes"){
            PopulateHostInstance $FilePathHostInstance
        }

    }else{
        PopulateHostInstance $FilePathHostInstance
    }

    if (Test-Path $FilePathEmailConfiguration){

        Write-Host "Checking if email configuration exists" -BackgroundColor White -ForegroundColor Black

        [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
        $result = [Microsoft.VisualBasic.Interaction]::MsgBox("EmailConfiguration.csv detected. Would you like to rewrite it?", 'YesNo,Question', "GLIDE Automatic Installation") 
        if ($result -eq "Yes"){
            PopulateEmailConfiguration $FilePathEmailConfiguration
        }

    }else{
        PopulateEmailConfiguration $FilePathEmailConfiguration
    }
        RunGlideInstall (GenerateDynamicCheckBoxForm (BuildInstanceList)) $RootDir $InstallStatusFile
}else{

    RunGlideInstall (BuildInstanceList) $RootDir $InstallStatusFile

}

#>
CreateScheduledTasks $GlidePS1Path $LogPathSchTask

write-host "Installation Complete. Please check individual report files for the status of each install." -ForegroundColor White -BackgroundColor Black