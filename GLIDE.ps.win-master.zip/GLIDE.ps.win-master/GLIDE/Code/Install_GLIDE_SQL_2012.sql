PRINT 'check GLIDE database exists'
SET NOCOUNT ON

IF NOT EXISTS (SELECT name FROM master.sys.databases WHERE name = N'GLIDE')
BEGIN
	--find the location of the last created user database
	DECLARE
		@l_str_data VARCHAR(3000),
		@l_str_log VARCHAR(3000)
	
	-----------------------------------------------------
	------------specify directory for db-----------------
	
	SELECT
		@l_str_data = '',
		@l_str_log = ''
	
	------------specify directory for db-----------------
	-----------------------------------------------------
			
	IF @l_str_data <> '' AND @l_str_log <> '' 
	BEGIN
		PRINT 'install directory specified by user'
		--place the GLIDE database IN the same location
		EXEC (
			'CREATE DATABASE [GLIDE] ON (
				Name = N''GLIDE_data'',
				Filename = N''' + @l_str_data + '\GLIDE_data.mdf'',
				Size = 15mb,
				Filegrowth = 5mb
						 )
			log ON (
				Name = N''GLIDE_log'',
				Filename = N''' + @l_str_log + '\GLIDE_log.ldf'',
				Size = 5mb,
				Filegrowth = 5mb
			)'
							 )
	END
	ELSE
		CREATE DATABASE [GLIDE]
		ALTER AUTHORIZATION ON DATABASE::[GLIDE] TO [sa];

	PRINT 'GLIDE database creating'
END

GO

IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'GLIDE')
BEGIN
	PRINT 'GLIDE Install Failed - GLIDE Database was not created or does not exist.'
	RAISERROR('GLIDE is unable to create the GLIDE database. stopping execution now!',20,1) WITH log
END
ELSE
BEGIN
	PRINT 'GLIDE database created'
END
GO

USE [GLIDE]
GO

PRINT 'checking GLIDE tables and constraints'

IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[entity_settings]') AND type IN (N'U'))
BEGIN
	CREATE TABLE [entity_settings] (
	[entity_type] [VARCHAR](10) NOT NULL,
	[entity_name] [VARCHAR](128) NOT NULL,
	[setting] [VARCHAR](30) NOT NULL,
	[value] [VARCHAR](255) NOT NULL,
		CONSTRAINT [pk_entity_settings] PRIMARY key CLUSTERED (
	[entity_type] ASC,
	[entity_name] ASC,
	[setting] ASC
	)
) ON [PRIMARY]
END	
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[extra_modules]') AND type IN (N'U'))
BEGIN
	CREATE TABLE [extra_modules] (
	[module_name] [VARCHAR](255) NOT NULL,
	[module_type] [VARCHAR](1) NOT NULL,
	[module_order] [INT] NOT NULL,
	[is_enabled] [VARCHAR](1) NOT NULL,
		CONSTRAINT [pk_extra_modules] PRIMARY KEY CLUSTERED (
	[module_name] ASC
	)
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[GLIDE_versions]') AND type IN (N'U'))
BEGIN
	CREATE TABLE [GLIDE_versions] (
	[version] [VARCHAR](10) NOT NULL,
	[installed] [DATETIME] NOT NULL,
		CONSTRAINT [pk_GLIDE_versions] PRIMARY KEY CLUSTERED (
	[version] ASC,
	[installed] ASC
	)
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[server_options]') AND type IN (N'U'))
	DROP TABLE server_options
GO
CREATE TABLE [server_options](
	[collation] [VARCHAR](128) NOT NULL,
	[edition] [VARCHAR](128) NOT NULL,
	[isclustered] [BIT] NOT NULL,
	[isfulltextinstalled] [BIT] NOT NULL,
	[isintegratedsecurityonly] [BIT] NOT NULL,
	[issingleuser] [BIT] NOT NULL,
	[licensetype] [VARCHAR](128) NOT NULL,
	[machinename] [VARCHAR](128) NOT NULL,
	[numlicenses] [VARCHAR](10) NOT NULL,
	[productversion] [VARCHAR](128) NOT NULL,
	[productlevel] [VARCHAR](128) NOT NULL,
	[servername] [VARCHAR](128) NOT NULL,
	[clusteractivenodename] [VARCHAR](128) NOT NULL,
	[row_date] [DATETIME] NOT NULL
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[db_options]') AND type IN (N'U'))
	DROP TABLE db_options
GO
CREATE TABLE [db_options](
	[name] [VARCHAR](1000) NOT NULL,
	[collation] [VARCHAR](128),
	[isansinulldefault] [BIT] NOT NULL,
	[isansinullsenabled] [BIT] NOT NULL,
	[isansipaddingenabled] [BIT] NOT NULL,
	[isansiwarningsenabled] [BIT] NOT NULL,
	[isarithmeticabortenabled] [BIT] NOT NULL,
	[isautoclose] [BIT] NOT NULL,
	[isautocreatestatistics] [BIT] NOT NULL,
	[isautoshrink] [BIT] NOT NULL,
	[isautoupdatestatistics] [BIT] NOT NULL,
	[isclosecursorsoncommitenabled] [BIT] NOT NULL,
	[isfulltextenabled] [BIT] NOT NULL,		
	[islocalcursorsdefault] [BIT] NOT NULL,
	[ismergepublished] [BIT] NOT NULL,
	[isnullconcat] [BIT] NOT NULL,
	[isnumericroundabortenabled] [BIT] NOT NULL,
	[isquotedidentifiersenabled] [BIT] NOT NULL,
	[isrecursivetriggersenabled] [BIT] NOT NULL,
	[issubscribed] [BIT] NOT NULL,
	[istornpagedetectionenabled] [BIT] NOT NULL,
	[recovery] [VARCHAR](20),
	[sqlsortorder] [VARCHAR](20),			
	[row_date] [DATETIME] NOT NULL,
	[encryption_keys] INT NOT NULL constraint df_db_options_encryption_keys default 0,
	[encryption_certificates] INT NOT NULL constraint df_db_options_encryption_certificates default 0
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[db_size]') AND type IN (N'U'))
	DROP TABLE [db_size]
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[db_filesize]') AND type IN (N'U'))
BEGIN
CREATE TABLE [db_filesize](
	[dbname] [VARCHAR](1000) NOT NULL,
	[file_type] VARCHAR(10) NOT NULL,
	[logical_name] VARCHAR(1000) NOT NULL,
	[physical_name] VARCHAR(1000) NOT NULL,
	[total_size] FLOAT NOT NULL,
	[used_size] FLOAT NOT NULL,
	[free_size] FLOAT NOT NULL,	
	[row_date] [DATETIME] NOT NULL
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[db_status]') AND type IN (N'U'))
	DROP TABLE [db_status]
GO
CREATE TABLE [db_status](
	[name] [VARCHAR](1000) NOT NULL,
	[isinstandby] [BIT] NOT NULL,
	[status] [VARCHAR](20) NOT NULL,
	[updateability] [VARCHAR](20) NOT NULL,
	[useraccess] [VARCHAR](20) NOT NULL,	
	[row_date] [DATETIME] NOT NULL		
) ON [PRIMARY]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'current_blocks') AND type IN (N'U'))
BEGIN
	DROP TABLE GLIDE.dbo.current_blocks
END
GO
CREATE TABLE [current_blocks] (
	database_name	VARCHAR(128) NOT NULL,
	spid			INTEGER	NOT NULL, --spid of locked process
	locktime		SMALLDATETIME  NOT NULL,--time lock was first recorded	
	batchtime		SMALLDATETIME NOT NULL,--time the last batch was sent
	locktype		VARCHAR(40) NOT NULL,--type of lock being applied
	blocking		INTEGER	NULL, --count of processed blocked by this process
	connection_host	VARCHAR(128) NOT NULL, --host machine connection came FROM
	connection_app	VARCHAR(128) NOT NULL, --application making the connection
	db_user			VARCHAR(128) NOT NULL, --database user that made the connection
	sql_handle		BINARY(20) NULL, --sql command sent through that caused the lock
	sql_text		VARCHAR(6000) NULL, --sql command sen t through that caused the lock
	alert_sent		BIT	NOT NULL DEFAULT (0), --IF an alert has been sent i.e. do NOT flag this one again
	processed		BIT	NOT NULL DEFAULT (0) --IF this lock has been checked already
)
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[block_history]') AND type IN (N'U'))
BEGIN
	DROP TABLE GLIDE.dbo.block_history
END
GO
CREATE TABLE dbo.block_history
(
	database_name	VARCHAR(128) NOT NULL,
	spid			INTEGER	NOT NULL, --spid of locked process
	locktime		SMALLDATETIME  NOT NULL,--time lock was first recorded	
	batchtime		SMALLDATETIME NOT NULL,--time the last batch was sent
	locktype		VARCHAR(40) NOT NULL,--type of lock being applied	
	connection_host	VARCHAR(128) NOT NULL, --host machine connection came FROM
	connection_app	VARCHAR(128) NOT NULL, --application making the connection
	db_user			VARCHAR(128) NOT NULL, --database user that made the connection
	sql_text		VARCHAR(7000) NOT NULL, --sql command sent through that caused the lock		
	blocks_held		INT NOT NULL, --number of blocks caused by this spid
	block_duration	INT NOT NULL, --time block has been held for before alert fired
	total_blocks	INT NOT NULL, --total blocks ON the system at this time		
)
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbmon_status]') AND type IN (N'U'))
BEGIN
	CREATE TABLE [dbmon_status] (
	[checkname] [VARCHAR](100) NOT NULL,
	[status] [VARCHAR](100) NOT NULL,
	[message] [VARCHAR](1000) NULL,
	[last_checked] [DATETIME] NULL
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[maintenance_plan]') AND type IN (N'U'))
BEGIN
	DROP TABLE GLIDE.dbo.maintenance_plan
END
GO
CREATE TABLE dbo.maintenance_plan (
	database_name	VARCHAR(128) NOT NULL,
	database_object	VARCHAR(600) NOT NULL,
	task_performed	VARCHAR(30) NOT NULL,
	task_date		SMALLDATETIME NOT NULL default (GETDATE()),
	task_duration	INT	NOT NULL default(0),
	task_status		VARCHAR(30)	NOT NULL default('success'),
)
GO

PRINT 'CREATE constraints'
IF NOT EXISTS(SELECT scobj.name FROM sysconstraints sc INNER JOIN sysobjects scobj ON sc.constid = scobj.id AND sc.id=OBJECT_ID('server_options') INNER JOIN syscolumns cols ON sc.id = cols.id AND sc.colid = cols.colid AND cols.name='row_date')
	ALTER TABLE dbo.server_options add constraint df_server_options_row_date default GETDATE() for row_date
GO
IF NOT EXISTS(SELECT scobj.name FROM sysconstraints sc INNER JOIN sysobjects scobj ON sc.constid = scobj.id AND sc.id=OBJECT_ID('db_options') INNER JOIN syscolumns cols ON sc.id = cols.id AND sc.colid = cols.colid AND cols.name='row_date')
	ALTER TABLE dbo.db_options add constraint df_db_options_row_date default GETDATE() for row_date
GO
IF NOT EXISTS(SELECT scobj.name FROM sysconstraints sc INNER JOIN sysobjects scobj ON sc.constid = scobj.id AND sc.id=OBJECT_ID('db_status') INNER JOIN syscolumns cols ON sc.id = cols.id AND sc.colid = cols.colid AND cols.name='row_date')
	ALTER TABLE dbo.db_status add constraint df_db_status_row_date default GETDATE() for row_date
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA='dbo' AND CONSTRAINT_NAME LIKE'ck__extra_mod__is_en%' AND TABLE_NAME='extra_modules')
	ALTER TABLE [extra_modules]  with check add check  (([is_enabled]='N' OR [is_enabled]='Y'))
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA='dbo' AND CONSTRAINT_NAME LIKE'ck__extra_mod__modul%' AND TABLE_NAME='extra_modules')
	ALTER TABLE [extra_modules]  with check add check  (([module_type]='S' OR [module_type]='P'))
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[valid_databases]') AND OBJECTPROPERTY(id, N'isview') = 1)
BEGIN
	EXEC dbo.sp_executesql @statement = N'
	CREATE view [valid_databases] AS
		SELECT *
		FROM master..sysdatabases
		WHERE (status & 32 <> 32) -- remove databases in loading state
			AND (status & 64 <> 64) -- remove databases in pre recovery state
			AND (status & 128 <> 128) -- remove databases in recovering state
			AND (status & 256 <> 256) -- remove databases in not recovered (suspect) state
			AND (status & 512 <> 512) -- remove databases in offline state
	'
END
GO

PRINT 'create trigger for basic support'
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id=OBJECT_ID('tr_basic_support') AND OBJECTPROPERTY(id, N'istrigger') = 1)
	DROP trigger tr_basic_support
GO

CREATE trigger dbo.tr_basic_support
ON GLIDE.dbo.entity_settings
AFTER INSERT, UPDATE
AS
BEGIN
	IF EXISTS (
		SELECT	entity_name --only fire the trigger if this updates that entity setting
		FROM	inserted
		WHERE	entity_type = 'server'
		AND		setting = 'basic_support'
	)
	BEGIN 			
		IF EXISTS (
			SELECT	entity_name 
			FROM	GLIDE.dbo.entity_settings 
			WHERE	entity_type = 'server'
			AND		setting = 'basic_support'
			AND		value = 'y'
		)
		BEGIN  --turn on basic support
			PRINT 'basic support enabled'
			UPDATE GLIDE.dbo.extra_modules SET is_enabled = 'N' 
			UPDATE GLIDE.dbo.entity_settings SET value = '5' WHERE setting = 'warning_percent' --change disk thresholds
			UPDATE GLIDE.dbo.entity_settings SET value = '1' WHERE setting = 'error_percent'
			UPDATE GLIDE.dbo.entity_settings SET value = 'y' WHERE setting = 'supresseon' --supress escalations and eons
			UPDATE GLIDE.dbo.entity_settings SET value = 'n' WHERE setting = 'escalate_job'
			UPDATE GLIDE.dbo.entity_settings SET value = 'n' WHERE setting = 'escalate_server'
			UPDATE GLIDE.dbo.entity_settings SET value = 'n' WHERE setting = 'escalate_status'
			UPDATE GLIDE.dbo.entity_settings SET value = 'n' WHERE setting = 'escalate_task'
			UPDATE GLIDE.dbo.entity_settings SET value = 'n' WHERE setting = 'is24x7' --server can NOT be 24x7 and basic
		END
		ELSE
		BEGIN  --turn off basic support i.e. SET all settings back to originals
			PRINT 'standard support enabled'
			UPDATE GLIDE.dbo.extra_modules SET is_enabled = 'Y' 
			UPDATE GLIDE.dbo.entity_settings SET value = '15' WHERE setting = 'warning_percent' --change disk thresholds
			UPDATE GLIDE.dbo.entity_settings SET value = '5' WHERE setting = 'error_percent'
			UPDATE GLIDE.dbo.entity_settings SET value = 'n' WHERE setting = 'supresseon'			
		END
	END
END
GO

PRINT 'GLIDE table configuration complete'

PRINT 'inserting default values IF missing'
GO


IF (SELECT count(name) FROM GLIDE.dbo.db_options) = 0
BEGIN
	INSERT INTO dbo.db_options (
		name,
		collation,
		isansinulldefault,
		isansinullsenabled,
		isansipaddingenabled,
		isansiwarningsenabled,
		isarithmeticabortenabled,
		isautoclose,
		isautocreatestatistics,
		isautoshrink,
		isautoupdatestatistics,
		isclosecursorsoncommitenabled,
		isfulltextenabled,
		islocalcursorsdefault,
		ismergepublished,
		isnullconcat,
		isnumericroundabortenabled,
		isquotedidentifiersenabled,
		isrecursivetriggersenabled,
		issubscribed,
		istornpagedetectionenabled,
		recovery,
		sqlsortorder,
		row_date
	)
	SELECT 
		name,
		CONVERT(VARCHAR, databasepropertyex(name, 'collation')),
		CONVERT(BIT, databasepropertyex(name, 'isansinulldefault')),
		CONVERT(BIT, databasepropertyex(name, 'isansinullsenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isansipaddingenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isansiwarningsenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isarithmeticabortenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isautoclose')),
		CONVERT(BIT, databasepropertyex(name, 'isautocreatestatistics')),
		CONVERT(BIT, databasepropertyex(name, 'isautoshrink')),
		CONVERT(BIT, databasepropertyex(name, 'isautoupdatestatistics')),
		CONVERT(BIT, databasepropertyex(name, 'isclosecursorsoncommitenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isfulltextenabled')),
		CONVERT(BIT, databasepropertyex(name, 'islocalcursorsdefault')),
		CONVERT(BIT, databasepropertyex(name, 'ismergepublished')),
		CONVERT(BIT, databasepropertyex(name, 'isnullconcat')),
		CONVERT(BIT, databasepropertyex(name, 'isnumericroundabortenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isquotedidentifiersenabled')),
		CONVERT(BIT, databasepropertyex(name, 'isrecursivetriggersenabled')),
		CONVERT(BIT, databasepropertyex(name, 'issubscribed')),
		CONVERT(BIT, databasepropertyex(name, 'istornpagedetectionenabled')),
		CONVERT(VARCHAR(20), databasepropertyex(name, 'recovery')),
		CONVERT(VARCHAR(20), databasepropertyex(name, 'sqlsortorder')),
		GETDATE()
	FROM master.dbo.sysdatabases	
END
GO


IF (SELECT count(name) FROM GLIDE.dbo.db_status) = 0
BEGIN
	INSERT INTO dbo.db_status (
		name,
		isinstandby,
		status,
		updateability,
		useraccess,
		row_date
	)
	SELECT
		name,
		CONVERT(BIT, databasepropertyex(name, 'isinstandby')),
		CONVERT(VARCHAR(20), databasepropertyex(name, 'status')),
		CONVERT(VARCHAR(20), databasepropertyex(name, 'updateability')),
		CONVERT(VARCHAR(20), databasepropertyex(name, 'useraccess')),
		GETDATE()
	FROM master.dbo.sysdatabases	
END
GO

IF (SELECT count(collation) FROM GLIDE.dbo.server_options) = 0
BEGIN
	DECLARE
		@currentnodename VARCHAR(128),
		@clusteractivenodename VARCHAR(128),
		@isclustered BIT,
		@msg VARCHAR(4000)
	IF EXISTS (SELECT 'x' WHERE SUBSTRING(CONVERT(VARCHAR(128), serverproperty('productversion')),1,CHARINDEX('.',CONVERT(VARCHAR(128), serverproperty('productversion')))-1) >= 9)--sql 2005 AND above
	BEGIN					
		INSERT INTO dbo.server_options (
			collation,
			edition,
			isclustered,
			isfulltextinstalled,
			isintegratedsecurityonly,
			issingleuser,
			licensetype,
			machinename,
			numlicenses,
			productversion,
			productlevel,
			servername,
			clusteractivenodename,
			row_date
		)
		values (
			CONVERT(VARCHAR, serverproperty('collation')),
			CONVERT(VARCHAR(128), serverproperty('edition')),
			CONVERT(BIT, serverproperty('isclustered')),
			CONVERT(BIT, serverproperty('isfulltextinstalled')),
			CONVERT(BIT, serverproperty('isintegratedsecurityonly')),
			CONVERT(BIT, serverproperty('issingleuser')),
			CONVERT(VARCHAR(128), serverproperty('licensetype')),
			CONVERT(VARCHAR(128), serverproperty('machinename')),
			isnull(CONVERT(VARCHAR(10), serverproperty('numlicenses')), 'NULL'),
			CONVERT(VARCHAR(128), serverproperty('productversion')),
			CONVERT(VARCHAR(128), serverproperty('productlevel')),
			CONVERT(VARCHAR(128), serverproperty('servername')),
			CONVERT(VARCHAR(128), serverproperty('computernamephysicalnetbios')), --changed to use sql 2005 FUNCTION
			GETDATE()
		)
	END
	ELSE
	BEGIN
		INSERT INTO dbo.server_options (
			collation,
			edition,
			isclustered,
			isfulltextinstalled,
			isintegratedsecurityonly,
			issingleuser,
			licensetype,
			machinename,
			numlicenses,
			productversion,
			productlevel,
			servername,
			clusteractivenodename,
			row_date
		)
		values (
			CONVERT(VARCHAR, serverproperty('collation')),
			CONVERT(VARCHAR(128), serverproperty('edition')),
			CONVERT(BIT, serverproperty('isclustered')),
			CONVERT(BIT, serverproperty('isfulltextinstalled')),
			CONVERT(BIT, serverproperty('isintegratedsecurityonly')),
			CONVERT(BIT, serverproperty('issingleuser')),
			CONVERT(VARCHAR(128), serverproperty('licensetype')),
			CONVERT(VARCHAR(128), serverproperty('machinename')),
			isnull(CONVERT(VARCHAR(10), serverproperty('numlicenses')), 'NULL'),
			CONVERT(VARCHAR(128), serverproperty('productversion')),
			CONVERT(VARCHAR(128), serverproperty('productlevel')),
			CONVERT(VARCHAR(128), serverproperty('servername')),
			'', --changed to use sql 2005 FUNCTION
			GETDATE()
		)
	END			

END
GO

-- 'data correction from previous versions'
DELETE FROM GLIDE.dbo.entity_settings WHERE entity_type = ''
-- 'DELETE values WHERE we have changed the default'
DELETE FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND entity_type <> 'server'
GO
-- 'adding entity_settings rows'
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','diff_backup_days','database','mon,tue,wed,thu,fri,sat,sun' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'diff_backup_days')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','diff_backup_ignore','database','y' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'diff_backup_ignore')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','diff_backup_warning','database','26' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'diff_backup_warning')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','full_backup_days','database','mon,tue,wed,thu,fri,sat,sun' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'full_backup_days')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','full_backup_ignore','database','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'full_backup_ignore')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','full_backup_warning','database','26' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'full_backup_warning')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','full_backup_critical','database','48' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'full_backup_critical')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','maximum_days_backup_check','bkup_check','7' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'maximum_days_backup_check')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','growth_warning','database','25' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'growth_warning')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','min_file_size','database','1024' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'min_file_size')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','tlog_backup_days','database','mon,tue,wed,thu,fri,sat,sun' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'tlog_backup_days')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','tlog_backup_ignore','database','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'tlog_backup_ignore')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','tlog_backup_warning','database','24' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'tlog_backup_warning')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','error_percent','disk','5' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'error_percent')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','exclude','disk','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'exclude')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','warning_percent','disk','15' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'warning_percent')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','error_log_limit','instance','2' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'error_log_limit')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','hours_allowed','instance','10' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'hours_allowed')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','failures','job','0' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'failures')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','ignore','job','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'ignore') --changed default to n v4.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','max_runtime_hours','job','10' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'max_runtime_hours')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','onlylastrun','job','y' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'onlylastrun')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','dt_adjust','server','0' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'dt_adjust')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','predefined_disks','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'predefined_disks')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','working_days','server','mon,tue,wed,thu,fri' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'working_days')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','supresseon','server','y' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'supresseon')     --added 01/03/2009 gs 2.3.0.5
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','is24x7','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'is24x7')             --added 01/03/2009 gs 2.3.0.5
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','escalate_server','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'escalate_server')   --added 06/04/2009 gs 2.3.0.6
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','escalate_job','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'escalate_job')         --added 22/04/2009 gs 2.3.0.6
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','escalate_task','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'escalate_task')       --added 22/04/2009 gs 2.3.0.6
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','supress_reboot','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'supress_reboot')     --added 23/04/2009 gs 2.3.0.7
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','basic_support','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'basic_support')     --added 09/06/2009 gs 2.3.0.9
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','escalate_status','server','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'escalate_status')       --added 22/04/2009 gs 2.3.0.9
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','checkintegrity','database','y' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'checkintegrity')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','maxblocks','server',1 WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'maxblocks')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','blocktime','server',5 WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'blocktime')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','blockedprocess','server',1 WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'blockedprocess')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','index_rebuild','database',30 WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'index_rebuild')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','index_defrag','database',10 WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'index_defrag')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','size_archive','server','y' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'size_archive')       --added 10/09/2009 gs 2.3.2.0
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','ignore_status_change','database','n' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'ignore_status_change')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','fixedsizedb_error_percent','database','15' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'fixedsizedb_error_percent')
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','dbmon_errorhours','server','24' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = '' AND setting = 'dbmon_errorhours')     --added 11/80/2017 ca 3.2
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT '','check_enabled','check','n' --added v4.0
-- some default values for common entities like C drive
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT 'C','error_percent','disk','3' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = 'C' AND setting = 'error_percent') --C drive thresholds much lower as best practice is to not have database data on the c drive so less likely for it to fill
INSERT INTO GLIDE.dbo.entity_settings (entity_name,setting,entity_type,value)  SELECT 'C','warning_percent','disk','3' WHERE NOT EXISTS (SELECT 1 FROM GLIDE.dbo.entity_settings WHERE entity_name = 'C' AND setting = 'warning_percent') --C drive thresholds much lower as best practice is to not have database data on the c drive so less likely for it to fill

GO
PRINT 'change disk space thresholds if required'
UPDATE GLIDE.dbo.entity_settings SET value = '15'  WHERE setting = 'warning_percent' AND value = '20'
UPDATE GLIDE.dbo.entity_settings SET value = '5' WHERE setting = 'error_percent' AND value = '10'
GO
PRINT 'updating versions'
INSERT INTO [dbo].[GLIDE_versions]([version], [installed]) SELECT N'4.0', GETDATE() WHERE NOT EXISTS (SELECT 1 FROM [dbo].[GLIDE_versions] WHERE [version] = N'4.0')

PRINT 'default data completed'

PRINT 'configure GLIDE database - set db options'
ALTER DATABASE GLIDE SET auto_close off
--ALTER DATABASE GLIDE SET torn_page_detection ON
--ALTER DATABASE GLIDE SET  restricted_user with no_wait
ALTER DATABASE GLIDE SET auto_shrink off
ALTER DATABASE GLIDE SET ansi_null_default off
ALTER DATABASE GLIDE SET recursive_triggers off
ALTER DATABASE GLIDE SET ansi_nulls off
ALTER DATABASE GLIDE SET concat_null_yields_null off
ALTER DATABASE GLIDE SET cursor_close_on_commit off
ALTER DATABASE GLIDE SET cursor_default global
ALTER DATABASE GLIDE SET quoted_identifier off
ALTER DATABASE GLIDE SET ansi_warnings off
ALTER DATABASE GLIDE SET auto_create_statistics ON
ALTER DATABASE GLIDE SET auto_update_statistics ON

IF EXISTS (SELECT 'x' WHERE SUBSTRING(CONVERT(VARCHAR(128), serverproperty('productversion')),1,CHARINDEX('.',CONVERT(VARCHAR(128), serverproperty('productversion')))-1) >= 9)--sql 2005 AND above
BEGIN					
	EXEC sp_configure 'show advanced options', 1
	RECONFIGURE WITH OVERRIDE
	EXEC sp_configure 'ole automation procedures', 1
	RECONFIGURE WITH OVERRIDE
	EXEC sp_configure 'show advanced options', 0
	PRINT 'ole automation enabled'
END
GO

PRINT 'configure GLIDE database - set to simple recovery'
use [master]
GO
ALTER database [GLIDE] SET recovery simple
GO
use [GLIDE]
GO


PRINT 'adding stored procedures and functions to GLIDE'
GO
PRINT ''
GO
--------------------------------------------------------------------

use GLIDE
GO
--------------------------------------------------------------------

PRINT 'recreate uf_get_setting'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[uf_get_setting]') AND OBJECTPROPERTY(id, N'isscalarfunction') = 1)
	DROP FUNCTION [dbo].[uf_get_setting]
GO
--------------------------------------------------------------------
CREATE FUNCTION [dbo].[uf_get_setting](@entitytype VARCHAR(10), @entityname VARCHAR(128), @setting VARCHAR(30))
RETURNS VARCHAR(1000)
	--with encryption
/**********************************************************************
*
* script   :  uf_get_setting
* version  :  2.2
* created  :  doug irwin (GLIDE australia), 23-aug-2007
*
* usage    :  run from various stored procedures.
*
* purpose  :  returns the the requested setting for entity and type
*							requested, creating it from the default if required.
*
* output   :  n/a
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters in GLIDE db
*					and standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
***********************************************************************/
AS
BEGIN
	DECLARE @retval VARCHAR(1000)
	SELECT @retval = [value] FROM [dbo].[entity_settings] WHERE [entity_type] = @entitytype AND [entity_name] = @entityname AND [setting] = @setting
	RETURN @retval
END
GO
--------------------------------------------------------------------


PRINT 'recreate uf_send_error'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[uf_send_error]') AND OBJECTPROPERTY(id, N'isscalarfunction') = 1)
	DROP FUNCTION [dbo].[uf_send_error]
GO
--------------------------------------------------------------------

CREATE FUNCTION dbo.uf_send_error (@i_str_severity VARCHAR(15), @i_str_msg VARCHAR(400), @i_dte_current SMALLDATETIME)
	RETURNS INT
--with encryption
/**********************************************************************
*
* script   :  uf_send_error
* version  :  1.2
* created  :  graham smith (GLIDE australia), 11-nov-2008
*
* usage    :  run FROM various stored procedures.
*
* purpose  :  writes an error to the windows event log
*
* output   :  n/a
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   11-11-08	graham smith	version 1.0 	initial version
*
*   27-01-09	graham smith	version 1.1 	added informational events to the raise error
*												allowed suppression of alerts using entity settings
*
*   26-02-09	graham smith	version 1.2 	added check for 24x7 systems
*												supress messages at weekends
*												corrected information to informational for events
*												added additional parameter to pass date IN
*
***********************************************************************/
AS
BEGIN	
	DECLARE @l_str_msg VARCHAR(1000) --variable to hold the windows event log status
	DECLARE @l_str_event VARCHAR(20) --variable to hold the windows event log status
	DECLARE @l_int_result INT --return variable

	--populate the paremeters
	SET @l_str_msg = CONVERT(VARCHAR(50),serverproperty('servername')) --the server this is occuring ON
		+ ' : ' + @i_str_msg --the message being returned
	IF(UPPER(LTRIM(dbo.uf_get_setting('server','', 'supresseon'))) <> 'y')
	BEGIN
		SET @l_str_msg = @l_str_msg + ' [GLIDE]'  --state this is GLIDE for the monitoring team to id it
	END


	SET	@l_str_event = case @i_str_severity when  'CRITICAL' then 'error' when 'WARNING' then 'WARNING' when 'information' then 'informational' END

	--check IF this is a weekend
	DECLARE @l_int_firstday INT
	DECLARE @l_int_week INT 

	SELECT	@l_int_firstday = @@datefirst - 1,
		@l_int_week = DATEPART(weekday,@i_dte_current) - 1

	IF (@l_int_firstday + @l_int_week) % 7 NOT IN (5, 6)
	BEGIN																		--none weekend day, raise alert AS normal
		EXEC master.dbo.xp_logevent 77777, @l_str_msg, @l_str_event				--write to the windows log
		SELECT @l_int_result = @@error
	END
	ELSE																			--weekend, only raise alert IF 24x7 server AND this is CRITICAL
	IF (UPPER(LTRIM(dbo.uf_get_setting('server','', 'is24x7'))) = 'y') AND @i_str_severity = 'CRITICAL'
	BEGIN				
		EXEC master.dbo.xp_logevent 77777, @l_str_msg, @l_str_event				--write to the windows log
		SELECT @l_int_result = @@error
	END
		
	return @l_int_result															--return the outcome
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_check_settings'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_settings]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_check_settings]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_check_settings](@entitytype VARCHAR(10), @entityname VARCHAR(128))
	--with encryption
/**********************************************************************
*
* script   :  up_check_settings
* version  :  2.2
* created  :  doug irwin (GLIDE australia), 29-feb-2008
*
* usage    :  run FROM various stored procedures.
*
* purpose  :  checks that the appropriate setting EXISTS for AND entity
*							AND type, creating it FROM the default IF required.
*
* output   :  n/a
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters IN GLIDE db
*															AND standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
***********************************************************************/

AS
BEGIN
	SET NOCOUNT ON

	IF (SELECT count(*) FROM dbo.entity_settings WHERE entity_type = @entitytype AND entity_name = '')
		> (SELECT count(*) FROM dbo.entity_settings WHERE entity_type = @entitytype AND entity_name = @entityname)
	BEGIN
		INSERT INTO dbo.entity_settings(
			entity_type,
			entity_name,
			setting,
			value
		)
		SELECT
			@entitytype,
			@entityname,
			setting,
			value
		FROM dbo.entity_settings e1
		WHERE entity_type = @entitytype
			AND entity_name = ''
			AND NOT EXISTS (
				SELECT 1
						FROM dbo.entity_settings e2
						WHERE e2.entity_type = @entitytype
							AND e2.entity_name = @entityname
					AND e1.setting = e2.setting
			)
	END
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_check_jobs'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_check_jobs]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_check_jobs]
GO
--------------------------------------------------------------------

CREATE PROCEDURE [dbo].[up_daily_report_check_jobs]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_check_jobs
* version  :  2.9
* created  :  doug irwin (GLIDE australia), 29-feb-2008
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  lists enables jobs that failed IN last 24 hours
*
* output   :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters IN GLIDE db
*												      AND standardised error/WARNING returns.
*   29-02-08	doug irwin      version 2.2 - first release version!
*
*   23-07-08	graham smith	version 2.3 - added line 77 so the proc only returns failed steps
*												that cause the entire job to fail
*	24-07-08	andre hoorenman	version 2.4 - added raiseerror to enable logchecker notifications
*
*	05-09-08	graham smith	version 2.5 - only reports failed jobs NOT steps to simplify code
*
*	16-09-08	graham smith	version 2.5 - changed raise error to CRITICAL/WARNING for hvt
*
*	07-10-08	graham smith	version 2.6 - allowed failure count to ignore one off failures ON repeating jobs
*							included job category IN WARNING message for failed jobs
*	31-10-08	graham smith	version 2.7 - ignore failure IF last run is a success.
*							created PROCEDURE --with encryption to remove code FROM view
*
*	25-03-09	graham smith	version 2.8 - new entity setting to allow escalation to CRITICAL
*
*	06-04-09	graham smith	version 2.9 - bug fix, changed >= @times_failed to > @times_failed otherwise it never alerts ON one error
***********************************************************************/

AS
BEGIN

	SET NOCOUNT ON

	DECLARE
		@yesterday_date INT,
		@today_date INT,
		@yesterday_hour INT,
		@fail_count INT,
		@printmsg VARCHAR(120),
		@job_id VARCHAR(128),
		@last_run VARCHAR(10),
		@job_name VARCHAR(100),
		@category_name VARCHAR(100),
		@step_name VARCHAR(100),
		@job_severity INT,
		@job_rundate INT,
		@job_runtime INT,
		@last_step INT,
		@job_error VARCHAR(1000),
		@msg VARCHAR(1000),
		@times_failed INT,
		@lstrmsg NVARCHAR(400)

	-- Converts date INTO IN with format YYYMMDD
	SELECT @today_date = CONVERT(INT,(CONVERT(CHAR(4),DATEPART(year,GETDATE())) +
						CONVERT(CHAR(2),right('00' + CONVERT(VARCHAR(2),DATEPART(month,GETDATE())),2)) +
						CONVERT(CHAR(2),right('00' + CONVERT(VARCHAR(2),DATEPART(day,GETDATE())),2))))

	SELECT @yesterday_date = CONVERT(INT,(CONVERT(CHAR(4),DATEPART(year,DATEADD(day,-1,GETDATE()))) +
						CONVERT(CHAR(2),right('00' + CONVERT(VARCHAR(2),DATEPART(month,DATEADD(day,-1,GETDATE()))),2)) +
						CONVERT(CHAR(2),right('00' + CONVERT(VARCHAR(2),DATEPART(day,DATEADD(day,-1,GETDATE()))),2))))

	SELECT @yesterday_hour = CONVERT(INT,CONVERT(CHAR(2),right('00' + CONVERT(VARCHAR(2),DATEPART(hour,GETDATE())),2)) + '0000')

	DECLARE task_cursor CURSOR FOR
		SELECT 
			msdb..sysjobs.name,
			msdb..syscategories.name,
			msdb..sysjobhistory.step_name,
			msdb..sysjobhistory.sql_severity,
			max(msdb..sysjobhistory.run_date),
			max(msdb..sysjobhistory.run_time),
			msdb..sysjobhistory.message,
			count(*) AS times_failed,
			msdb..sysjobs.job_id
		FROM
			msdb..sysjobs,
				msdb..sysjobhistory,
				msdb..syscategories
		WHERE
			(msdb..sysjobhistory.run_status = 0 OR msdb..sysjobhistory.run_status = 3)
			AND (msdb..sysjobhistory.run_date = @today_date OR (msdb..sysjobhistory.run_date = @yesterday_date AND msdb..sysjobhistory.run_time >= @yesterday_hour))
			AND msdb..sysjobs.enabled = 1
			AND msdb..sysjobs.job_id = msdb..sysjobhistory.job_id
				AND msdb..syscategories.category_id = msdb..sysjobs.category_id
				AND msdb.dbo.sysjobhistory.step_id = 0 --only check the overall job status NOT each step
		GROUP BY
			msdb..sysjobs.name,
			msdb..syscategories.name,
			msdb..sysjobhistory.step_name,
			msdb..sysjobhistory.sql_severity,
			msdb..sysjobhistory.message,
			msdb..sysjobs.job_id
		ORDER BY 
			msdb..sysjobhistory.sql_severity DESC,
			msdb..sysjobs.name,
			msdb..sysjobhistory.step_name

	OPEN task_cursor

	FETCH NEXT FROM task_cursor INTO @job_name,@category_name,@step_name,@job_severity,@job_rundate,@job_runtime,@job_error, @times_failed, @job_id

	SET @fail_count = 0

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @last_run = 'failure'
		EXEC up_check_settings 'job', @job_name
		IF UPPER(LEFT(LTRIM(dbo.uf_get_setting('job', @job_name, 'ignore')), 1)) = 'y' OR dbo.uf_get_setting('job', @job_name, 'failures') > @times_failed
		BEGIN
			SELECT @printmsg = 'INFO    : '+@@SERVERNAME
		END
		ELSE
		BEGIN
			--now check to see IF the last run was a success
			IF UPPER(LEFT(LTRIM(dbo.uf_get_setting('job', @job_name, 'onlylastrun')), 1)) = 'y' AND EXISTS(SELECT job_id FROM msdb.dbo.sysjobhistory WHERE job_id=@job_id AND step_id = 0 AND run_status = 1 AND instance_id IN (SELECT max(instance_id) FROM msdb.dbo.sysjobhistory WHERE job_id=@job_id))
			BEGIN
				SELECT @last_run = 'success'
				SELECT @printmsg = 'INFO    : '+@@SERVERNAME
			END
			ELSE
			BEGIN
				SELECT @fail_count = @fail_count + 1
				SELECT @printmsg = 'WARNING : '+@@SERVERNAME
			END
		END

		SELECT @printmsg = @printmsg + ' job failed! ['+SUBSTRING(@category_name,1,60) + '] ' + SUBSTRING(@job_name,1,100)
		PRINT @printmsg

		SELECT @printmsg = 'job name:       ' + SUBSTRING(@job_name,1,100)
		PRINT @printmsg

		SELECT @printmsg = 'category:       ' + SUBSTRING(@category_name,1,60)
		PRINT @printmsg

		SELECT @printmsg = '  step name:      ' + SUBSTRING(@step_name,1,60)
		PRINT @printmsg

		SELECT @printmsg = '  error severity: ' + CONVERT(CHAR(2),@job_severity)
		PRINT @printmsg

		SELECT @printmsg = '  failed ' + CONVERT(VARCHAR(10),@times_failed) + ' time(s) with error message: '
		PRINT @printmsg

		PRINT @job_error

		SELECT @printmsg =
			'  last run: '
						+ SUBSTRING(CONVERT(CHAR(8),@job_rundate),7,2) + '/'
						+ SUBSTRING(CONVERT(CHAR(8),@job_rundate),5,2) + '/'
						+ SUBSTRING(CONVERT(CHAR(8),@job_rundate),1,4) + ' '
						+ SUBSTRING(CONVERT(CHAR(6),(right('00000' + CONVERT(VARCHAR(6),@job_runtime), 6))),1,2) + ':'
						+ SUBSTRING(CONVERT(CHAR(6),(right('00000' + CONVERT(VARCHAR(6),@job_runtime), 6))),3,2) + ':'
						+ SUBSTRING(CONVERT(CHAR(6),(right('00000' + CONVERT(VARCHAR(6),@job_runtime), 6))),5,2)
						+ ' result: ' + @last_run
		PRINT @printmsg

		PRINT ' '

		FETCH NEXT FROM task_cursor INTO
			@job_name,
			@category_name,
			@step_name,
			@job_severity,
			@job_rundate,
			@job_runtime,
			@job_error,
			@times_failed,
			@job_id
	END

	CLOSE task_cursor
	DEALLOCATE task_cursor

	IF @fail_count = 0
	BEGIN
		PRINT 'OKAY'
	END
	ELSE
	BEGIN	
		IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'escalate_job'))) = 'y')
			SELECT dbo.uf_send_error ('CRITICAL','job failures detected',GETDATE())
		ELSE
			SELECT dbo.uf_send_error ('WARNING','job failures detected',GETDATE())
	END

END
GO
--------------------------------------------------------------------

PRINT 'DELETE up_daily_report_config_options AS now superseeded'
GO
--------------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_config_options]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_config_options]
GO

PRINT 'recreate up_daily_report_database_options'
GO
--------------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_database_status]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_database_status]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_database_status]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_database_status
* version  :  1.0 
* created  :  graham smith (GLIDE australia), 09-june-2009
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  warns when database status has changed
*
* output   :  populates TABLE db_options 
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters IN GLIDE db
*															AND standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
*	24-07-08	andre hoorenman	version 2.3 - added raiserror for logchecker automation
*
*	16-09-08	graham smith	version 2.4 - changed raise error to CRITICAL/WARNING for hvt
*
*	25-03-09	graham smith	version 2.5 - new entity setting to allow escalation to CRITICAL
*
*	02-04-09	graham smith	version 2.6 - new check for database encryption AND encryption certificates
*
*	23-04-09	graham smith	version 2.7 - check for new databases AND raise WARNING to the report
*
*	23-06-09	graham smith	version 1.0 - database status check (branched FROM 2.7 of up_daily_report_config_options)
*
*	23-06-09	graham smith	version 1.1 - bug fix so that database status is written back to the database_status TABLE
***********************************************************************/

AS
BEGIN
	SET NOCOUNT ON

	-- if a database is brought back online then it should be monitored
	UPDATE GLIDE..entity_settings
	SET value = 'n'
	WHERE setting = 'ignore_status_change'
	AND value = 'y'
	AND entity_name IN (
		SELECT name 
		FROM GLIDE..valid_databases
	)

	DECLARE	
		@msg				VARCHAR(4000),
		@change_count		INT,
		@currentnodename	VARCHAR(128),
		@crlf   			CHAR(2),
		@lstrmsg 			NVARCHAR(400),
		@lintalert			INT,

		-- databasepropertyex
		@name		 		VARCHAR(1000),	
		@status				VARCHAR(20),	
		@isinstandby	 		BIT,
		@updateability	 		VARCHAR(20),
		@useraccess	 		VARCHAR(20)
		
	SET @change_count = 0
	SET @crlf = CHAR(13) + CHAR(10)

	-- database options

	DECLARE table_cursor_1 CURSOR FOR
	SELECT  name,		
		isinstandby,
		status,
		useraccess,
		updateability
	FROM dbo.db_status
	OPEN table_cursor_1

	FETCH NEXT FROM table_cursor_1 INTO
		@name,
		@isinstandby,
		@status,
		@useraccess,
		@updateability
		
	WHILE @@FETCH_STATUS = 0
	BEGIN			
		SET @msg = ''
		IF EXISTS (SELECT 'x' FROM GLIDE.dbo.valid_databases WHERE name = @name)
		BEGIN
			IF CONVERT(VARCHAR(20), databasepropertyex(@name, 'status')) 			<> @status				SET @msg = @msg + @name + ' : database status changed : '  				+ @status	 				+ ' -> ' + CONVERT(VARCHAR(20), databasepropertyex(@name, 'status')) 			+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isinstandby')) 			<> @isinstandby				SET @msg = @msg + @name + ' : database standby mode changed : '  			+ CONVERT(CHAR(1), @isinstandby)	 	+ ' -> ' + CONVERT(CHAR(1), databasepropertyex(@name, 'isinstandby')) 			+ @crlf
			IF CONVERT(VARCHAR(20), databasepropertyex(@name, 'updateability')) 		<> @updateability			SET @msg = @msg + @name + ' : database updateability changed : '  			+ @updateability				+ ' -> ' + CONVERT(VARCHAR(20), databasepropertyex(@name, 'updateability')) 		+ @crlf
			IF CONVERT(VARCHAR(20), databasepropertyex(@name, 'useraccess')) 		<> @useraccess				SET @msg = @msg + @name + ' : database user access changed : '  			+ @useraccess					+ ' -> ' + CONVERT(VARCHAR(20), databasepropertyex(@name, 'useraccess')) 			+ @crlf									
		END
		ELSE
		BEGIN
			--checks IF database is NOT IN a valid state.
			--checks IF database is being mirrored, IF so will check IF it is IN state 4. 
			--IF database is NOT IN state 4, it will be ignored since the database will be IN restoring mode AND return false positive.
			IF EXISTS(
				SELECT * 
				FROM sys.databases sdb
				INNER JOIN sys.database_mirroring m ON sdb.database_id = m.database_id
				WHERE sdb.state != 0 
					AND (m.mirroring_state != 4 OR m.mirroring_state IS NULL) 
					AND name COLLATE DATABASE_DEFAULT = @name COLLATE DATABASE_DEFAULT
				)
			BEGIN
				SELECT @msg = 'database ' + @name + ' is in ' + CONVERT(VARCHAR(20), databasepropertyex(@name, 'status')) + ' mode.'
			END
			ELSE IF EXISTS(
				SELECT name
				FROM GLIDE.dbo.db_status
				WHERE name COLLATE DATABASE_DEFAULT NOT IN (SELECT name COLLATE DATABASE_DEFAULT FROM master.dbo.sysdatabases) 
					AND name = @name
				)
			BEGIN
				SELECT @msg = 'database ' + @name + ' has been removed'
			END
			--remove one FROM the counter...we do NOT want this message to page
			SET @change_count = @change_count - 1
		END
		IF @msg <> '' 
		BEGIN
		
			--check IF the database is being mirrored.
			--IF mirroring_status = 4 AND databasepropertyex(@name, 'status')) = restoring
			--IF yes - ignore the message
		
			IF EXISTS (SELECT	entity_name 
			FROM	GLIDE.dbo.entity_settings 
			WHERE	entity_type = 'database'
			AND		setting = 'ignore_status_change'
			AND		value = 'n'
			AND		entity_name = @name)
			
				PRINT 'CRITICAL : ' + @@SERVERNAME + ' : ' + @msg
			
			ELSE
				PRINT @name + ' ignored due to entity settings.'
				PRINT 'INFO : ' + @@SERVERNAME + ' : ' + @msg
			
			SET @change_count = @change_count + 1

			DELETE FROM dbo.db_status WHERE name = @name
		END

		FETCH NEXT FROM table_cursor_1 INTO
			@name,
			@isinstandby,
			@status,
			@useraccess,
			@updateability
	END -- WHILE

	CLOSE table_cursor_1
	DEALLOCATE table_cursor_1


	--list the databases created IN the last 24 hours
	IF EXISTS (SELECT 'x' FROM master.dbo.sysdatabases WHERE crdate > DATEADD(hh,-24,GETDATE()) AND name <> 'tempdb') 			
	BEGIN
		DECLARE @l_str_tmp VARCHAR(6000)
		SELECT @l_str_tmp = coalesce(@l_str_tmp + ', ', '') + name FROM master.dbo.sysdatabases WHERE crdate > DATEADD(hh,-24,GETDATE())		
		PRINT 'WARNING : ' + @@SERVERNAME + ': ' + CAST(@@rowcount AS VARCHAR(3)) + ' new databases added in the last 24 hours [' + @l_str_tmp + ']'
	END
	
	INSERT INTO dbo.db_status (
		name,
		isinstandby,
		status,
		updateability,
		useraccess		
	) SELECT a.name,
		CONVERT(BIT, databasepropertyex(a.name, 'isinstandby')),
		CONVERT(VARCHAR(20), databasepropertyex(a.name, 'status')),
		CONVERT(VARCHAR(20), databasepropertyex(a.name, 'updateability')),
		CONVERT(VARCHAR(20), databasepropertyex(a.name, 'useraccess'))
	FROM master.dbo.sysdatabases a
	WHERE NOT EXISTS (
		SELECT * FROM dbo.db_status b
		WHERE a.name COLLATE DATABASE_DEFAULT = b.name COLLATE DATABASE_DEFAULT
		)
		
	IF @change_count = 0
	BEGIN
		PRINT 'OKAY'
	END
	ELSE
	BEGIN		
		IF (@lintalert = 1)
		BEGIN
			IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'escalate_status'))) = 'y')
				SELECT dbo.uf_send_error ('CRITICAL','database status change detected',GETDATE())	--only raise error IF database has changed status
			ELSE
				SELECT dbo.uf_send_error ('WARNING','database status change detected',GETDATE())	--only raise error IF database has changed status
			
		END
	END
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_database_options'
GO
--------------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_database_options]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_database_options]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_database_options]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_database_options
* version  :  1.0 
* created  :  graham smith (GLIDE australia), 09-june-2009
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  warns when database options have changed
*
* output   :  populates TABLE db_options 
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters IN GLIDE db
*															AND standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
*	24-07-08	andre hoorenman	version 2.3 - added raiserror for logchecker automation
*
*	16-09-08	graham smith	version 2.4 - changed raise error to CRITICAL/WARNING for hvt
*
*	25-03-09	graham smith	version 2.5 - new entity setting to allow escalation to CRITICAL
*
*	02-04-09	graham smith	version 2.6 - new check for database encryption AND encryption certificates
*
*	23-04-09	graham smith	version 2.7 - check for new databases AND raise WARNING to the report
*
*	23-04-09	graham smith	version 1.0 - database switches only (branched FROM 2.7 of up_daily_report_config_options)
***********************************************************************/

AS
BEGIN
	SET NOCOUNT ON

	DECLARE	
		@msg				VARCHAR(4000),
		@change_count		INT,
		@currentnodename	VARCHAR(128),
		@crlf   			CHAR(2),
		@lstrmsg 			NVARCHAR(400),
		@lintalert			INT,

		-- databasepropertyex
		@name		 		VARCHAR(1000),
		@collation	 		VARCHAR(128),
		@isansinulldefault		BIT,
		@isansinullsenabled		BIT,
		@isansipaddingenabled	 	BIT,
		@isansiwarningsenabled	 	BIT,
		@isarithmeticabortenabled	BIT,
		@isautoclose	 		BIT,
		@isautocreatestatistics	 	BIT,
		@isautoshrink	 		BIT,
		@isautoupdatestatistics	 	BIT,
		@isclosecursorsoncommitenabled	BIT,
		@isfulltextenabled	 	BIT,
		@islocalcursorsdefault	 	BIT,
		@ismergepublished	 	BIT,
		@isnullconcat	 		BIT,
		@isnumericroundabortenabled	BIT,
		@isquotedidentifiersenabled	BIT,
		@isrecursivetriggersenabled	BIT,
		@issubscribed	 		BIT,
		@istornpagedetectionenabled	BIT,
		@recovery	 		VARCHAR(20),
		@sqlsortorder	 		VARCHAR(20),				
		@l_int_encrypt_keys	INT,
		@l_int_encrypt_cert	INT
		
	SET @change_count = 0
	SET @crlf = CHAR(13) + CHAR(10)

	-- database options

	DECLARE table_cursor_1 CURSOR FOR
	SELECT  name,
		collation,
		isansinulldefault,
		isansinullsenabled,
		isansipaddingenabled,
		isansiwarningsenabled,
		isarithmeticabortenabled,
		isautoclose,
		isautocreatestatistics,
		isautoshrink,
		isautoupdatestatistics,
		isclosecursorsoncommitenabled,
		isfulltextenabled,		
		islocalcursorsdefault,
		ismergepublished,
		isnullconcat,
		isnumericroundabortenabled,
		isquotedidentifiersenabled,
		isrecursivetriggersenabled,
		issubscribed,
		istornpagedetectionenabled,
		recovery,
		sqlsortorder,
		encryption_keys,
		encryption_certificates
	FROM dbo.db_options
	OPEN table_cursor_1

	FETCH NEXT FROM table_cursor_1 INTO
		@name,
		@collation,
		@isansinulldefault,
		@isansinullsenabled,
		@isansipaddingenabled,
		@isansiwarningsenabled,
		@isarithmeticabortenabled,
		@isautoclose,
		@isautocreatestatistics,
		@isautoshrink,
		@isautoupdatestatistics,
		@isclosecursorsoncommitenabled,
		@isfulltextenabled,		
		@islocalcursorsdefault,
		@ismergepublished,
		@isnullconcat,
		@isnumericroundabortenabled,
		@isquotedidentifiersenabled,
		@isrecursivetriggersenabled,
		@issubscribed,
		@istornpagedetectionenabled,
		@recovery,
		@sqlsortorder,		
		@l_int_encrypt_keys,
		@l_int_encrypt_cert

	WHILE @@FETCH_STATUS = 0
	BEGIN			
		SET @msg = ''
		IF EXISTS (SELECT 'x' FROM GLIDE.dbo.valid_databases WHERE name = @name)
		BEGIN			
			IF isnull(CONVERT(VARCHAR, databasepropertyex(@name,   'collation')), 'NULL')	<> @collation 				SET @msg = @msg + ' collation: '  			+ isnull(CONVERT(VARCHAR, @collation), 'NULL')	+ '->' + isnull(CONVERT(VARCHAR, databasepropertyex(@name, 'collation')), 'NULL')	+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isansinulldefault')) 		<> @isansinulldefault			SET @msg = @msg + ' isansinulldefault: '  		+ CONVERT(CHAR(1), @isansinulldefault)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isansinulldefault')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isansinullsenabled'))		<> @isansinullsenabled			SET @msg = @msg + ' isansinullsenabled: '  		+ CONVERT(CHAR(1), @isansinullsenabled)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isansinullsenabled')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isansipaddingenabled'))		<> @isansipaddingenabled		SET @msg = @msg + ' isansipaddingenabled: '		+ CONVERT(CHAR(1), @isansipaddingenabled)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isansipaddingenabled'))		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isansiwarningsenabled'))	 	<> @isansiwarningsenabled		SET @msg = @msg + ' isansiwarningsenabled: '  		+ CONVERT(CHAR(1), @isansiwarningsenabled)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isansiwarningsenabled')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isarithmeticabortenabled')) 		<> @isarithmeticabortenabled		SET @msg = @msg + ' isarithmeticabortenabled: '  	+ CONVERT(CHAR(1), @isarithmeticabortenabled) 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isarithmeticabortenabled')) 	+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isautoclose'))			<> @isautoclose				SET @msg = @msg + ' isautoclose: '  			+ CONVERT(CHAR(1), @isautoclose)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isautoclose')) 			+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isautocreatestatistics'))		<> @isautocreatestatistics		SET @msg = @msg + ' isautocreatestatistics: '  		+ CONVERT(CHAR(1), @isautocreatestatistics)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isautocreatestatistics')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isautoshrink')) 			<> @isautoshrink			SET @msg = @msg + ' isautoshrink: '  			+ CONVERT(CHAR(1), @isautoshrink)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isautoshrink')) 			+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isautoupdatestatistics')) 		<> @isautoupdatestatistics		SET @msg = @msg + ' isautoupdatestatistics: '  		+ CONVERT(CHAR(1), @isautoupdatestatistics)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isautoupdatestatistics')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isclosecursorsoncommitenabled')) 	<> @isclosecursorsoncommitenabled	SET @msg = @msg + ' isclosecursorsoncommitenabled: '	+ CONVERT(CHAR(1), @isclosecursorsoncommitenabled) + '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isclosecursorsoncommitenabled')) + @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isfulltextenabled')) 		<> @isfulltextenabled			SET @msg = @msg + ' isfulltextenabled: '  		+ CONVERT(CHAR(1), @isfulltextenabled)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isfulltextenabled')) 		+ @crlf			
			IF CONVERT(BIT, databasepropertyex(@name, 'islocalcursorsdefault')) 		<> @islocalcursorsdefault		SET @msg = @msg + ' islocalcursorsdefault: '  		+ CONVERT(CHAR(1), @islocalcursorsdefault) 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'islocalcursorsdefault')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'ismergepublished')) 			<> @ismergepublished			SET @msg = @msg + ' ismergepublished: '  		+ CONVERT(CHAR(1), @ismergepublished)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'ismergepublished')) 		+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isnullconcat')) 			<> @isnullconcat			SET @msg = @msg + ' isnullconcat: '  			+ CONVERT(CHAR(1), @isnullconcat)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isnullconcat')) 			+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isnumericroundabortenabled')) 	<> @isnumericroundabortenabled		SET @msg = @msg + ' isnumericroundabortenabled: '  	+ CONVERT(CHAR(1), @isnumericroundabortenabled)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isnumericroundabortenabled')) 	+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isquotedidentifiersenabled')) 	<> @isquotedidentifiersenabled		SET @msg = @msg + ' isquotedidentifiersenabled: '  	+ CONVERT(CHAR(1), @isquotedidentifiersenabled)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isquotedidentifiersenabled')) 	+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'isrecursivetriggersenabled')) 	<> @isrecursivetriggersenabled		SET @msg = @msg + ' isrecursivetriggersenabled: '  	+ CONVERT(CHAR(1), @isrecursivetriggersenabled)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'isrecursivetriggersenabled')) 	+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'issubscribed')) 			<> @issubscribed			SET @msg = @msg + ' issubscribed: '  			+ CONVERT(CHAR(1), @issubscribed)	 	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'issubscribed')) 			+ @crlf
			IF CONVERT(BIT, databasepropertyex(@name, 'istornpagedetectionenabled')) 	<> @istornpagedetectionenabled		SET @msg = @msg + ' istornpagedetectionenabled: '  	+ CONVERT(CHAR(1), @istornpagedetectionenabled)	+ '->' + CONVERT(CHAR(1), databasepropertyex(@name, 'istornpagedetectionenabled')) 	+ @crlf
			IF CONVERT(VARCHAR(20), databasepropertyex(@name, 'recovery')) 			<> @recovery				SET @msg = @msg + ' recovery: '  			+ @recovery	 				+ '->' + CONVERT(VARCHAR(20), databasepropertyex(@name, 'recovery')) 			+ @crlf
			IF isnull(CONVERT(VARCHAR(20), databasepropertyex(@name, 'sqlsortorder')), 'NULL') <> @sqlsortorder			SET @msg = @msg + ' sqlsortorder: '  			+ isnull(@sqlsortorder, 'NULL')			+ '->' + isnull(CONVERT(VARCHAR(20), databasepropertyex(@name, 'sqlsortorder')), 'NULL')+ @crlf
			
			--check IF this is a sql 2005 OR above box i.e. encryption is enabled
			IF EXISTS (SELECT 'x' WHERE SUBSTRING(CONVERT(VARCHAR(128), serverproperty('productversion')),1,CHARINDEX('.',CONVERT(VARCHAR(128), serverproperty('productversion')))-1) >= 9)--sql 2005 AND above
			BEGIN					
				--to check the encryption we need to do this against the current database so require a use command AND execute sql
				DECLARE @l_str_sql NVARCHAR(4000)
				DECLARE @l_tmp_lastmod VARCHAR(1)
				DECLARE	@l_tmp_encrypt_keys	INT
				DECLARE @l_tmp_encrypt_cert	INT
				DECLARE @l_tbl_encrypt TABLE
				(
				  databasename	VARCHAR(256),
				  hasencryption	INT,
				  numcertificates	INT			  
				)
				
				SELECT	@l_str_sql =  N'SELECT	@o_int_encrypt_keys = count(k.name)				--get the TABLE name
										FROM	' + QUOTENAME(@name) + N'.sys.symmetric_keys AS k
										
										SELECT	@o_int_encrypt_cert = count(c.name)
										FROM	' +QUOTENAME( @name) + N'.sys.certificates AS c 
										
										SELECT	@o_str_lastmod = 1
										FROM	sys.symmetric_keys 
										WHERE	modify_date > DATEADD(hour,-24,GETDATE()) 
										AND		create_date <> modify_date'
						
				EXEC sp_executesql	@l_str_sql,										--sql code
									N'@o_int_encrypt_keys	INT output,			--output parameters to be used in the statement
									@o_int_encrypt_cert	INT output,
									@o_str_lastmod	VARCHAR(1) output',
									
									@o_int_encrypt_keys = @l_tmp_encrypt_keys output,				--parameters to get the values back
									@o_int_encrypt_cert = @l_tmp_encrypt_cert output,
									@o_str_lastmod = @l_tmp_lastmod output

				--stick the values INTO a temporary TABLE for later
				INSERT INTO @l_tbl_encrypt values (@name, @l_tmp_encrypt_keys,@l_tmp_encrypt_cert)
				IF @l_tmp_encrypt_keys  		<> @l_int_encrypt_keys				SET @msg = @msg + ' database encryption: '  			+ CAST(@l_int_encrypt_keys AS VARCHAR(1))					+ '->' + CAST(@l_tmp_encrypt_keys AS VARCHAR(1))	 			+ @crlf
				IF @l_tmp_encrypt_cert  		<> @l_int_encrypt_cert				SET @msg = @msg + ' encryption certificate count: '  			+ CAST(@l_int_encrypt_cert AS VARCHAR(3))				+ '->' +  CAST(@l_tmp_encrypt_cert AS VARCHAR(1)) 			+ @crlf
				IF @l_tmp_lastmod 		= 1 SET @msg = @msg + ' service master key has been recreated in the last 24 hour. key requires backing up.' + @crlf
			END
		END
		
		IF @msg <> '' BEGIN
			SET @msg = 'found changed options for database ' + @name + ': ' + @crlf + @msg

			PRINT 'WARNING : ' + @@SERVERNAME + ': '+@msg

			SET @change_count = @change_count + 1

			DELETE FROM dbo.db_options WHERE name = @name
		END

		FETCH NEXT FROM table_cursor_1 INTO
			@name,
			@collation,
			@isansinulldefault,
			@isansinullsenabled,
			@isansipaddingenabled,
			@isansiwarningsenabled,
			@isarithmeticabortenabled,
			@isautoclose,
			@isautocreatestatistics,
			@isautoshrink,
			@isautoupdatestatistics,
			@isclosecursorsoncommitenabled,
			@isfulltextenabled,			
			@islocalcursorsdefault,
			@ismergepublished,
			@isnullconcat,
			@isnumericroundabortenabled,
			@isquotedidentifiersenabled,
			@isrecursivetriggersenabled,
			@issubscribed,
			@istornpagedetectionenabled,
			@recovery,
			@sqlsortorder,
			@l_int_encrypt_keys,
			@l_int_encrypt_cert
	END -- WHILE

	CLOSE table_cursor_1
	DEALLOCATE table_cursor_1
	
	INSERT INTO dbo.db_options (
		name,
		collation,
		isansinulldefault,
		isansinullsenabled,
		isansipaddingenabled,
		isansiwarningsenabled,
		isarithmeticabortenabled,
		isautoclose,
		isautocreatestatistics,
		isautoshrink,
		isautoupdatestatistics,
		isclosecursorsoncommitenabled,
		isfulltextenabled,		
		islocalcursorsdefault,
		ismergepublished,
		isnullconcat,
		isnumericroundabortenabled,
		isquotedidentifiersenabled,
		isrecursivetriggersenabled,
		issubscribed,
		istornpagedetectionenabled,
		recovery,
		sqlsortorder
	) SELECT a.name,
		isnull(CONVERT(VARCHAR, databasepropertyex(a.name, 'collation')), 'NULL'),
		CONVERT(BIT, databasepropertyex(a.name, 'isansinulldefault')),
		CONVERT(BIT, databasepropertyex(a.name, 'isansinullsenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isansipaddingenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isansiwarningsenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isarithmeticabortenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isautoclose')),
		CONVERT(BIT, databasepropertyex(a.name, 'isautocreatestatistics')),
		CONVERT(BIT, databasepropertyex(a.name, 'isautoshrink')),
		CONVERT(BIT, databasepropertyex(a.name, 'isautoupdatestatistics')),
		CONVERT(BIT, databasepropertyex(a.name, 'isclosecursorsoncommitenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isfulltextenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'islocalcursorsdefault')),
		CONVERT(BIT, databasepropertyex(a.name, 'ismergepublished')),
		CONVERT(BIT, databasepropertyex(a.name, 'isnullconcat')),
		CONVERT(BIT, databasepropertyex(a.name, 'isnumericroundabortenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isquotedidentifiersenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'isrecursivetriggersenabled')),
		CONVERT(BIT, databasepropertyex(a.name, 'issubscribed')),
		CONVERT(BIT, databasepropertyex(a.name, 'istornpagedetectionenabled')),
		CONVERT(VARCHAR(20), databasepropertyex(a.name, 'recovery')),
		isnull(CONVERT(VARCHAR(20), databasepropertyex(a.name, 'sqlsortorder')), 'NULL')
	FROM master.dbo.sysdatabases a
	WHERE NOT EXISTS (
		SELECT * FROM dbo.db_options b
		WHERE a.name COLLATE DATABASE_DEFAULT = b.name COLLATE DATABASE_DEFAULT
		)

	IF EXISTS (SELECT 'x' WHERE SUBSTRING(CONVERT(VARCHAR(128), serverproperty('productversion')),1,CHARINDEX('.',CONVERT(VARCHAR(128), serverproperty('productversion')))-1) >= 9)--sql 2005 AND above
		BEGIN				
			--populate the dboptions TABLE with the encryption values IF we got them
			UPDATE	GLIDE.dbo.db_options
			SET		encryption_keys = e.hasencryption,
					encryption_certificates = e.numcertificates
			FROM	GLIDE.dbo.db_options o,
					@l_tbl_encrypt e
			WHERE	e.databasename = o.name						
		END
		
	IF @change_count = 0
	BEGIN
		PRINT 'OKAY'
	END
	ELSE
	BEGIN		
		IF (@lintalert = 1)
		BEGIN
			IF (dbo.uf_get_setting('check', 'uf_send_error', 'check_enabled')) = 'y'
			BEGIN
			SELECT dbo.uf_send_error ('WARNING','database configuration option change detected',GETDATE())	--only raise error IF database has changed status
	END
END
	END
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_server_options'
GO
--------------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_server_options]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_server_options]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_server_options]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_server_options
* version  :  1.0 
* created  :  graham smith (GLIDE australia), 09-june-2009
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  warns when database options have changed
*
* output   :  populates TABLE db_options 
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters in GLIDE db
*															and standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
*	24-07-08	andre hoorenman	version 2.3 - added raiserror for logchecker automation
*
*	16-09-08	graham smith	version 2.4 - changed raise error to CRITICAL/WARNING for hvt
*
*	25-03-09	graham smith	version 2.5 - new entity setting to allow escalation to CRITICAL
*
*	02-04-09	graham smith	version 2.6 - new check for database encryption and encryption certificates
*
*	23-04-09	graham smith	version 2.7 - check for new databases and raise WARNING to the report
*
*	23-04-09	graham smith	version 1.0 - server only PROCEDURE (branched FROM 2.7 of up_daily_report_config_options)
***********************************************************************/

AS
BEGIN
	SET NOCOUNT ON

	DECLARE	
		@msg				VARCHAR(4000),
		@change_count		INT,
		@currentnodename	VARCHAR(128),
		@crlf   			CHAR(2),
		@lstrmsg 			NVARCHAR(400),
		
		-- serverproperties
		@edition 			VARCHAR(128),
		@collation	 		VARCHAR(128),
		@isclustered 			BIT,
		@isfulltextinstalled 		BIT,
		@isintegratedsecurityonly 	BIT,
		@issingleuser 			BIT,
		@licensetype			VARCHAR(128),
		@machinename 			VARCHAR(128),
		@numlicenses 			VARCHAR(10),
		@productversion 		VARCHAR(128),
		@productlevel 			VARCHAR(128),
		@servername 			VARCHAR(128),
		@clusteractivenodename		VARCHAR(128)

	SET @change_count = 0
	SET @crlf = CHAR(13) + CHAR(10)

	-- server options

	-- IF a cluster, get current node
	IF serverproperty('isclustered') = 1  -- sql server is clustered
	BEGIN
		IF EXISTS (SELECT 'x' WHERE SUBSTRING(CONVERT(VARCHAR(128), serverproperty('productversion')),1,CHARINDEX('.',CONVERT(VARCHAR(128), serverproperty('productversion')))-1) >= 9)--sql 2005 AND above
		BEGIN
			SELECT @currentnodename = CONVERT(VARCHAR(128), serverproperty('computernamephysicalnetbios')) --changed to use sql 2005 FUNCTION
		END
	END
	ELSE
	BEGIN
		SET @currentnodename = 'NULL'
	END
	SELECT	@collation		=	collation,
		@edition		=	edition,
		@isclustered		=	isclustered,
		@isfulltextinstalled	=	isfulltextinstalled,
		@isintegratedsecurityonly =	isintegratedsecurityonly,
		@issingleuser		=	issingleuser,
		@licensetype		=	licensetype,
		@machinename		=	machinename,
		@numlicenses		=	numlicenses,
		@productversion		=	productversion,
		@productlevel		=	productlevel,
		@servername		=	servername,
		@clusteractivenodename	=	clusteractivenodename
	FROM dbo.server_options

	IF @@rowcount = 1
	BEGIN
		SET @msg = ''

		IF CONVERT(VARCHAR, serverproperty('collation')) 		<> @collation			SET @msg = @msg + ' collation: ' 		+ @collation				+ '->' + CONVERT(VARCHAR, serverproperty('collation')) 				+ @crlf
		IF CONVERT(VARCHAR(128), serverproperty('edition')) 		<> @edition			SET @msg = @msg + ' edition: ' 			+ @edition				+ '->' + CONVERT(VARCHAR(128), serverproperty('edition')) 			+ @crlf
		IF CONVERT(INT, serverproperty('isclustered')) 			<> @isclustered			SET @msg = @msg + ' isclustered: ' 		+ CONVERT(CHAR(1), @isclustered)	+ '->' + CONVERT(CHAR(1), serverproperty('isclustered')) 			+ @crlf
		IF CONVERT(INT, serverproperty('isfulltextinstalled')) 		<> @isfulltextinstalled		SET @msg = @msg + ' isfulltextinstalled: ' 	+ CONVERT(CHAR(1), @isfulltextinstalled)+ '->' + CONVERT(CHAR(1), serverproperty('isfulltextinstalled')) 		+ @crlf
		IF CONVERT(INT, serverproperty('isintegratedsecurityonly'))	<> @isintegratedsecurityonly 	SET @msg = @msg + ' isintegratedsecurityonly: ' + CONVERT(CHAR(1), @isintegratedsecurityonly) + '->' + CONVERT(CHAR(1), serverproperty('isintegratedsecurityonly')) 	+ @crlf
		IF CONVERT(INT, serverproperty('issingleuser')) 		<> @issingleuser		SET @msg = @msg + ' issingleuser: ' 		+ CONVERT(CHAR(1), @issingleuser)	+ '->' + CONVERT(CHAR(1), serverproperty('issingleuser')) 			+ @crlf
		IF CONVERT(VARCHAR(128), serverproperty('licensetype')) 	<> @licensetype			SET @msg = @msg + ' licensetype: ' 		+ @licensetype				+ '->' + CONVERT(VARCHAR(128), serverproperty('licensetype')) 			+ @crlf
		IF CONVERT(VARCHAR(128), serverproperty('machinename')) 	<> @machinename			SET @msg = @msg + ' machinename: ' 		+ @machinename				+ '->' + CONVERT(VARCHAR(128), serverproperty('machinename')) 			+ @crlf
		IF isnull(CONVERT(VARCHAR(10), serverproperty('numlicenses')), 'NULL') <> @numlicenses		SET @msg = @msg + ' numlicenses: ' 		+ CONVERT(VARCHAR(6), @numlicenses)	+ '->' + isnull(CONVERT(VARCHAR(10), serverproperty('numlicenses')), 'NULL')	+ @crlf
		IF CONVERT(VARCHAR(128), serverproperty('productversion')) 	<> @productversion		SET @msg = @msg + ' productversion: '	 	+ @productversion			+ '->' + CONVERT(VARCHAR(128), serverproperty('productversion')) 		+ @crlf
		IF CONVERT(VARCHAR(128), serverproperty('productlevel')) 	<> @productlevel		SET @msg = @msg + ' productlevel: ' 		+ @productlevel				+ '->' + CONVERT(VARCHAR(128), serverproperty('productlevel')) 			+ @crlf
		IF CONVERT(VARCHAR(128), serverproperty('servername')) 		<> @servername			SET @msg = @msg + ' servername: ' 		+ @servername				+ '->' + CONVERT(VARCHAR(128), serverproperty('servername')) 			+ @crlf

	--		warn when a node change (i.e. failover) has been detected.
		IF @isclustered = 1  -- sql server is clustered
			IF @currentnodename <> @clusteractivenodename SET @msg = @msg + ' clusteractivenodename: ' + @clusteractivenodename + '->' + @currentnodename + @crlf

		IF @msg <> '' BEGIN
			SET @msg = 'found changed options for server instance: ' + @crlf + @msg
			PRINT 'WARNING : ' + @@SERVERNAME + ': '+@msg

			SET @change_count = @change_count + 1

			DELETE FROM dbo.server_options
		END
	END
		
	IF NOT EXISTS (SELECT * FROM dbo.server_options)
		INSERT INTO dbo.server_options (
			collation,
			edition,
			isclustered,
			isfulltextinstalled,
			isintegratedsecurityonly,
			issingleuser,
			licensetype,
			machinename,
			numlicenses,
			productversion,
			productlevel,
			servername,
			clusteractivenodename
		) values (CONVERT(VARCHAR, serverproperty('collation')),
			CONVERT(VARCHAR(128), serverproperty('edition')),
			CONVERT(BIT, serverproperty('isclustered')),
			CONVERT(BIT, serverproperty('isfulltextinstalled')),
			CONVERT(BIT, serverproperty('isintegratedsecurityonly')),
			CONVERT(BIT, serverproperty('issingleuser')),
			CONVERT(VARCHAR(128), serverproperty('licensetype')),
			CONVERT(VARCHAR(128), serverproperty('machinename')),
			isnull(CONVERT(VARCHAR(10), serverproperty('numlicenses')), 'NULL'),
			CONVERT(VARCHAR(128), serverproperty('productversion')),
			CONVERT(VARCHAR(128), serverproperty('productlevel')),
			CONVERT(VARCHAR(128), serverproperty('servername')),
			@currentnodename
		)

	IF @change_count = 0
	BEGIN
		PRINT 'OKAY'
	END
	ELSE
	BEGIN		
		IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'escalate_server'))) = 'y')
			SELECT dbo.uf_send_error ('CRITICAL','server/database configuration option change detected',GETDATE())
		ELSE
			SELECT dbo.uf_send_error ('WARNING','server/database configuration option change detected',GETDATE())	
	END
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_db_backup'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_db_backup]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_db_backup]
GO

PRINT 'recreate up_daily_report_long_running'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_long_running]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_long_running]
GO
--------------------------------------------------------------------

CREATE PROCEDURE [dbo].[up_daily_report_long_running]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_long_running
* version  :  2.5
* created  :  doug irwin (GLIDE australia), 29-feb-2008
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  report ON jobs running more that the allowed time
*
* output   :  n/a
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters in GLIDE db
*															AND standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
*   24-07-08	andre hoorenman	version 2.3 - added raiserror for logchecker automation
*
*   07-08-08	andre hoorenman	version 2.4 - added max_runtime_hours to entity settings
*
*	16-09-08	graham smith	version 2.5 - changed raise error to CRITICAL/WARNING for hvt
***********************************************************************/

AS
BEGIN

	DECLARE @job_id			uniqueidentifier,
		@job_name		VARCHAR(1000),
		@process_id		CHAR(8),
		@job_id_char		CHAR(8),
		@minutes_allowed	INT,
		@minutes_running 	INT,
		@long_run_count		INT,
		@msg			VARCHAR(1000),
		@lstrmsg 	NVARCHAR(400)

	SET NOCOUNT ON
	SET @long_run_count = 0

	DECLARE job_cursor CURSOR FOR
		SELECT 	name,
			job_id
		FROM 	msdb..sysjobs

	OPEN job_cursor

	FETCH NEXT FROM job_cursor INTO @job_name, @job_id

	WHILE @@FETCH_STATUS = 0
	BEGIN

		SELECT @job_id_char = SUBSTRING(CAST(@job_id AS CHAR(50)),1,8)

		SELECT @process_id = 	SUBSTRING(@job_id_char,7,2) +
					SUBSTRING(@job_id_char,5,2) +
					SUBSTRING(@job_id_char,3,2) +
					SUBSTRING(@job_id_char,1,2)

		SET @minutes_running = 0 -- default value if job NOT running

		SELECT @minutes_running = DATEDIFF(minute,last_batch, GETDATE())
		FROM master..sysprocesses
		WHERE program_name LIKE ('%0x' + @process_id +'%')

		EXEC up_check_settings 'job', @job_name

		SET @minutes_allowed = CAST(dbo.uf_get_setting('job', @job_name, 'max_runtime_hours') AS INT) * 60

		IF @minutes_allowed != 0  -- i.e. infinite runtime NOT SET
		BEGIN

		IF @minutes_running > @minutes_allowed

		BEGIN


			SELECT 	@msg = ('WARNING : '+@@SERVERNAME+': job: '
				+ SUBSTRING(@job_name,1,LEN(@job_name))
				+ ' - has been running for '
				+ SUBSTRING(CAST(@minutes_running AS CHAR(5)),1,LEN(CAST(@minutes_running AS CHAR(5))))
				+ ' minutes. this is over the allowed run time of '
				+ SUBSTRING(CAST(@minutes_allowed AS CHAR(5)),1,LEN(CAST(@minutes_allowed AS CHAR(5))))
				+ ' minutes.')

			PRINT @msg

			SET @long_run_count = @long_run_count + 1
		END
		END
		FETCH NEXT FROM job_cursor INTO @job_name, @job_id
	END

	CLOSE job_cursor
	DEALLOCATE job_cursor

	IF @long_run_count = 0
	BEGIN
		PRINT 'OKAY'
	END
	ELSE
	BEGIN
		SELECT dbo.uf_send_error ('information','long running jobs detected',GETDATE())
	END
END

GO

--------------------------------------------------------------------
PRINT 'recreate up_daily_report_uptime'
GO
--------------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_uptime]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_uptime]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_uptime]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_uptime
* version  :  2.5
* created  :  doug irwin (GLIDE australia), 29-feb-2008
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  displays sql server version and edition, windows version,
*	       sql server start time and how long it has been running.
*	       warns IF sql server has been started within the last 24 hours.
*
* output   :
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters in GLIDE db
*															and standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
*	24-07-08	andre hoorenman	version 2.3 - added raiserror for logchecker automation
*
*	16-09-08	graham smith	version 2.4 - changed raise error to CRITICAL/WARNING for hvt
*
*	23-04-09	graham smith	version 2.5 - added entity setting to allow supression of server reboots
***********************************************************************/

AS
BEGIN
	DECLARE	@version 	VARCHAR(1000),
		@edition 	VARCHAR(1000),
		@curr_date 	DATETIME,
		@date0		DATETIME,
		@days		INT,
		@hours		INT,
		@minutes	INT,
		@uptime		VARCHAR(256),
		@lstrmsg 	NVARCHAR(400)

	SET NOCOUNT ON

	--	display the sql server version, edition AND windows version
	SELECT @version = LEFT(REPLACE(@@version, CHAR(9), ''), 1000)
	SELECT @edition = right(@version, CHARINDEX(CHAR(10), reverse(@version), 2) - 1)
	SELECT @edition = space(5) + LEFT(@edition, LEN(@edition) - 1)
	SELECT @version = LEFT(@version, CHARINDEX(CHAR(10), @version) - 1)

	PRINT @version
	PRINT @edition
	PRINT ''

	--	display server start time AND uptime
	SELECT 	@uptime = 'sql server was started on ' +
		CAST(crdate AS VARCHAR) + '.'
	FROM master.dbo.sysdatabases WHERE name = 'tempdb'
	PRINT @uptime

	SELECT 	@date0 = crdate	FROM master.dbo.sysdatabases WHERE name = 'tempdb'
	SELECT 	@curr_date = GETDATE()

	SELECT @days = DATEDIFF(dd, @date0, @curr_date)
	SELECT @hours = DATEPART (hh, @curr_date) - DATEPART (hh, @date0)
	SELECT @minutes = DATEPART (mi, @curr_date) - DATEPART (mi, @date0)

	IF @minutes < 0 BEGIN
		SELECT @minutes = @minutes + 60
		SELECT @hours = @hours - 1
	END

	IF @hours < 0 BEGIN
		SELECT @hours = @hours + 24
		SELECT @days = @days - 1
	END

	SELECT @uptime = space(5) + 'it has been running for '
		+ CONVERT(VARCHAR, @days) + ' days '
		+ CONVERT(VARCHAR, @hours) + ' hrs '
		+ CONVERT(VARCHAR, @minutes) + ' mins.'
	PRINT @uptime

	--	display WARNING message IF sql server has been restarted IN last 24 hours AND we are NOT supressing errors
	IF @days = 0 AND UPPER(LEFT(LTRIM(dbo.uf_get_setting('server', '', 'supress_reboot')),1)) = 'n'
	BEGIN
		PRINT 'WARNING : '+@@SERVERNAME+': sql server has been started in the last 24 hours.'				
	END
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_extra_modules'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_extra_modules]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_extra_modules]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_extra_modules]
	--with encryption
/**********************************************************************
*
* script   :  up_daily_report_extra_modules
* version  :  2.2
* created  :  doug irwin (GLIDE australia), 29-feb-2008
*
* usage    :  run from the up_run_daily_report_main sp.
*
* purpose  :  runs extra modules.
*
* output   :  status messages printed.
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   06-12-07	doug irwin      first version.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
***********************************************************************/

AS

BEGIN
	SET NOCOUNT ON
	DECLARE @msg VARCHAR(1000), @mname VARCHAR(1000), @mtype VARCHAR(1), @mod_count integer

	SELECT @mod_count = 0

	DECLARE module_curs CURSOR FOR
		SELECT module_name, module_type
		FROM dbo.extra_modules
		WHERE [is_enabled] = 'y'
		ORDER BY [module_order] DESC, [module_name] ASC

	OPEN module_curs

	FETCH NEXT FROM module_curs INTO @mname, @mtype

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @mtype = 'p' OR @mtype = 's'
		BEGIN
			EXEC(@mname)
		END
		ELSE
		BEGIN
			PRINT 'error: type ' + @mtype + ' for module ' + @mname + ' is unknown!'
		END

		SELECT @mod_count = @mod_count + 1

		FETCH NEXT FROM module_curs INTO @mname, @mtype
	END

	CLOSE module_curs
	DEALLOCATE module_curs

	IF @mod_count < 1
	BEGIN
		PRINT 'OKAY - no additional modules to execute'
	END
	ELSE
	BEGIN
		PRINT 'OKAY - executed '+CONVERT(VARCHAR(20), @mod_count)+' additional modules.'
	END

END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_cycle_errorlog'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_cycle_errorlog]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_cycle_errorlog]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_cycle_errorlog]
/**********************************************************************
*
* script   :  up_daily_report_cycle_errorlog
* version  :  2.2
* created  :  doug irwin (GLIDE australia), 29-feb-2008
*
* usage    :  run FROM the up_run_daily_report_main sp.
*
* purpose  :  cycles sql server error log IF its size greater than
*	       a specified limit
*
* output   :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   23-08-07	doug irwin      version 2.1 changes - parameters in GLIDE db
*															and standardised error/WARNING returns.
*   29-02-08  doug irwin      version 2.2 - first release version!
*
***********************************************************************/

AS

BEGIN
	SET NOCOUNT ON

	DECLARE @error_log_limit INT
	SELECT @error_log_limit = dbo.uf_get_setting('instance', '', 'error_log_limit')

	CREATE TABLE #log_info (
		archive INT,
		date_created DATETIME,
		file_size INT
	)

	INSERT INTO #log_info EXEC('sp_enumerrorlogs')

	DECLARE @file_size 		INT,
		@error_log_limit_kb 	INT,
		@cycled_msg		VARCHAR (80)

	SELECT @error_log_limit_kb = @error_log_limit * 1024 * 1024

	SELECT @file_size = file_size FROM #log_info WHERE archive = 0

	IF (@file_size > @error_log_limit_kb) AND (@error_log_limit_kb > 0)
	BEGIN

		EXEC sp_cycle_errorlog

		IF @@error = 0
			SET @cycled_msg = 'INFO    : errorlog cycled'
		ELSE
		BEGIN
			SET @cycled_msg = 'WARNING : '+@@SERVERNAME+': failed to cycle errorlog!'
		END

		PRINT @cycled_msg
	END
	ELSE
		IF @error_log_limit = 0
			PRINT 'errorlog not cycled AS less error_log_limit is 0'
		ELSE
			PRINT 'OKAY - errorlog did not need to be cycled.'
END
GO
--------------------------------------------------------------------

PRINT 'recreate up_daily_report_db_space'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_db_space]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_db_space]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_db_space]
		--with encryption
/**********************************************************************
*
* script   :  up_daily_report_db_space
* version  :  3.1
* created  :  graham smith (GLIDE australia), 14-sep-2009
*
* usage    :  run from the up_run_daily_report_main sp.
*
* purpose  :  checks database files for significant growth and compiles history
*
* output   :  populates tables db_filesize
* files    :  n/a
*
*
***********************************************************************
*                            modification log
***********************************************************************
*   date            programmer      description
*   ----            ----------      -----------
*   23-08-07    doug irwin      version 2.1 changes - parameters IN GLIDE db
*                                                                                                                       and standardised error/WARNING returns.
*   29-02-08  doug irwin                version 2.2 - first release version!
*
*       24-07-08        andre hoorenman version 2.3 - added raiserror for logchecker automation
*
*       16-09-08        graham smith    version 2.4 - changed raise error to CRITICAL/WARNING for hvt
*
*       14-09-09        graham smith    version 3.0 - complete rewrite to allow history and more detailed reporting and checking
*       28-03-19        charles zyzniewski    version 3.1 - fixed bug where a database size too large will cause an arithmetic overflow
***********************************************************************/
		
AS
BEGIN
		SET NOCOUNT ON
				--drop temp tables if they exist
		IF OBJECT_ID('tempdb.dbo.##tbl_combinedinfo', 'u') is NOT NULL
				DROP TABLE dbo.##tbl_combinedinfo;
		  
		IF OBJECT_ID('tempdb.dbo.##tbl_dbfilestats', 'u') is NOT NULL
				DROP TABLE dbo.##tbl_dbfilestats;
			
		IF OBJECT_ID('tempdb.dbo.##tbl_logs', 'u') is NOT NULL
				DROP TABLE dbo.##tbl_logs;

		--CREATE temp tables
		CREATE TABLE dbo.##tbl_combinedinfo 
		(
				databasename VARCHAR(1000) NULL, 
				[type] VARCHAR(10) NULL, 
				logicalname VARCHAR(1000) NULL,
				t float NULL,
				u float NULL,
				f float NULL,
				physicalname VARCHAR(1000) NULL 
		);

		CREATE TABLE dbo.##tbl_dbfilestats 
		(
				id INT identity, 
				databasename VARCHAR(1000) NULL, 
				fileid INT NULL, 
				filegroup INT NULL, 
				totalextents bigint NULL, 
				usedextents bigint NULL, 
				name VARCHAR(1000) NULL, 
				filename VARCHAR(1000) NULL 
		);
		  
		CREATE TABLE dbo.##tbl_logs 
		(
				databasename VARCHAR(1000) NULL, 
				logsize float NULL, 
				logspaceusedpercent float NULL,
				status INT NULL 
		);

		--create variables used to loop through databases and values
		DECLARE @ver VARCHAR(10), 
						@databasename VARCHAR(1000), 
						@ident_last INT, 
						@string VARCHAR(2000),
						@basestring VARCHAR(2000);
				
		SELECT @databasename = '', 
				   @ident_last = 0, 
				   @string = '', 
				   @ver = case when @@version LIKE '%9.0%' then 'sql 2005' 
										   when @@version LIKE '%8.0%' then 'sql 2000' 
										   when @@version LIKE '%10.0%' then 'sql 2008' 
								  END;
					  
		SELECT  @basestring = 
		' SELECT db_name(), ' + 
		case when @ver = 'sql 2000' then 'case when status & 0x40 = 0x40 then ''log''  ELSE ''data'' END' 
		  ELSE ' case type when 0 then ''data'' when 1 then ''log'' when 4 then ''full-text'' ELSE ''reserved'' END' END + 
		', name, ' + 
		case when @ver = 'sql 2000' then 'filename' ELSE 'physical_name' END + 
		', size*8.0/1024.0 FROM ' + 
		case when @ver = 'sql 2000' then 'sysfiles' ELSE 'sys.database_files' END + 
		' WHERE '
		+ case when @ver = 'sql 2000' then ' has_dbaccess(db_name()) = 1' ELSE 'state_desc = ''online''' END + '';

		EXEC (@string);

		INSERT INTO dbo.##tbl_logs EXEC ('dbcc sqlperf (logspace) with no_infomsgs');

		--  for data part
		WHILE 1 = 1
				BEGIN
						SELECT top 1 @databasename = name FROM GLIDE.dbo.valid_databases WHERE name > @databasename ORDER BY name ASC;
						IF @@rowcount = 0
						  break;

						--confirm this database is accesible
						IF (has_dbaccess(@databasename) = 0)
								PRINT 'database ' + @databasename + ' is unaccesible for file size monitoring'                  
						ELSE
						BEGIN
								SELECT @ident_last = isnull(max(id), 0) FROM dbo.##tbl_dbfilestats;

								SELECT @string = 'INSERT INTO dbo.##tbl_combinedinfo (databasename, type, logicalname, physicalname, t) ' + @basestring; 

								EXEC ('use [' + @databasename + '] ' + @string);

								INSERT INTO dbo.##tbl_dbfilestats (fileid, filegroup, totalextents, usedextents, name, filename)
								EXEC ('use [' + @databasename + '] dbcc showfilestats with no_infomsgs');

								UPDATE dbo.##tbl_dbfilestats SET databasename = @databasename WHERE id between @ident_last + 1 AND @@identity;
						END
				END

		--  set used size for data files, do not change total obtained from sys.database_files as it has for log files
		UPDATE  dbo.##tbl_combinedinfo 
		SET             u = s.usedextents*8*8/1024.0 
		FROM    dbo.##tbl_combinedinfo t 
				JOIN    dbo.##tbl_dbfilestats s 
						ON      t.logicalname = s.name 
						AND     s.databasename = t.databasename;

		--  SET used size  for log files:
		UPDATE  dbo.##tbl_combinedinfo 
		SET             u = t * logspaceusedpercent/100.0
		FROM    dbo.##tbl_combinedinfo t 
				JOIN    dbo.##tbl_logs l 
						ON      l.databasename = t.databasename 
		WHERE   t.type = 'log';

		UPDATE  dbo.##tbl_combinedinfo 
		SET     u = isnull(u,0),
				f = t - isnull(u,0);

		--all calculations finished

		--drop todays results into the GLIDE database as long as they do not already exist for today
		IF NOT EXISTS (SELECT 'x' FROM GLIDE.dbo.db_filesize WHERE DATEADD(hour,-20,GETDATE()) < row_date)
		BEGIN 
				INSERT INTO GLIDE.dbo.db_filesize
				SELECT  databasename AS 'database',
								type AS 'type',
								logicalname,
								physicalname,
								t AS 'total',
								u AS 'used',      
								f AS 'free',
								GETDATE()
				FROM    dbo.##tbl_combinedinfo;
		END
		ELSE
				PRINT 'database size report already ran today.  using last set of data'

		--check growth levels
		DECLARE @l_str_msg VARCHAR(6000)
		--check IF datagrowth IN 24 hours has broken threashold
		SELECT  @l_str_msg = coalesce(@l_str_msg + CHAR(10) ,'') +'WARNING : ' + 
								@@SERVERNAME + 
								' database "' + a.dbname + '" ' + a.file_type + ' file ' + ' has grown by ' + 
								CAST(CAST(((c.t - a.total_size)/a.total_size) * 100 AS INT) AS VARCHAR(35)) + '% since ' + CAST(a.row_date AS VARCHAR(35)) + '. ' +
								CAST(a.total_size AS VARCHAR(15)) + 'mb to ' + CAST(c.t AS VARCHAR(15)) + 'mb.  ' + 
								CAST(c.f AS VARCHAR(15)) + 'mb unused space remaining in database file.'                        
				FROM GLIDE.dbo.db_filesize a
				INNER JOIN      dbo.##tbl_combinedinfo c
						ON      a.dbname = c.databasename
						AND a.physical_name = c.physicalname
				WHERE 
				--Check for Day, Week, Month AND Year
				(a.total_size <> 0 AND ((c.t - a.total_size)/a.total_size) * 100 > 30 AND DATEDIFF(hour,row_date,GETDATE()) < 25) 
				OR 
				(((c.t - a.total_size)/a.total_size) * 100 > 30 AND DATEDIFF(day,row_date,GETDATE()) < 8 AND DATEDIFF(day,row_date,GETDATE()) > 6)
				OR 
				(((c.t - a.total_size)/a.total_size) * 100 > 30 AND DATEDIFF(day,row_date,GETDATE()) < 31 AND DATEDIFF(day,row_date,GETDATE()) > 29)
				OR
				(((c.t - a.total_size)/a.total_size) * 100 > 30 AND DATEDIFF(day,row_date,GETDATE()) < 364 AND DATEDIFF(day,row_date,GETDATE()) > 366)  

		IF @l_str_msg is NOT NULL
		BEGIN
				--output the results but do not raise eon
				PRINT @l_str_msg
				SELECT dbo.uf_send_error ('information','significant database file growth detected',GETDATE())
		END
		ELSE
				PRINT 'INFO : ' +++ @@SERVERNAME + ' database file size ok'
				
				
		--DROP temp tables if they exist
		IF OBJECT_ID('tempdb.dbo.##tbl_combinedinfo', 'u') is NOT NULL
				DROP TABLE dbo.##tbl_combinedinfo;
		  
		IF OBJECT_ID('tempdb.dbo.##tbl_dbfilestats', 'u') is NOT NULL
				DROP TABLE dbo.##tbl_dbfilestats;
			
		IF OBJECT_ID('tempdb.dbo.##tbl_logs', 'u') is NOT NULL
				DROP TABLE dbo.##tbl_logs;

		--archiving
		IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'size_archive'))) = 'y')                       --check if the archive should be running
		BEGIN
				--run the archive procedure keep 14 days, 8 weeks, 12 months of data in archive. 
				IF DATENAME(weekday,GETDATE()) = 'sunday'                       --check if today is sunday
						BEGIN
								DELETE                                                                          --remove all the days last week but sunday
								FROM    GLIDE.dbo.db_filesize 
								WHERE   DATEPART(week,row_date)         =       DATEPART(week,DATEADD(week,-2,GETDATE()) )
								AND     DATENAME(weekday,row_date)      <>      'sunday'
						END     

				IF DATEPART(day,GETDATE()) = 1                                          --check if today is first of month
						BEGIN
								DELETE                                                                          --remove all the days last month but the 1st            
								FROM    GLIDE.dbo.db_filesize 
								WHERE   DATEPART(month,row_date)        =       DATEPART(month,DATEADD(month,-2,GETDATE()) )
								AND     DATEPART(day,row_date)          <>      1
						END     
						
				IF DATEPART(dayofyear,GETDATE()) = 1                            --check if today is first of year
						BEGIN
								DELETE                                                                          --remove all the entries last year but the 1st day
								FROM    GLIDE.dbo.db_filesize 
								WHERE   DATEPART(year,row_date)                 =       DATEPART(year,DATEADD(year,-1,GETDATE()) )
								AND             DATEPART(dayofyear,row_date)    <>      1
						END     
						
				DELETE                                                                                          --remove anything older than 5 years from the history completely
				FROM GLIDE.dbo.db_filesize
				WHERE row_date < DATEADD(year,-5,GETDATE())
		END
		ELSE
		BEGIN
				PRINT 'WARNING    : '+@@SERVERNAME + ' archive PROCEDURE is turned off for file growth stats'
		END     
END

--------------------------------------------------------------------
GO

PRINT 'adding extra modules INTO GLIDE'
use GLIDE
GO
PRINT 'recreate up_check_dbmail_status'
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_dbmail_status]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_check_dbmail_status]
GO

CREATE PROCEDURE [dbo].[up_check_dbmail_status]
/**********************************************************************
*
* script   :  up_check_dbmail_status
* version  :  1.0
* created  :  graham smith (GLIDE australia), 21-oct-2008
*
* usage    :  run from the extra modules sp within daily report.
*
* purpose  :  does a health check on dbmail checking
*					it is enabled
*					broker is running
*					settings have not been changed
*					mail is not failing
*
* output   :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   21-10-08	graham smith    version 1.0 - intial version
***********************************************************************/
	--with encryption
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @errors INT
	SELECT @errors = 0 --initialise the variable

	--check IF dbmail is enabled
	IF (SELECT is_broker_enabled FROM sys.databases WHERE name = 'msdb') = 0
		BEGIN
			PRINT 'WARNING : '+@@SERVERNAME+': database mail is disabled'
			SELECT @errors = 1
		END

	--check IF dbmail is running
	IF NOT EXISTS (SELECT name FROM msdb.sys.service_queues WHERE name = N'externalmailqueue' AND is_receive_enabled = 1)
		BEGIN
			PRINT 'WARNING : '+@@SERVERNAME+': database mail queue is stopped'
			SELECT @errors = 1
		END

	DECLARE @settings_changed INT
	--check IF any settings have been changed
	SELECT @settings_changed = count(*) FROM msdb.dbo.sysmail_account WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	SELECT @settings_changed = @settings_changed + count(*) FROM msdb.dbo.sysmail_configuration WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	SELECT @settings_changed = @settings_changed + count(*) FROM msdb.dbo.sysmail_principalprofile WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	SELECT @settings_changed = @settings_changed + count(*) FROM msdb.dbo.sysmail_profile WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	SELECT @settings_changed = @settings_changed + count(*) FROM msdb.dbo.sysmail_profileaccount WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	SELECT @settings_changed = @settings_changed + count(*) FROM msdb.dbo.sysmail_server WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	SELECT @settings_changed = @settings_changed + count(*) FROM msdb.dbo.sysmail_servertype  WHERE last_mod_datetime >= DATEADD(hh,-24,GETDATE())
	IF @settings_changed > 0
		BEGIN
			PRINT 'WARNING : '+@@SERVERNAME+': database mail configuration options changed'
			SELECT @errors = 1
		END

	DECLARE @errmsg VARCHAR(3000),
			@subject VARCHAR(3000),
			@senddate DATETIME,
			@senduser VARCHAR(128)
	--check for anything in the mail log
	DECLARE cur_bkinfo CURSOR FOR
		SELECT  l.description, m.subject, m.send_request_date, m.send_request_user
		FROM	msdb.dbo.sysmail_log l
			INNER JOIN msdb.dbo.sysmail_mailitems m
			ON l.mailitem_id = m.mailitem_id
		WHERE	log_date >= DATEADD(hh,-24,GETDATE())
		AND		event_type <> 1
		ORDER BY log_date DESC
	OPEN cur_bkinfo

		FETCH NEXT FROM cur_bkinfo INTO @errmsg, @subject, @senddate, @senduser
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT 'WARNING : '+@@SERVERNAME+': database mail failed to send mail'
			PRINT '   error   : '+REPLACE(@errmsg,CHAR(10),' ')
			PRINT '   subject : '+@subject--remove any carriage returns FROM a string
			PRINT '   sent    : '+CONVERT(VARCHAR(20),@senddate,113)
			PRINT '   sent by : '+@senduser
			SELECT @errors = 1
			FETCH NEXT FROM cur_bkinfo INTO @errmsg, @subject, @senddate, @senduser
		END	--END loop

		CLOSE cur_bkinfo
		DEALLOCATE cur_bkinfo

	--check IF any errors were reported, IF NOT return a clean check
	IF @errors = 0
		PRINT 'INFO : ' +++ @@SERVERNAME+': database mail checks complete successfully'
	ELSE	
		SELECT dbo.uf_send_error ('WARNING','database mail errors found',GETDATE())
END
GO

PRINT 'recreate up_check_mirroring_status'
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_mirroring_status]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_check_mirroring_status]
GO

CREATE PROCEDURE [dbo].[up_check_mirroring_status]
	--with encryption
/**********************************************************************
*
* script   :  up_check_mirroring_status
* version  :  1.1
* created  :  andre hoorenman (GLIDE australia), 5-aug-2008
*
* usage    :  run from the up_daily_report_extra_modules sp OR directly.
*
* purpose  :  checks database mirroring sessions are in syncronized state
*
* output   :  standard out for daily report and logs failures to errorlog
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   05-08-08	andre hoorenman version 1.0 - first release version!
*
*   05-08-08	andre hoorenman version 1.1 - added hvt to error log!
***********************************************************************/

AS
BEGIN
	SET NOCOUNT ON

	DECLARE @mirrorerrors INT,
		@lstrmsg 	NVARCHAR(400)

	SET @mirrorerrors = 0

	SELECT @mirrorerrors = count(*)
	FROM sys.database_mirroring
	WHERE mirroring_guid IS NOT NULL AND mirroring_state <> 4

	IF @mirrorerrors = 0
	BEGIN
		PRINT 'INFO : '+@@SERVERNAME+': database mirroring synchronised'
	END
	ELSE
	BEGIN
		PRINT 'CRITICAL : '+@@SERVERNAME+': database mirroring not synchronised - check failed'		
		SELECT dbo.uf_send_error ('CRITICAL','database mirroring not synchronised',GETDATE())
	END
END
GO

PRINT 'recreate up_check_indexes'
PRINT '*** index rebuild script installed ***'
PRINT 'the indexing script requires a sql agent job that daily calls up_check_indexes to perform checks, this step should be removed from any maintenance plans'
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_indexes]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].up_check_indexes
GO
CREATE PROCEDURE dbo.up_check_indexes
--	/************************************************************************
--	*									*
--	* script   :  up_check_indexes						*
--	* version  :  1.1							*
--	* created  :  graham smith (GLIDE australia), 13-feb-2009			*
--	*									*
--	* usage    :  run from sqlagent job.					*
--	*									*
--	* purpose  :  checks fragmentation on a index by index basis AND 	*
--	*		performs a rebuild OR reorg as required			*
--	*									*
--	* output   :  logs failures to errorlog					*
--	* files    :  n/a							*
--	*									*
--	*									*
--	*************************************************************************
--	*						     modification log	*
--	*************************************************************************
--	*   date	    programmer	    description				*
--	*   ----	    ----------	    -----------				*
--	*   13-02-09	graham smith version 1.0 - first draft version!		*
--	*   16-02-09	graham smith version 1.1 - first release version!	*
--	************************************************************************/
	--with encryption
AS
	/***********local declarations***********/
	DECLARE @l_str_db		VARCHAR(128)									--current database
	DECLARE @l_str_table	VARCHAR(128)									--table object with fragmentation
	DECLARE @l_str_schema	VARCHAR(128)									--schema object with fragmentation
	DECLARE @l_str_index	VARCHAR(128)									--index object with fragmentation
	DECLARE @l_str_type		VARCHAR(20)										--type of activity
	DECLARE @l_dbl_frag		decimal(18,2)									--amount of fragmentation
	DECLARE @l_boo_locks	TINYINT											--if this index has page locks set
	DECLARE @l_int_rebuild	INT												--rebuild threashold	
	DECLARE @l_int_reorg	INT												--reorg threashold	
	DECLARE @l_dte_start	DATETIME										--start date	
	DECLARE @l_str_status	VARCHAR(30)										--status of index task	
	DECLARE @l_str_sql		NVARCHAR(2000)									--hold the sql command to run
	DECLARE @l_str_error	VARCHAR(1000)									--get the error code
	/***********local declarations***********/	
		
	DECLARE l_cur_index CURSOR												--create a cursor to check the new records
	for 
		SELECT	db_name(idx.database_id),									--database name
				idx.index_id,												--index id to get the index name
				idx.OBJECT_ID,												--table id to get the table name
				idx.avg_fragmentation_in_percent,							--amount of fragmentation
				GETDATE()													--current timestamp
		FROM	sys.dm_db_index_physical_stats(NULL, NULL, NULL, NULL , NULL) idx 
		WHERE	idx.index_id > 0
		AND		idx.avg_fragmentation_in_percent <> 0
		AND		idx.database_id IN (SELECT db_id(name) FROM GLIDE.dbo.valid_databases)
	OPEN l_cur_index														--open cursor'
	FETCH NEXT FROM l_cur_index INTO
				@l_str_db,
				@l_str_index,
				@l_str_table,
				@l_dbl_frag,				
				@l_dte_start
	WHILE @@FETCH_STATUS = 0												--start looping
	BEGIN	
		SELECT	@l_str_sql =  N'SELECT @o_str_table= o.name,				--get the table name
				@o_str_schema = s.name,										--the schema name
				@o_str_index = i.name,										--the index name
				@o_boo_locks = i.allow_page_locks										--page locks status
		FROM	' + QUOTENAME(@l_str_db) + N'.sys.objects AS o
			JOIN	' +QUOTENAME( @l_str_db) + N'.sys.schemas AS s 
				ON s.schema_id = o.schema_id
			JOIN	' + QUOTENAME(@l_str_db) + N'.sys.indexes AS i 
				ON i.OBJECT_ID = o.OBJECT_ID
		WHERE	o.OBJECT_ID = ' + CHAR(39) + @l_str_table + CHAR(39) + N'
		AND		i. index_id = ' + CHAR(39) + @l_str_index + CHAR(39)
				
		EXEC sp_executesql	@l_str_sql,										--sql code
							
							N'@o_str_table	VARCHAR(128) output,			--output parameters to be used in the statement
							@o_str_schema	VARCHAR(128) output,
							@o_str_index	VARCHAR(128) output,
							@o_boo_locks	TINYINT output',
							
							@o_str_table = @l_str_table output,				--parameters to get the values back
							@o_str_schema = @l_str_schema output,
							@o_str_index = @l_str_index output,
							@o_boo_locks = @l_boo_locks output
																			--get the 
		SELECT	@l_int_rebuild = GLIDE.dbo.uf_get_setting ('database',@l_str_db,'index_rebuild') ,
				@l_int_reorg = GLIDE.dbo.uf_get_setting ('database',@l_str_db,'index_defrag')
				
		IF @l_dbl_frag > @l_int_rebuild OR @l_boo_locks = 0					--rebuild the index IF the threashold is passed OR page locks are active
			SELECT	@l_str_sql = N'ALTER index [' + @l_str_index + N'] ON [' + @l_str_db + N'].[' + @l_str_schema + N'].[' + @l_str_table + N'] rebuild  SELECT @o_str_error = @@error',
					@l_str_type = 'rebuild index' 		
		ELSE IF @l_dbl_frag > @l_int_reorg									--reorganise the index online AND perform an UPDATE statistics
			SELECT	@l_str_sql = N'ALTER index [' + @l_str_index + N'] ON [' + @l_str_db + N'].[' + @l_str_schema + N'].[' + @l_str_table + N'] reorganize  SELECT @o_str_error = @@error UPDATE statistics [' + @l_str_db + N'].[' + @l_str_schema + N'].[' + @l_str_table + N'] [' + @l_str_index + N'] SELECT @o_str_error = @o_str_error  + @@error ',
					@l_str_type = 're-org index'		
		ELSE
			SELECT	@l_str_sql = N''
		
		IF 	LEN(@l_str_sql) > 10											--check we have a sql statement to run
		BEGIN			
			EXEC sp_executesql	@l_str_sql,									--execute the index statement
								N'@o_str_error VARCHAR(1000) output',
								@o_str_error = @l_str_error output

			IF @l_str_error = 0												--check that it executed
				SELECT @l_str_status = 'success'
			ELSE
				SELECT @l_str_status = 'failure'
				
			INSERT INTO GLIDE.dbo.maintenance_plan							--store in GLIDE the history of this backup
			values (@l_str_db, @l_str_table +'.'+ @l_str_schema +'.'+ @l_str_index, @l_str_type, GETDATE(), DATEDIFF(ss,@l_dte_start,GETDATE()),@l_str_status)		
		END 
		
		FETCH NEXT FROM l_cur_index											--next record in the cursor
		INTO	@l_str_db,
				@l_str_index,
				@l_str_table,
				@l_dbl_frag,
				@l_dte_start
	END																		--end cursor loop
	CLOSE l_cur_index														--close cursor
	DEALLOCATE l_cur_index													--clean up memory allocation for cursor
GO
PRINT 'recreate up_check_integrity'
PRINT '*** integrity script installed ***'
PRINT 'the dbbc script requires a sql agent job that daily calls up_check_integrity to perform checks, this step should be removed from any maintenance plans'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_integrity]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].up_check_integrity
GO
CREATE PROCEDURE dbo.up_check_integrity
--	/************************************************************************
--	*																		*
--	* script   :  up_check_integrity										*
--	* version  :  1.0														*
--	* created  :  graham smith (GLIDE australia), 13-feb-2009				*
--	*																		*
--	* usage    :  run from sqlagent job.									*
--	*																		*
--	* purpose  :  performs database integrity tasks							*
--	*																		*
--	* output   :  logs failures to errorlog									*
--	* files    :  n/a														*
--	*																		*
--	*																		*
--	*************************************************************************
--	*						     modification log							*
--	*************************************************************************
--	*   date	    programmer	    description								*
--	*   ----	    ----------	    -----------								*
--	*   13-02-09	graham smith version 1.0 - first release version!	 	*
--	************************************************************************/
	--with encryption
AS
	/***********local declarations***********/
	DECLARE @l_str_db		VARCHAR(128)									--current database
	DECLARE @l_dte_start	DATETIME										--start date
	DECLARE @l_str_status	VARCHAR(30)										--status of task
	
	/***********local declarations***********/
	CREATE TABLE #GLIDE_integrity												--create a temp table to hold the databases
	(
		database_name VARCHAR(128)
	)
	
	INSERT INTO #GLIDE_integrity												--populate the temp table
	SELECT entity_name
	FROM dbo.entity_settings 
	WHERE setting = 'checkintegrity'										--where the day is marked as a full backup day
		AND	value <> 'n'
		AND	entity_name NOT IN ('','tempdb') 
		AND	entity_name IN (SELECT name COLLATE DATABASE_DEFAULT FROM valid_databases)	
	
	WHILE (EXISTS(SELECT 'x' FROM #GLIDE_integrity))							--loop through each database
	BEGIN 
		SELECT top 1 
				@l_str_db = database_name,									--and the backup type required
				@l_dte_start = GETDATE()
		FROM #GLIDE_integrity
		
		dbcc checkdb(@l_str_db) 											--perform an integrity check, any issues will be grabbed by logchecker
		IF (@@error = 0)
			SELECT @l_str_status = 'success'
		ELSE
			SELECT @l_str_status = 'failure'
		
		INSERT INTO GLIDE.dbo.maintenance_plan								--store in GLIDE the history of this backup
		values (
			@l_str_db,
			'',
			'integrity check',
			GETDATE(),
			DATEDIFF(ss,@l_dte_start,GETDATE()),@l_str_status)
		
		DELETE																--delete the temp record to allow the loop
		FROM #GLIDE_integrity 
		WHERE database_name = @l_str_db 		
	END																		--end while loop	
	
	DROP TABLE #GLIDE_integrity												--remove the temp table																									
GO

SET ansi_nulls ON
GO

SET quoted_identifier ON
GO

PRINT 'recreate up_daily_report_availability_group_dbstatus_GLIDE'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_ag_dbstatus_GLIDE]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_ag_dbstatus_GLIDE]
GO
-----------------------------------------------------

CREATE PROCEDURE [up_daily_report_ag_dbstatus_GLIDE]
	--with encryption

/**********************************************************************
*
* script   :  up_daily_report_ag_dbstatus_GLIDE
* version  :  1.0
* created  :  sumudu koku hannadige (hp australia), 18-dec-2014
*
* usage    :  run from task schedular for GLIDE morning health check to check always on database health check.
*
* purpose  :  GLIDE morning healcheck evry morning for sql always on database health check
*
* output   :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   
***********************************************************************/

	AS
BEGIN

SET NOCOUNT ON

IF EXISTS (SELECT * FROM sys.objects WHERE name='y' AND type_desc='user_table')
 DROP TABLE GLIDE.dbo.y
 IF EXISTS (SELECT * FROM sys.objects WHERE name='y' AND type_desc='user_table')
 DROP TABLE GLIDE.dbo.z

DECLARE 
	@sync_status VARCHAR(50),
	@db_id VARCHAR(50),
	@name VARCHAR(50),
	@p VARCHAR(50),
	@ag_name VARCHAR(50),
	@h VARCHAR(50);


SELECT
	ag.name AS agname,
	rep.synchronization_state_desc,
	rep.synchronization_health_desc,
	rep.database_id,
	sysdb.name 
INTO GLIDE.dbo.y
FROM master.sys.dm_hadr_database_replica_states AS rep
INNER JOIN master.sys.databases AS sysdb ON rep.database_id = sysdb.database_id 
INNER JOIN master.sys.availability_groups AS ag ON rep.group_id = ag.group_id
WHERE rep.synchronization_state<>2
	OR rep.synchronization_state<>1
	AND rep.is_local = 1  
ORDER BY rep.database_id

DECLARE contact_cursor CURSOR FOR 
	SELECT
		agname,
		synchronization_state_desc,
		database_id,
		name,
		synchronization_health_desc
 FROM GLIDE.dbo.y
ORDER BY database_id;

OPEN contact_cursor;

FETCH NEXT FROM contact_cursor
	INTO
		@ag_name,
		@sync_status,
		@db_id,
		@name,
		@h;

WHILE @@FETCH_STATUS=0

BEGIN
	IF sys.fn_hadr_backup_is_preferred_replica(@name) <>1
SET @p='primary replica'
ELSE
SET @p='secondary replica'


IF @sync_status ='SYNCHRONIZED' OR @sync_status ='SYNCHRONIZING' AND @h='HEALTHY'


	BEGIN
   	PRINT 'INFO :'+' ag db status- ' + @sync_status + ' ' +@name+' '+@p+' '+@@SERVERNAME+' ag name '+@ag_name+'-'+@h+' '
	END
   	ELSE IF @sync_status <>'SYNCHRONIZED' OR @sync_status <>'SYNCHRONIZING' AND @h<>'HEALTHY'
   	BEGIN
   	PRINT 'WARNING :'+' ag db status- ' + @sync_status + ' ' +@name+' '+@p+' '+@@SERVERNAME++' ag name: '+@ag_name+'-'+@h+' '
	END
   FETCH NEXT FROM contact_cursor
		INTO
			@ag_name,
			@sync_status,
			@db_id,
			@name,
			@h;
END
DROP TABLE GLIDE.dbo.y

CLOSE contact_cursor;
DEALLOCATE contact_cursor;

DECLARE
	@sync_status1 VARCHAR(50),
	@db_id1 VARCHAR(50),
	@name1 VARCHAR(50),
	@p1 VARCHAR(50),
	@ag_name1 VARCHAR(50),
	@h1 VARCHAR(50);

SELECT
	ag.name AS agname,
	rep.synchronization_state_desc,
	rep.synchronization_health_desc, 
	rep.database_id,
	sysdb.name
INTO GLIDE.dbo.z
FROM master.sys.dm_hadr_database_replica_states AS rep
INNER JOIN master.sys.databases AS sysdb ON rep.database_id = sysdb.database_id 
INNER JOIN master.sys.availability_groups AS ag ON rep.group_id = ag.group_id
WHERE rep.synchronization_state<>2
	OR rep.synchronization_state<>1
	AND rep.is_local=0  
ORDER BY rep.database_id

DECLARE contact_cursor1 CURSOR FOR
	SELECT
		agname,
		synchronization_state_desc,
		database_id,
		name,
		synchronization_health_desc 
 FROM GLIDE.dbo.z
ORDER BY database_id;

OPEN contact_cursor1;

FETCH NEXT FROM contact_cursor1
	INTO
		@ag_name1,
		@sync_status1,
		@db_id1,
		@name1,
		@h1;

WHILE @@FETCH_STATUS=0
BEGIN

   IF @sync_status1 ='SYNCHRONIZED' OR @sync_status1 ='SYNCHRONIZING' AND @h1='HEALTHY'
   BEGIN
   PRINT 'INFO :'+' ag db status- ' + @sync_status1 + ' ' +@name1+' '+'secondary servers'+' ag name '+@ag_name1+'-'+@h1
   END
   ELSE IF @sync_status1 <>'SYNCHRONIZED' OR @sync_status1 <>'SYNCHRONIZING' AND @h1<>'HEALTHY'
		BEGIN
   PRINT 'WARNING :'+' ag db status- ' + @sync_status1 + ' ' +@name1+' '+'secondary replicas'+' ag name '+@ag_name1+'-'+@h1
		END
   FETCH NEXT FROM contact_cursor1
  		INTO 
			@ag_name1,
			@sync_status1,
			@db_id1,
			@name1,
			@h1;
END
DROP TABLE GLIDE.dbo.z
PRINT 'OKAY'
CLOSE contact_cursor1;
DEALLOCATE contact_cursor1;
END

GO



--*******

use GLIDE
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE name = N'agstatus' AND OBJECTPROPERTY(id, N'istable') = 1)
	DROP TABLE [dbo].[agstatus]
GO

IF (SERVERPROPERTY('isHadrEnabled') IS NOT NULL)
BEGIN
---CREATE the TABLE (before run the agstatus stored PROCEDURE required to CREATE the agstatus TABLE ON each replica)
	SELECT
		rep.group_id,
		rep.replica_id,
		ag.name AS v_name,
		group_state.primary_replica,
		rep.replica_server_name,
		rep_state.role_desc,
		rep_state.role_desc AS current_role,
		rep.availability_mode_desc,
		rep.availability_mode_desc AS current_mode_desc,
		rep.failover_mode_desc,
		rep.failover_mode_desc AS current_failover_mode_desc,
		rep.secondary_role_allow_connections,
		rep.secondary_role_allow_connections_desc AS current_allow_conn 
	INTO dbo.agstatus
	FROM sys.availability_replicas AS rep 
	INNER JOIN sys.availability_groups AS ag ON rep.group_id = ag.group_id 
	INNER JOIN sys.dm_hadr_availability_group_states AS group_state ON rep.group_id = group_state.group_id 
	INNER JOIN sys.dm_hadr_availability_replica_states AS rep_state ON rep.group_id = rep_state.group_id
		AND rep.replica_id = rep_state.replica_id
END
GO

--********






--create stored PROCEDURE for always on status changes 

USE [GLIDE]
GO

PRINT 'recreate up_daily_report_agmon_status'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_agmon_status]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_agmon_status]
GO
CREATE PROCEDURE [up_daily_report_agmon_status]
	--with encryption

/**********************************************************************
*
* script   :  up_daily_report_agmon_status
* version  :  1.0
* created  :  sumudu koku hannadige (hp australia), 18-dec-2014
*
* usage    :  run from task schedular for dbmon to check always on  group various status changes.
*
* purpose  :  write to always on group status changes to sql error log for dbmon
*
* output   :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   
***********************************************************************/

AS
BEGIN

	DECLARE
	@v_name VARCHAR(50),
	@r_name VARCHAR(50),
	@role_desc VARCHAR(50),
	@group_id VARCHAR(50),
	@r_id VARCHAR(50),
	@a VARCHAR(50),
	@b VARCHAR(50),
	@c VARCHAR(50),
	@a_mode VARCHAR(50),
	@f_mode VARCHAR(50),
	@rs VARCHAR(50),
	@d VARCHAR(50),
	@s INT,
	@result NVARCHAR(256);

DECLARE tb_cur CURSOR FOR
	SELECT
		group_id,
		replica_id,
		v_name,
		replica_server_name,
		current_role,
		current_mode_desc,
		current_failover_mode_desc,
		current_allow_conn
	FROM GLIDE.dbo.agstatus
	ORDER BY 
		group_id,
		replica_id

OPEN tb_cur

FETCH NEXT FROM tb_cur INTO
	@group_id,
	@r_id,
	@v_name,
	@r_name,
	@role_desc,
	@a_mode,
	@f_mode,
	@rs

WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @a=(SELECT role_desc FROM sys.dm_hadr_availability_replica_states WHERE replica_id=@r_id AND group_id=@group_id)
	SET @b=(SELECT availability_mode_desc FROM  sys.availability_replicas WHERE replica_id=@r_id AND group_id=@group_id)
	SET @c=(SELECT failover_mode_desc FROM sys.availability_replicas WHERE replica_id=@r_id AND group_id=@group_id)
	SET @d=(SELECT secondary_role_allow_connections_desc FROM sys.availability_replicas WHERE replica_id=@r_id AND group_id=@group_id)
	--check for primary server for ag by record count. if record count 1 primary else secondary
	SET @s=(
		SELECT
			count(*)
		FROM sys.availability_groups_cluster AS agc
		INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS rcs ON rcs.group_id = agc.group_id
  		INNER JOIN sys.dm_hadr_availability_replica_states AS ars ON ars.replica_id = rcs.replica_id
  		LEFT JOIN sys.availability_group_listeners AS agl ON agl.group_id = ars.group_id
	WHERE
 			ars.group_id = @group_id AND ars.role_desc = 'primary'
	)

	IF @a=@role_desc
	BEGIN
		PRINT 'INFO :'+'  ag name:'+@v_name+'  replica '+@r_name+'  previous state:'+@role_desc+'   current state:'+@a
	END
	ELSE
	BEGIN
		SET @result='WARNING :'+'  ag name:'+@v_name+'  replica '+@r_name+'  previous state:'+@role_desc+'  changed to  :'+@a
		PRINT @result -- for GLIDE
 		SELECT GLIDE.dbo.uf_send_erroragmon ('WARNING',@result,GETDATE())
		UPDATE GLIDE.dbo.agstatus SET current_role=@a WHERE  group_id=@group_id AND replica_id=@r_id
	END

	IF @b=@a_mode 
	BEGIN
		PRINT 'INFO :'+'  ag name:'+@v_name+'  replica '+@r_name+'  availability mode previous state:'+@a_mode+'   current state:'+@b
	END
	ELSE
	BEGIN
		SET @result= 'WARNING :'+'  ag name:'+@v_name+'  replica '+@r_name+'  availability mode previous state:'+@a_mode+'   current state:'+@b
		PRINT @result  -- for GLIDE
 		SELECT GLIDE.dbo.uf_send_erroragmon ('WARNING',@result,GETDATE())
		UPDATE GLIDE.dbo.agstatus SET current_mode_desc=@b WHERE  group_id=@group_id AND replica_id=@r_id
	END 
	 	
	IF @c=@f_mode
	BEGIN
		PRINT 'INFO :'+'  ag name:'+@v_name+'  replica '+@r_name+'  failover mode previous state:'+@f_mode+'   current state:'+@c
	END
	ELSE
	BEGIN
		SET @result= 'WARNING :'+'  ag name:'+@v_name+'  replica '+@r_name+'  failover mode previous state:'+@f_mode+'   current state:'+@c
		PRINT @result -- for GLIDE
 		SELECT GLIDE.dbo.uf_send_erroragmon ('WARNING',@result,GETDATE())
		UPDATE GLIDE.dbo.agstatus SET current_failover_mode_desc=@c WHERE  group_id=@group_id AND replica_id=@r_id
	END
		
	IF @d=@rs
	BEGIN
		PRINT 'INFO :'+'  ag name:'+@v_name+'  replica '+@r_name+'  connection previous state:'+@rs+'   current state:'+@d
	END
	ELSE
	BEGIN
		PRINT 'WARNING :'+'  ag name:'+@v_name+'  replica '+@r_name+'  connection previous state:'+@rs+'   current state:'+@d
		SET @result='WARNING :'+'  ag name:'+@v_name+'  replica '+@r_name+'  connection previous state:'+@rs+'   current state:'+@d
		PRINT @result  -- for GLIDE
		SELECT GLIDE.dbo.uf_send_erroragmon ('WARNING',@result,GETDATE())
		UPDATE GLIDE.dbo.agstatus SET current_allow_conn=@d WHERE  group_id=@group_id AND replica_id=@r_id
	END
		
	FETCH NEXT FROM tb_cur INTO
		@group_id,
		@r_id,
		@v_name,
		@r_name,
		@role_desc,
		@a_mode,
		@f_mode,
		@rs
END

CLOSE tb_cur
DEALLOCATE tb_cur
PRINT 'OKAY'
END

GO

--*******************

USE [GLIDE]
GO

IF NOT EXISTS (SELECT * FROM  GLIDE.dbo.extra_modules WHERE module_name ='up_daily_report_ag_dbstatus_GLIDE')
	INSERT INTO GLIDE.dbo.extra_modules values ('up_daily_report_ag_dbstatus_GLIDE','P',6,'N')
ELSE
	UPDATE [GLIDE].[dbo].[extra_modules] SET is_enabled='N' WHERE module_name='up_daily_report_ag_dbstatus_GLIDE'

IF NOT EXISTS (SELECT * FROM  GLIDE.dbo.extra_modules WHERE module_name ='up_daily_report_agmon_status')
	INSERT INTO GLIDE.dbo.extra_modules values ('up_daily_report_agmon_status','P',7,'N')
ELSE
	UPDATE [GLIDE].[dbo].[extra_modules] SET is_enabled='N' WHERE module_name='up_daily_report_agmon_status'

GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[uf_send_erroragmon]') AND OBJECTPROPERTY(id, N'isscalarfunction') = 1)
	DROP FUNCTION [dbo].[uf_send_erroragmon]
GO
--------------------------------------------------------------------

CREATE FUNCTION dbo.uf_send_erroragmon (@i_str_severity VARCHAR(15), @i_str_msg VARCHAR(400), @i_dte_current SMALLDATETIME)
	returns INT
--with encryption

/**********************************************************************
*
* script   :  uf_send_erroragmon
* 
* created  :  sumudu koku hannadige
*
* usage    :  run from various stored procedures for sql always on alerts on dbmon (sql 2012 and above).
*
* purpose  :  writes an error to the windows event log
*
* output   :  n/a
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   11-11-08	graham smith	version 1.0 	initial version for GLIDE
*
*   27-01-09	graham smith	version 1.1 	added informational events to the raise error
*												allowed suppression of alerts using entity settings
*
*   26-02-09	graham smith	version 1.2 	added check for 24x7 systems
*												supress messages at weekends
*												corrected information to informational for events
*												added additional parameter to pass date in
*  20/01/2015	sumudu koku hannadige		altered for sql always ON dbmon monitoring
*
***********************************************************************/

AS
BEGIN	
	DECLARE @l_str_msg VARCHAR(1000) --variable to hold the windows event log status
	DECLARE @l_str_event VARCHAR(20) --variable to hold the windows event log status
	DECLARE @l_int_result INT --return variable

	--populate the paremeters
	SET @l_str_msg = 	CONVERT(VARCHAR(50),serverproperty('servername')) + --the server this is occuring on
				' : ' + @i_str_msg --the message being returned
	--IF(UPPER(LTRIM(dbo.uf_get_setting('server','', 'supresseon'))) <> 'y')
	--BEGIN
		SET @l_str_msg = '[agmon] '+@l_str_msg   --state this is for always on dbmon- (agmon) for the monitoring team to id it
	--END


	SET	@l_str_event = case @i_str_severity when  'CRITICAL' then 'error' when 'WARNING' then 'WARNING' when 'information' then 'informational' END

	--check if this is a weekend
	--DECLARE @l_int_firstday INT
	--DECLARE @l_int_week INT 

	--SELECT	@l_int_firstday = @@datefirst - 1,
	--	@l_int_week = DATEPART(weekday,@i_dte_current) - 1

	--IF (@l_int_firstday + @l_int_week) % 7 NOT IN (5, 6)
	IF @i_str_severity = 'CRITICAL' OR @i_str_severity = 'WARNING'
	BEGIN																		--none weekend day, raise --alert as normal
		EXEC master.dbo.xp_logevent 99999, @l_str_msg, @l_str_event				--write to the windows log
		SELECT @l_int_result = @@error
	END
	--ELSE																			--weekend, only --raise alert IF 24x7 server and this is CRITICAL
	--IF (UPPER(LTRIM(dbo.uf_get_setting('server','', 'is24x7'))) = 'y') AND @i_str_severity = 'CRITICAL'
	--BEGIN				
	--	EXEC master.dbo.xp_logevent 77777, @l_str_msg, @l_str_event				--write to the windows log
	--	SELECT @l_int_result = @@error
	--END
		
	return @l_int_result															--return the outcome
END
GO

PRINT 'recreate up_check_maintenance'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_maintenance]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].up_check_maintenance
GO
CREATE PROCEDURE dbo.up_check_maintenance
--	/************************************************************************
--	*									*
--	* script   :  up_check_maintenance					*
--	* version  :  1.0							*
--	* created  :  graham smith (GLIDE australia), 13-feb-2009			*
--	*									*
--	* usage    :  run FROM daily report.					*
--	*									*
--	* purpose  :  performs database maintenance history			*
--	*									*
--	* output   :  logs failures to errorlog					*
--	* files    :  n/a							*
--	*									*
--	*									*
--	*************************************************************************
--	*						     modification log	*
--	*************************************************************************
--	*   date	    programmer	    description				*
--	*   ----	    ----------	    -----------				*
--	*   13-02-09	graham smith version 1.0 - first release version!	*
--	************************************************************************/
	--with encryption
AS
	--DELETE anything older that 14 days old
	DELETE 
	FROM GLIDE.dbo.maintenance_plan
	WHERE	task_date < DATEADD(d,-14,GETDATE())
	DECLARE @l_str_msg	VARCHAR(6000)
	--report back on any maintenance tasks performed in the last 24 hours
	SELECT  coalesce(@l_str_msg + CHAR(10) ,'') +  'INFO: ' + @@SERVERNAME + ': maintenance task ' + task_status + ' : ' + task_performed + ' [' + CAST(task_duration AS VARCHAR(6)) + ' seconds] ON ' + database_name + database_object 
	FROM 	GLIDE.dbo.maintenance_plan
	WHERE	task_date >= DATEADD(hour,-24,GETDATE())

	PRINT @l_str_msg
	PRINT 'INFO : '+@@SERVERNAME+': maintenance plan history returned'

GO
PRINT 'recreate up_check_blocks'
GO
PRINT '*** blocking script installed ***'
PRINT 'the blocking script requires a sql agent job that regularly calls up_check_blocks to perform analysis'
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_blocks]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].up_check_blocks
GO
CREATE PROCEDURE dbo.up_check_blocks
	--with encryption
AS
	/************************************************************************
	*									*
	* script   :  up_check_blocks						*
	* version  :  1.1							*
	* created  :  graham smith (GLIDE australia), 3-feb-2009			*
	*									*
	* usage    :  run FROM sqlagent job.					*
	*									*
	* purpose  :  checks database locks for any long running OR blocking	*
	*			  processes					*
	*									*
	* output   :  logs failures to errorlog					*
	* files    :  n/a							*
	*									*
	*									*
	*************************************************************************
	*						     modification log	*
	*************************************************************************
	*   date	    programmer	    description				*
	*   ----	    ----------	    -----------				*
	*   02-02-09	graham smith version 1.0 - first release version!	*
	*   22-02-09	graham smith version 1.1 - restricted current blocks!	*
	************************************************************************/
	
	--check current processes that are causing a block
	IF EXISTS (SELECT 1 FROM master.dbo.sysprocesses WHERE blocked != 0)
	BEGIN 
		DELETE											--clear out any block in current_blocks 
		FROM	GLIDE.dbo.current_blocks 
		WHERE	spid	NOT IN (SELECT	spid 
								FROM	master.dbo.sysprocesses)	--that have stopped
		OR		spid	NOT IN  (SELECT blocked
								FROM	master.dbo.sysprocesses)	--or are no longer blocking

		INSERT INTO GLIDE.dbo.current_blocks							--dump information into current_blocks
			(	
				database_name,
				spid,
				locktime,
				batchtime,
				locktype,
				blocking,
				connection_host,
				connection_app,
				db_user,
				sql_handle		
			)
		SELECT	d.name,	
				p.spid, 	
				GETDATE(),		
				p.last_batch, 			
				p.status, 
				b.spid,
				p.hostname,
				p.program_name, 
				p.loginame,
				p.sql_handle 				
		FROM	master.dbo.sysprocesses p 
			INNER JOIN master.dbo.sysprocesses b
				ON p.spid = b.blocked
			INNER JOIN master.dbo.sysdatabases d
				ON p.dbid = d.dbid	
		WHERE NOT EXISTS (SELECT	'x'									--do not include any existing locks
						FROM	GLIDE.dbo.current_blocks c
						WHERE	p.spid = c.spid 
						AND		b.spid= c.blocking
						AND		c.alert_sent = 1)					--that have already been processed

		/***********local declarations***********/
		DECLARE @l_int_spid INT			--current process id
		DECLARE @l_int_blocking INT		--current process being blockedid
		DECLARE @l_str_db VARCHAR(128)		--database connection is made to
		DECLARE @l_str_host VARCHAR(128)	--host connection is FROM
		DECLARE @l_str_user VARCHAR(128)	--sql user making the connection
		DECLARE @l_int_blocks INT		--count of the number of blocks being made
		DECLARE @l_str_handle binary(20)	--sql handle of the locking process
		DECLARE @l_str_sql VARCHAR(3000)	--last sql batch sent by the locking process
		DECLARE @l_int_mins INT			--number of minutes the lock has been held for
		DECLARE @l_str_locktype VARCHAR(40)	--type of lock being held
		DECLARE @l_str_version VARCHAR(128)	--hold the sql server version
		DECLARE @l_int_spid_tmp INT		--hold the spid for counting blocks
		/***********local declarations***********/
				
		DECLARE l_cur_blocks CURSOR										--create a cursor to check the new records
		for 
			SELECT	spid,
					database_name,
					connection_host,
					db_user,
					blocking
			FROM	GLIDE.dbo.current_blocks
			WHERE	processed = 0										--is a new block'
						
		OPEN l_cur_blocks											--OPEN cursor'
		FETCH NEXT FROM l_cur_blocks 
			INTO	@l_int_spid,
					@l_str_db,
					@l_str_host,
					@l_str_user,
					@l_int_blocking
		WHILE @@FETCH_STATUS = 0										--cycle through all records in cursor
			BEGIN									
				IF EXISTS	(									--do we have any existing records
							SELECT	spid 
							FROM	GLIDE.dbo.current_blocks 
							WHERE	spid = @l_int_spid
							AND		database_name = @l_str_db
							AND		connection_host = @l_str_host
							AND		db_user = @l_str_user
							AND		blocking = @l_int_blocking
							AND		processed = 1
							AND		alert_sent = 0
							)
				BEGIN				
															--get the difference between the last occurence and now'
					SELECT 	@l_str_handle  = sql_handle,					
						@l_int_mins = DATEDIFF(minute,locktime,GETDATE())
					FROM	GLIDE.dbo.current_blocks 
					WHERE	spid = @l_int_spid
					AND		database_name = @l_str_db
					AND		connection_host = @l_str_host
					AND		db_user = @l_str_user
					AND		blocking = @l_int_blocking
					AND		processed = 1
															--get the lock type'
					SELECT @l_str_locktype = SUBSTRING (v.name, 1, 4) + '/' + SUBSTRING (u.name, 1, 8) + '/' + SUBSTRING (x.name, 1, 5)
					FROM	master.dbo.syslockinfo l,
							master.dbo.spt_values v,
							master.dbo.spt_values x,
							master.dbo.spt_values u						
					WHERE	l.rsc_type = v.number
					AND		v.type = 'lr'
					AND		l.req_status = x.number
					AND		x.type = 'ls'
					AND		l.req_mode + 1 = u.number
					AND		u.type = 'l'
					AND		req_spid = @l_int_spid
															--get the count of the records affected
					SELECT	@l_int_spid_tmp = @l_int_spid,
							@l_int_blocks = 0	
									
					WHILE (EXISTS (SELECT 'x' FROM master.dbo.sysprocesses p WHERE	blocked = @l_int_spid_tmp))	
					BEGIN										--loop until all blocking processes have been found											
						SELECT	@l_int_spid_tmp = p.spid,					--initialise counter
								@l_int_blocks = @l_int_blocks + 1
						FROM	master.dbo.sysprocesses p 
						WHERE	blocked = @l_int_spid_tmp
					END
															--get the sql text using the system functions/views using the sql handle'
					SELECT	@l_str_version = CONVERT(VARCHAR(128), serverproperty('productversion')),
							@l_str_sql = 'sql query text unavailable'
					IF SUBSTRING(@l_str_version ,1,CHARINDEX('.',@l_str_version)-1) > 8
					BEGIN										--2005 + version'
						SELECT @l_str_sql = text FROM sys.dm_exec_sql_text(@l_str_handle); 
					END
					ELSE IF SUBSTRING(@l_str_version ,1,CHARINDEX('.',@l_str_version)-1) = 8
					BEGIN
						WHILE CHARINDEX('.',@l_str_version) != 0				--loop through the version to get the patch level'
						BEGIN
							SELECT @l_str_version = SUBSTRING(@l_str_version,CHARINDEX('.',@l_str_version),LEN(@l_str_version))
						END									--end loop [get the patch level]'
						IF @l_str_version >= 760
						BEGIN									--2000 sp4 and above '
							SELECT @l_str_sql = text FROM sys.fn_get_sql(@l_str_handle); 
						END									--end if [2000 sp4 and above]'
					END										--end if [sql version]'												
							
					IF	(									--check if this lock matches the criteria
						(SELECT count(spid)FROM master.dbo.sysprocesses WHERE blocked!= 0) >= GLIDE.dbo.uf_get_setting('server','','maxblocks')
						AND (@l_int_mins >= GLIDE.dbo.uf_get_setting('server','','blocktime'))
						AND (@l_int_blocks >= GLIDE.dbo.uf_get_setting('server','','blockedprocess'))
						)								
					BEGIN					
						INSERT INTO GLIDE.dbo.block_history					--dump data to history table
							(	
								database_name,
								spid,
								locktime,	
								batchtime,
								locktype,
								connection_host,
								connection_app,
								db_user,
								sql_text,
								blocks_held,
								block_duration,
								total_blocks								
							)
						SELECT	database_name,	
								spid,
								locktime,
								batchtime,
								@l_str_locktype,
								connection_host,
								connection_app,
								db_user,
								@l_str_sql,
								@l_int_blocks,
								@l_int_mins,
								(SELECT count(spid)FROM master.dbo.sysprocesses WHERE blocked!= 0) 				
						FROM	GLIDE.dbo.current_blocks
						WHERE	spid = @l_int_spid
						AND		database_name = @l_str_db
						AND		connection_host = @l_str_host
						AND		db_user = @l_str_user
						AND		processed = 1
						
						UPDATE	GLIDE.dbo.current_blocks						--set current_block table to show alert has been sent
						SET		alert_sent = 1
						WHERE	spid = @l_int_spid
						AND		database_name = @l_str_db
						AND		connection_host = @l_str_host
						AND		db_user = @l_str_user
						AND		processed = 1				

						SELECT GLIDE.dbo.uf_send_error('CRITICAL','blocking occuring ON database ' + @l_str_db + '. spid ' + CAST(@l_int_spid AS VARCHAR(4)),GETDATE())
						
						DELETE 									--delete the newest record as we want to keep the first occurence of this block
						FROM	GLIDE.dbo.current_blocks 
						WHERE	spid = @l_int_spid
						AND		database_name = @l_str_db
						AND		connection_host = @l_str_host
						AND		db_user = @l_str_user
						AND		processed = 0	
					END										--end if [check if this lock matches the criteria]
				END											--end if [do we have existing records]
							
				FETCH NEXT FROM l_cur_blocks								--fetch next record into cursor		
				INTO	@l_int_spid,
						@l_str_db,
						@l_str_host,
						@l_str_user,
						@l_int_blocking
			END												--end loop [@@FETCH_STATUS = 0]
			CLOSE l_cur_blocks										--close cursor
			DEALLOCATE l_cur_blocks										--clean up memory allocation for cursor
					
			UPDATE	GLIDE.dbo.current_blocks									--set all existing records to processed
			SET		processed = 1
		END													--end if [current processes with block]
	ELSE
		BEGIN			
			DELETE												--no blocks exist so clear current blocks
			FROM	GLIDE.dbo.current_blocks 
		END													--end else [current processes with block]
			
	DELETE														--final clean up to delete any history older than 14 days
	FROM	GLIDE.dbo.block_history
	WHERE	locktime < DATEADD(dd,-14,GETDATE())
GO

PRINT 'add additional module up_check_maintenance to daily report'
IF NOT EXISTS (SELECT * FROM  GLIDE.dbo.extra_modules WHERE module_name ='up_check_maintenance')
	INSERT INTO GLIDE.dbo.extra_modules values ('up_check_maintenance','P',5,'Y')
GO
PRINT 'add additional module up_check_mirroring_status to daily report'
IF NOT EXISTS (SELECT * FROM  GLIDE.dbo.extra_modules WHERE module_name ='up_check_mirroring_status')
	INSERT INTO GLIDE.dbo.extra_modules values ('up_check_mirroring_status','P',3,'Y')
GO
PRINT 'add additional module up_check_dbmail_status to daily report'
IF NOT EXISTS (SELECT * FROM  GLIDE.dbo.extra_modules WHERE module_name ='up_check_dbmail_status')
	INSERT INTO GLIDE.dbo.extra_modules values ('up_check_dbmail_status','P',4,'Y')
GO

PRINT 'remove additional modules for sql 2005 FROM sql 2000 servers'

--remove sql2005 only modules from 2000 servers
IF EXISTS (SELECT 'x' WHERE SUBSTRING(CONVERT(VARCHAR(128), serverproperty('productversion')),1,CHARINDEX('.',CONVERT(VARCHAR(128), serverproperty('productversion')))-1) < 9)--sql 2005 AND above
BEGIN
	DELETE FROM GLIDE.dbo.extra_modules WHERE module_name IN ('up_check_dbmail_status','up_check_mirroring_status')
END
--------------------------------------------------------------------

use GLIDE
GO

PRINT 'recreate up_aoag_rolefailovercapture'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_aoag_rolefailovercapture]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_aoag_rolefailovercapture]
GO
CREATE PROCEDURE [up_aoag_rolefailovercapture]
	--with encryption

AS

	/************************************************************************
	*									*
	* script   :  up_aoag_rolefailovercapture						*
	* version  :  1.1							*
	* created  :  Cameron Arthur, nov-2017			*
	*									*
	* usage    :  run from main stored proc.					*
	*									*
	* purpose  :  checks error logs for AOAG role changes	*
	*			  					*
	*									*
	* output   :  prints to screen					*
	* files    :  n/a							*
	*									*
	*									*
	*************************************************************************
	*						     modification log	*
	*************************************************************************
	*   date	    programmer	    description				*
	*   ----	    ----------	    -----------				*
	*   Nov-2017	Cameron Arthur version 1.0 - first release version!	*
	*	Aug-2018	Charles Zyzniewski	version 1.1 - returns only last 26 hours worth of logs
	*						 and groups alerts by availability group listener
	************************************************************************/

BEGIN
SET NOCOUNT ON
DECLARE @hours AS INT 
SELECT @hours=26
DECLARE @count AS INT

CREATE TABLE #temp (
	archive VARCHAR(50),
	date DATETIME,
	[text] VARCHAR(2000)
)
INSERT INTO #temp
EXEC sp_enumerrorlogs

CREATE TABLE #errorlog (
logdate DATETIME,
	processinfo VARCHAR(50),
	[text] VARCHAR(2000)
)

CREATE TABLE #errorlog2 (
	i INT,
	logdate DATETIME,
	[text] VARCHAR(2000)
)

CREATE TABLE #AoagDbChangedRole(
	logdate DATETIME,
	[dbname] VARCHAR(500),
)

SET @count = (
	SELECT count(archive)
	FROM #temp
	WHERE date > DATEADD(hh,-@hours,GETDATE())
)

DECLARE @counter AS INT
SET @counter = 0
WHILE @counter < @count
BEGIN   
	INSERT INTO #errorlog
	EXEC sp_readerrorlog @counter
	SET @counter = @counter + 1
END   

INSERT INTO #errorlog2
SELECT
	ROW_NUMBER() Over(ORDER BY logdate DESC) AS i,
	logdate,
	text
FROM #errorlog
WHERE text LIKE '%changing roles FROM%"PRIMARY" to%'
	AND logdate > DATEADD(hh,-@hours,GETDATE())

-----------------------------------------------------------------------------------------------

DECLARE @name VARCHAR(5000)
DECLARE @logdate DATETIME
SET @counter = 1

DECLARE db_cursor CURSOR FOR  
SELECT logdate, text FROM #errorlog2

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @logdate, @name 

WHILE @@FETCH_STATUS = 0   
BEGIN
	DECLARE @a TABLE (i INT, pos INT)
	IF EXISTS (SELECT * FROM @a)
		DELETE @a
	DECLARE @index INT 
	SELECT @index= 1
	DECLARE @pos INT
	DECLARE @oldpos INT
	SELECT @oldpos=0
	SELECT @pos=patindex('%"%',@name) 
	WHILE @pos > 0 AND @oldpos<>@pos
	 BEGIN
	   INSERT INTO @a Values (@index, @pos)
	   SELECT @oldpos=@pos
	   SELECT @pos=patindex('%"%',SUBSTRING(@name,@pos + 1,LEN(@name))) + @pos
	   SELECT @index = @index + 1
	END
	DECLARE @DBIndexStart AS INT
	SELECT @DBIndexStart=(SELECT pos FROM @a WHERE i = 1)
	DECLARE @DBIndexEnd AS INT
	SELECT @DBIndexEnd = (SELECT pos FROM @a WHERE i = 2)
	DECLARE @DBState1Start AS INT
	SELECT @DBState1Start = (SELECT pos FROM @a WHERE i = 3)
	DECLARE @DBState1End AS INT
	SELECT @DBState1End = (SELECT pos FROM @a WHERE i = 4)
	DECLARE @DBState2Start AS INT
	SELECT @DBState2Start = (SELECT pos FROM @a WHERE i = 5)
	DECLARE @DBState2End AS INT
	SELECT @DBState2End = (SELECT pos FROM @a WHERE i = 6)

	INSERT INTO #AoagDbChangedRole
	SELECT
		logdate,
		SUBSTRING(text,@DBIndexStart+1,@DBIndexEnd-@DBIndexStart-1) AS dbname
	FROM #errorlog2
	WHERE i = @counter
	SELECT @counter = @counter + 1

	   FETCH NEXT FROM db_cursor INTO @logdate, @name  
END   

CLOSE db_cursor   
DEALLOCATE db_cursor

----------------------------------------------------------------------------------------------
DECLARE @message VARCHAR(1000)

DECLARE db_cursor CURSOR FOR
SELECT distinct
	'WARNING : ' + @@SERVERNAME 
	+ ':Availability Group "' + gclust.name 
	+ '" on listener "' + glistner.dns_name
	
	+ '" role change occurred at ' + CAST(logdate AS VARCHAR(25)) 
FROM #AoagDbChangedRole AS role_changed
INNER JOIN sys.availability_databases_cluster AS db_cluster ON role_changed.dbname = db_cluster.database_name
INNER JOIN sys.availability_groups_cluster AS gclust ON db_cluster.group_id = gclust.group_id
INNER JOIN sys.dm_hadr_availability_replica_states AS rep_state ON db_cluster.group_id = rep_state.group_id
INNER JOIN sys.availability_group_listeners AS glistner ON db_cluster.group_id = glistner.group_id
WHERE rep_state.is_local = 1

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @message

WHILE @@FETCH_STATUS = 0
BEGIN   
	PRINT @message
	FETCH NEXT FROM db_cursor INTO @message  
END   

CLOSE db_cursor   
DEALLOCATE db_cursor

IF @message IS NULL
PRINT 'OKAY'
END
GO

USE [GLIDE]
PRINT 'recreate up_aoag_replicasyncstatus'
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_aoag_replicasyncstatus]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_aoag_replicasyncstatus]
GO

CREATE PROCEDURE [up_aoag_replicasyncstatus]
	--with encryption
AS
BEGIN
	/************************************************************************
	*									*
	* script   :  up_aoag_replicasyncstatus						*
	* version  :  1.0							*
	* created  :  Cameron Arthur, nov-2017			*
	*									*
	* usage    :  run from main stored proc.					*
	*									*
	* purpose  :  checks AOAG tables for disconnected/unhealthy/unsyncronized databases	*
	*			  					*
	*									*
	* output   :  prints to screen					*
	* files    :  n/a							*
	*									*
	*									*
	*************************************************************************
	*						     modification log	*
	*************************************************************************
	*   date	    programmer	    description				*
	*   ----	    ----------	    -----------				*
	*   Nov-2017	Cameron Arthur version 1.0 - first release version!	*
	************************************************************************/
SET NOCOUNT ON
DECLARE @txt VARCHAR(1000)

------------------------------------------------------------------------------------------------

DECLARE cur CURSOR FOR 

	SELECT 'CRITICAL : '
	+@@SERVERNAME
	+ ': '
	+ [replica_server_name]
	+CASE [connected_state_desc]
		WHEN 'CONNECTED' THEN ''
		ELSE ' Connected State: ' + [connected_state_desc]
	END
	+CASE [st].[synchronization_health_desc]
		WHEN 'HEALTHY' THEN ''
		ELSE ' Health State: ' + [st].[synchronization_health_desc]
	END
	+CASE [das].[synchronization_state_desc]
		WHEN 'SYNCHRONIZED' THEN ''
		WHEN 'SYNCHRONIZING' THEN ''
		ELSE ' Synchronization State: ' + [das].[synchronization_state_desc]
	END
	+ '. Current Role: '
	+[role_desc]
	+'.' 
FROM
sys.dm_hadr_availability_replica_states st 
	INNER JOIN sys.availability_replicas rep
	ON rep.replica_id=st.replica_id
		AND
	rep.group_id=st.group_id
	INNER JOIN sys.dm_hadr_database_replica_states das
	ON rep.replica_id=das.replica_id
		AND
	rep.group_id=das.group_id
WHERE(
	st.connected_state_desc <> 'CONNECTED' 
	OR st.synchronization_health_desc <> 'HEALTHY'
	OR (das.synchronization_state_desc NOT IN ('SYNCHRONIZED','SYNCHRONIZING')
		AND
		rep.availability_mode = 1)
	)

IF @txt IS NULL
	PRINT 'OKAY'

OPEN cur
FETCH NEXT FROM cur INTO @txt
  
WHILE @@FETCH_STATUS = 0
	BEGIN 
		PRINT @txt
		FETCH NEXT FROM cur INTO @txt
	END
  
CLOSE cur
DEALLOCATE cur
END

GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_check_fixed_database_size]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_check_fixed_database_size]
GO

CREATE PROCEDURE [dbo].[up_check_fixed_database_size]
	--with encryption
	
	
		/************************************************************************
	*									*
	* script   :  up_check_fixed_database_size						*
	* version  :  1.0							*
	* created  :  cameron arthur june 2017			*
	*									*
	* usage    :  called from GLIDE main sp					*
	*									*
	* purpose  :  checks max size of databases and percentage of capacity*
	*									*
	* output   :  those that are CLOSE to threshhold				*
	* files    :  n/a							*
	*									*
	*									*
	*************************************************************************
	*						     modification log	*
	*************************************************************************
	*   date	    programmer	    description				*
	*   ----	    ----------	    -----------				*
	*   06 june 2017	cameron arthur version 1.0 - first release version!	*
	************************************************************************/
	
AS
BEGIN
	SET NOCOUNT ON;

DECLARE	
		@msg				VARCHAR(4000),
		@change_count		INT,
		@currentnodename	VARCHAR(128),
		@crlf   			CHAR(2),
		@lstrmsg 			NVARCHAR(400),
		@lintalert			INT,

		-- databasepropertyex
		@name		 		VARCHAR(1000),	
		@status				VARCHAR(20),	
		@isinstandby	 		BIT,
		@updateability	 		VARCHAR(20),
		@useraccess	 		VARCHAR(20)
		
	SET @change_count = 0
	SET @crlf = CHAR(13) + CHAR(10)

	-- database options

	DECLARE table_cursor_1 CURSOR FOR
	SELECT  name,		
		isinstandby,
		status,
		useraccess,
		updateability
	FROM dbo.db_status
	OPEN table_cursor_1

	FETCH NEXT FROM table_cursor_1 INTO
		@name,
		@isinstandby,
		@status,
		@useraccess,
		@updateability
		
SET @msg = ''
WHILE @@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT
	s.[name] AS [logical name],
	s.[file_id] AS [file id],
	 s.[physical_name] AS [file name],
	CAST(CAST(g.name AS varbinary(256)) AS sysname) AS [filegroup_name],
	CONVERT (VARCHAR(10),(s.[size]*8)) + ' kb' AS [size],
	case when s.[max_size]=-1 then 'unlimited' ELSE CONVERT(VARCHAR(10),CONVERT(bigint,s.[max_size])*8) +' kb' END AS [max size],
	case s.is_percent_growth when 1 then CONVERT(VARCHAR(10),s.growth) +'%' ELSE CONVERT(VARCHAR(10),s.growth*8) +' kb' END AS [growth],
	case 
		when s.[type]=0 then 'data only'
	when s.[type]=1 then 'log only'
	when s.[type]=2 then 'filestream only'
	when s.[type]=3 then 'informational purposes only'
	when s.[type]=4 then 'full-text '
	END AS [usage],
	db_name(s.database_id) AS [database name]
	FROM sys.master_files AS s
	LEFT JOIN sys.filegroups AS g ON ((s.type = 2 OR s.type = 0)
	AND (s.drop_lsn is NULL)) AND (s.data_space_id=g.data_space_id)
	WHERE @name = db_name(s.database_id)
	AND (max_size > 0 AND 100 - (size / max_size * 100) < (
		SELECT value
		FROM dbo.entity_settings
										WHERE entity_name = db_name(s.database_id)
										AND setting = 'fixedsizedb_error_percent'))
	)
	BEGIN
		SET @msg = 'CRITICAL : ' + @@SERVERNAME + ' : fixed sized database ' + @name + ' is nearing its capacity'
		PRINT @msg
	END
		FETCH NEXT FROM table_cursor_1 INTO
			@name,
			@isinstandby,
			@status,
			@useraccess,
			@updateability
END

IF @msg = ''
BEGIN
	SET @msg = 'OKAY'
	PRINT @msg
END
CLOSE table_cursor_1
DEALLOCATE table_cursor_1
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_dbmon_module]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_dbmon_module]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_dbmon_module]
	--with encryption
/**********************************************************************
*
* script   :  up_dbmon_module
* version  :  1.0
* created  :  cameron arthur  14-08-2017
*
* usage    :  run from various stored procedures.
*
* purpose  :  checks the dbmon TABLE for any failures or fields that have not been updated for 24 hours
*			  will fire off a CRITICAL message IF any checks fail and a WARNING if they have not been checked for 24 hours.
*
* output   :  n/a
* files    :  n/a
*
*
***********************************************************************
*			     modification log
***********************************************************************
*   date	    programmer	    description
*   ----	    ----------	    -----------
*   
*   14-08-2017  cameron arthur      version 1.0 - first release version!
*
***********************************************************************/

AS
BEGIN
	SET NOCOUNT ON

DECLARE	
		@msg VARCHAR(4000),
		@fail_count INT,
		@crlf CHAR(2),

		@checkname VARCHAR(128),
		@status VARCHAR(128),
		@message VARCHAR(128),
		@last_checked DATETIME

SET @crlf = CHAR(13) + CHAR(10)
SET @fail_count = 0


DECLARE @errorhours INT
SET @errorhours = (SELECT value FROM [GLIDE].[dbo].[entity_settings] WHERE setting = 'dbmon_errorhours')
	IF (@errorhours is NULL)
	BEGIN
		SET @errorhours = 24
	END

DECLARE table_cursor_1 CURSOR FOR
		SELECT
			checkname,
			status,
			message,
			last_checked
	FROM dbo.dbmon_status
	
	OPEN table_cursor_1

FETCH NEXT FROM table_cursor_1 INTO
		@checkname,
		@status,
		@message,
		@last_checked

WHILE @@FETCH_STATUS = 0
BEGIN
	IF (@status = 'fail')
	BEGIN
		SET @msg = 'dbmon module : ' + @message 
		PRINT 'CRITICAL : ' + @@SERVERNAME + ' : ' + @msg
		SET @fail_count = @fail_count + 1
	END
	ELSE
	BEGIN
		SET @msg = 'dbmon module : ' + @checkname  + ' passed'
		PRINT 'INFO : ' + @@SERVERNAME + ' : ' + @msg
	END

	IF (@last_checked < DATEADD(hh,-(@errorhours),GETDATE()))
	BEGIN
		SET @msg = 'dbmon module : ' + @checkname + ' has not been checked for ' + CAST(@errorhours AS VARCHAR) + ' hours.'
		PRINT 'WARNING : ' + @@SERVERNAME + ' : ' + @msg
		SET @fail_count = @fail_count + 1
	END
	ELSE
	BEGIN
		SET @msg = 'dbmon module : ' + @checkname + ' has been updated in the past ' + CAST(@errorhours AS VARCHAR) + ' hours.'
		PRINT 'INFO : ' + @@SERVERNAME + ' : ' + @msg
	END 

	FETCH NEXT FROM table_cursor_1 INTO
		@checkname,
		@status,
		@message,
		@last_checked
END
	
CLOSE table_cursor_1
DEALLOCATE table_cursor_1

PRINT 'OKAY'
END
GO


PRINT 'recreate up_daily_report_main'
GO
--------------------------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[up_daily_report_main]') AND OBJECTPROPERTY(id, N'isprocedure') = 1)
	DROP PROCEDURE [dbo].[up_daily_report_main]
GO
--------------------------------------------------------------------
CREATE PROCEDURE [dbo].[up_daily_report_main]
				--with encryption
/******************************************************************************
*
* script   :  up_daily_report_main
* version  :  2.5
* created  :  doug irwin (GLIDE australia), 23-august-2007
*
* usage    :  runs other stored procedures, returning GLIDE daily report
*                                                                                                             information to original caller.
*
* purpose  :  produce GLIDE daily report.
*
* output   :  GLIDE daily report.
* 
*******************************************************************************
*                                                  modification log
*******************************************************************************
*   date programmer      description
*   ----    ----------               -----------
*   06-12-07         doug irwin          version 2.2 changes - added extra modules
*                                                             functionality.
*   18-02-08         doug irwin          added scheduled task reporting module.
*
*   29-02-08         doug irwin          version 2.2 - first release version!
*
*   05-06-09         graham smith   version 2.3 - corrected spelling mistakes and versions
*
*   09-06-09         graham smith   version 2.4 - basic support package entity settings
*                                                             changed order of checks
*   30-09-14         prashanth paspu version 2.5   mount point capture
******************************************************************************/

AS

BEGIN
				SET NOCOUNT ON
				DECLARE
					@msg VARCHAR(1000),
					@dbname VARCHAR(1000)

				PRINT ''
				PRINT ''
				PRINT '******************************************************'
				PRINT '*'
				PRINT '*          GLIDE daily report version 4.0'
				PRINT '*          ------------------------------'
				PRINT '*          instance '+@@SERVERNAME
				IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'basic_support'))) = 'Y')  --basic support package
				BEGIN   
								PRINT '*'
								PRINT '*               basic support package'     
				END
				PRINT '*'
				PRINT '******************************************************'
				PRINT '*'

				-- make sure all the databases have their own settings.
				DECLARE db_cursor CURSOR FOR
				SELECT name
				FROM master.sys.sysdatabases
				ORDER BY name

				OPEN db_cursor
				FETCH NEXT FROM db_cursor INTO @dbname
	
				WHILE @@FETCH_STATUS = 0
				BEGIN
								EXEC up_check_settings 'database', @dbname
								FETCH NEXT FROM db_cursor INTO @dbname
				END
	
				CLOSE db_cursor
				DEALLOCATE db_cursor

				--run the report
				IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'basic_support'))) = 'N')  --basic support package
				BEGIN
												PRINT ''
												PRINT '------------------------------------------------------'
												PRINT '-                                                     '
												PRINT '-          check sql server availability              '
												PRINT '-                                                     '
												PRINT '------------------------------------------------------'
												PRINT ''
												EXEC dbo.up_daily_report_uptime
				END

				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-          check for changed database status'
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_database_status

				IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'basic_support'))) = 'N')  --basic support package
				BEGIN
												PRINT ''
												PRINT '------------------------------------------------------'
												PRINT '-                                                     '
												PRINT '-          check for changed database options'
												PRINT '-                                                     '
												PRINT '------------------------------------------------------'
												PRINT ''
												EXEC dbo.up_daily_report_database_options
				END

				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-          cycle the errorlog if appropriate          '
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_cycle_errorlog

				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-          check enabled sql server agent jobs        '
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_check_jobs

				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-          check long running jobs                    '
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_long_running

				IF (SERVERPROPERTY('IsHadrEnabled') = 1)
				BEGIN
					PRINT ''
					PRINT ' ------------------------------------------------------'
					PRINT ' -                                                     '
					PRINT ' -          always on database health check            '
					PRINT ' -                                                     '
					PRINT ' ------------------------------------------------------'
					PRINT ''
					EXEC dbo.up_daily_report_ag_dbstatus_GLIDE
				
					PRINT '------------------------------------------------------'
					PRINT '-                                                     '
					PRINT '-          alwayson replica status         '
					PRINT '-                                                     '
					PRINT '------------------------------------------------------'
					PRINT ''
					EXEC [dbo].[up_aoag_replicasyncstatus]

					PRINT ''
					PRINT '------------------------------------------------------'
					PRINT '-                                                     '
					PRINT '-          alwayson role failover capture          '
					PRINT '-                                                     '
					PRINT '------------------------------------------------------'
					PRINT ''
					EXEC [dbo].[up_aoag_rolefailovercapture]
					PRINT ''

					PRINT ''
					PRINT ' ------------------------------------------------------'
					PRINT ' -                                                     '
					PRINT ' -          always on group various status changes     '
					PRINT ' -                                                     '
					PRINT ' ------------------------------------------------------'
					PRINT ''
					EXEC dbo.up_daily_report_agmon_status
				
				END
	EXEC dbo.up_check_settings 'check','up_daily_report_db_space'
	IF (dbo.uf_get_setting('check','up_daily_report_db_space','check_enabled')) = 'y'
	BEGIN
				IF (UPPER(LTRIM(dbo.uf_get_setting('server', '', 'basic_support'))) = 'N')  --basic support package
				BEGIN   
												PRINT ''
												PRINT '------------------------------------------------------ '
												PRINT '-                                                      '
												PRINT '-          check data file growth                      '
												PRINT '-                                                      '
												PRINT '------------------------------------------------------ '
												PRINT ''
												EXEC dbo.up_daily_report_db_space
				END
	END

	EXEC dbo.up_check_settings 'check','up_dbmon_module'
	IF (dbo.uf_get_setting('check','up_dbmon_module','check_enabled')) = 'y'
	BEGIN
				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-                   dbmon checks                      '
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC [dbo].[up_dbmon_module]
	END
	
	EXEC dbo.up_check_settings 'check','up_daily_report_extra_modules'
	IF (dbo.uf_get_setting('check','up_daily_report_extra_modules','check_enabled')) = 'y'
	BEGIN
				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-          run additional modules IF defined          '
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_extra_modules
	END
				
				PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
				PRINT '-          check for changed server options'
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_server_options
				
								PRINT ''
				PRINT '------------------------------------------------------'
				PRINT '-                                                     '
	PRINT '-          up_check_fixed_database_size'
				PRINT '-                                                     '
				PRINT '------------------------------------------------------'
				PRINT ''
				EXEC dbo.up_daily_report_server_options

END
GO
--------------------------------------------------------------------
PRINT ''
PRINT ''
PRINT ' - upgrade complete - GLIDE at 4.0 running test report-'
PRINT 'disable eon alerts'
UPDATE GLIDE.dbo.entity_settings SET value = 'Y' WHERE setting = 'supresseon'
GO
EXEC GLIDE.dbo.up_daily_report_main
GO
PRINT 'enable eon alerts'
UPDATE GLIDE.dbo.entity_settings SET value = 'N' WHERE setting = 'supresseon'


