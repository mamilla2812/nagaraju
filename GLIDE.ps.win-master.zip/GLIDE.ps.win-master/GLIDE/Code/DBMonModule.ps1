<#
Name: DBMonMon
Inputs: $DBMonConfigPath
Outputs: Inserts and Updates table in GLIDE DB
Details: 
Runs a series of checks on the list of servers contained in DBMonConfigPath and updates the GLIDE database with Pass/Fails on each instance. 
#>
Function Check-DBMon($instance){
    
    Function StandardiseOutput ($CheckName, $Result, $Message){
        
        $Object = New-Object -TypeName psobject 
        $object | Add-Member -MemberType NoteProperty -Name "Check_Name" -Value $CheckName
        $object | Add-Member -MemberType NoteProperty -Name "Status" -Value $result
        $object | Add-Member -MemberType NoteProperty -Name "Message" -Value $message
        $object | Add-Member -MemberType NoteProperty -Name "Last_Checked" -Value ("{0:yyyy-MM-dd HH:mm:ss}" -f (get-date))
        return $object
        
    }
    
    # Server - ServerName, Lckpath - C:\xyz\xyz, InputPath - C:\xyz\xyz
    Function CheckVersionDBMON ($Server, $lckPath, $InputPath){
        
        $message = ""
        $LckTest = (Test-Path "\\$server\$lckPath" )
        $InputTest = (Test-Path "\\$server\$inputPath")
        if($LckTest -and $InputTest){
            $intConf = "\\$server\$lckPath\db_mon.cfg"
            $dbConf = "\\$server\$inputPath\db_mon.cfg"
            
            $instrnDBConf = Get-Content $intConf -First 1
            $dbversion = $instrnDBConf
            
            $dbVersion = $dbversion.Split('[')
            $dbVersion = $dbVersion.Split(']')
            $dbversion = $dbVersion[1]
            
            $actualdbConf = Get-Content $dbConf -First 1
            $dbVersionA = $actualdbConf
            $dbVersionA = $dbVersionA.Split('[')
            $dbVersionA = $dbVersionA.Split(']')
            $dbVersionA = $dbVersionA[1]
            
            if($instrnDBConf -eq $actualdbConf){
                $result = 'Pass'
            }
            # this version mismatch is ok
            elseif($dbVersion -like "*10*" -AND $dbVersionA -like "*11*"){
                $result = 'Pass'
                $message = "Version details mismatch between config files."
            }
            else{
                $result = 'Fail'
                $message = "Version details mismatch between config files."
            }
        }   
        else{
            $result = 'Fail'
            if (!($LckTest) -and !($InputTest)){
                $message = "Could not find either DBMON config file"
            }elseif(!($LckTest)){
                $message = "Could not find config file located at $lckPath"
            }elseif(!($InputTest)){
                $message = "Could not find config file located at $inputPath"
            }
        }  
        
        return StandardiseOutput "Check_Version" $Result $Message
    }
    
    # Server - ServerName, InputPath - C:\xyz\xyz, Log_Interval - integer
    Function CheckLogUpdatesDBMON ($server, $inputPath, $log_interval){
        
        $result = "Pass"
        $message = ""
        $InputTest = (Test-Path "\\$server\$inputPath")
        if ($InputTest){
            $dblogpath1 = Get-ChildItem -path "\\$server\$inputPath" -Recurse |  where {$_.Name -eq 'ww_dbmon.log' } 
            $dblogpath2 = Get-ChildItem -path "\\$server\$inputPath" -Recurse |  where {$_.Name -eq 'dbmoncol.log' } 
            
            $ltimelog1 = $dblogpath1.LastWriteTime
            $ltimelog2 = $dblogpath2.LastWriteTime
            
            $dtdiff1 = New-TimeSpan ($dblogpath1.LastWriteTime) $(Get-Date)
            $dtdiff2 = New-TimeSpan ($dblogpath2.LastWriteTime) $(Get-Date)
            
            $errlogpath1 = Get-ChildItem -path "\\$server\$inputPath" -Recurse |  where {$_.Name -eq 'dbmon_err.log' }
            $errlogpath2 = Get-ChildItem -path "\\$server\$inputPath" -Recurse |  where {$_.Name -eq 'dbspierror' }
            
            $ltimeerr1 = $errlogpath1.LastWriteTime
            $ltimeerr2 = $errlogpath2.LastWriteTime
            
            $mindiff1 = New-TimeSpan ($errlogpath1.LastWriteTime) $(Get-Date)
            $mindiff2 = New-TimeSpan ($errlogpath2.LastWriteTime) $(Get-Date)
            
            if ($dtdiff1.TotalMinutes -lt $log_interval -and $dtdiff2.TotalMinutes -lt $log_interval){
                $result = 'Pass'
            }
            
            elseif($mindiff1.TotalMinutes -lt $log_interval -and $mindiff2.TotalMinutes -lt $log_interval){
                $result = 'Fail'
                $message = "ErrorLog was updated within the past $log_interval minutes."
            }
            else{
                $result = 'Fail'
                $message = "Both log files and Error files are not active for $log_interval minutes."
            }
        }Else{
            $result = 'Fail'
            $message = "Both log files and Error files are not active for $log_interval minutes."
        }
        
        return StandardiseOutput "Log_Updates" $Result $Message
        
    }
    
    Function CheckErrorLogStabilityDBMON ($Server, $lckPath, $InputPath, $err_Interval){
        
        $result = "Pass"
        $message = ""
        
        if (Test-Path "\\$server\$inputPath"){
            $errlogpath1 = Get-ChildItem -path "\\$server\$inputPath" -Recurse |  where {$_.Name -eq 'dbmon_err.log'}
            $errlogpath2 = Get-ChildItem -path "\\$server\$inputPath" -Recurse |  where {$_.Name -eq 'dbspierror'}   
        }else{
            $result = 'Fail'
            $message = "Could not find dbmon_err.log and/or dbspierror"
        }
        
        $ltimeerr1 = $errlogpath1.LastWriteTime
        $ltimeerr2 = $errlogpath2.LastWriteTime
        
        if($FLAG){
            
            $mindiff1 = New-TimeSpan ($errlogpath1.LastWriteTime) $(Get-Date)
            $mindiff2 = New-TimeSpan ($errlogpath2.LastWriteTime) $(Get-Date)   
            
            if($mindiff1.TotalHours -lt $err_Interval -and $mindiff2.TotalHours -lt $err_Interval){
                $result = 'Fail'
                $message = 'Both Error logs are active for 24 hrs! Please check the log files'
            }else{
                if(Test-Path "\\$server\$lckPath\db_mon.cfg"){
                    Get-Content "\\$server\$lckPath\db_mon.cfg"  | foreach-object -begin {$dbconfig=@{}} -process { $k = [regex]::split($_,'='); if(($k[0].CompareTo("") -ne 0) -and ($k[0].StartsWith("[") -ne $True) -and ($k[0].StartsWith("#") -ne $True)) { $dbconfig.Add($k[0], $k[1]) } } 
                    $debugSetting = $dbconfig.DEBUG
                    if($debugSetting -eq 'TRUE'){
                        $result = 'Fail'
                        $message = "Debug setting in db_mon.cfg set to TRUE"
                    }
                    else{
                        $result = 'Pass'
                    }
                }
                else{
                    $result = 'Fail'
                    $message = "db_mon.cfg is not found in $server"
                }
            }
        }
        return StandardiseOutput "Errorlog_Stability" $Result $Message
    }
    
    Function CheckLockFileUpdatesDBMON($Server, $lckPath){
        
        $LockFileArr = @()
        $FLAG = $TRUE
        try{
            $lckFiles = Get-ChildItem -path "\\$server\$lckPath" -Recurse -ErrorAction stop |  where {$_.Name -match '^*lock.[\d+|\w+]\w+' }
        }Catch{
            $result = "Fail"
            $message = "Could not find lock files."
            $FLAG = $FALSE
        }
        
        [regex]$regex = '\d+\w+'
        if ($FLAG){
            foreach ($lckFile in $lckFiles){
                $message = ""
                $fileName =  $lckFile.Name
                
                if ($($regex.Matches($lckFile)[0].success) -eq $true){
                    $lock += @{$lckFile = $($regex.Matches($lckFile)[0].captures)} # Taking time interval with respective Filenames
                    $timeframe = $($regex.Matches($lckFile)[0].captures)
                    if($timeframe -match '\d+'){ # Segregating the Digits and Time
                        $digit = $Matches[0]
                        
                        if($timeframe -match '[a-z]'){
                            $frame=$Matches[0]
                            
                            if($frame -eq 'm'){   
                                $finalFile = Get-ChildItem -path "\\$server\$lckPath" -Recurse |  where {$_.Name  -eq $fileName} 
                                
                                $finalFiletime = New-TimeSpan ($finalFile.LastWriteTime) $(Get-Date) 
                                $lastupdated = $finalFile.LastWriteTime
                                
                                if($finalFiletime.TotalMinutes -lt ($digit + 1)){
                                    $result = "Pass"
                                }
                                else{
                                    $result = "Fail"
                                    $message = "Lock File $fileName not updated within $digit minutes"
                                }
                            }
                            
                            if($frame -eq 'd'){
                                $finallckd = Get-ChildItem -path "\\$server\$lckPath" -Recurse |  where {$_.Name  -eq $fileName} 
                                $finalLckday = New-TimeSpan ($finallckd.LastWriteTime) $(Get-Date) 
                                
                                $lastupdatedday=$finallckd.LastWriteTime
                                
                                if($finalLckday.Days -lt $digit){
                                    $result = "Pass"
                                }
                                else{
                                    $result = "Fail"
                                    $message = "Lock File $fileName not updated within $digit days"
                                }
                            }
                            
                            if($frame -eq 'h'){
                                $finallckh = Get-ChildItem -path "\\$server\$lckPath" -Recurse |  where {$_.Name  -eq $fileName} 
                                $finalLckhr = New-TimeSpan ($finallckh.LastWriteTime) $(Get-Date) 
                                
                                $lastupdatedhr=$finallckh.LastWriteTime
                                
                                if($finalLckhr.TotalHours -lt $digit){
                                    $result = "Pass"
                                }
                                else{
                                    $result = "Fail"
                                    $message = "Lock File $fileName not updated within $digit hours"
                                }
                            }
                        }
                    }else{ # lockfile does not contain digits but it is there
                        $result = "Pass"
                    }
                }
                $LockFileArr += StandardiseOutput "$FileName`_Update" $Result $Message
            }
            $LockFileArr += StandardiseOutput "LockFiles_Present" "Pass" ""
        }
        else{
            $LockFileArr += StandardiseOutput "LockFiles_Present" $Result $Message
        }
        return $LockFileArr
    }
    
    Function CheckSaveStoreDBMON($Server, $lckPath, $SaveStore_Interval){
        
        $message = ""
        if (Test-Path "\\$server\$lckPath"){
            $dbstrFile  = Get-ChildItem -path "\\$server\$lckPath" -Recurse |  where {$_.Name -eq 'dbmon_save.store' } 
            
            #$ltimestrFile = $dbstrFile.LastWriteTime
            
            $strdiff = New-TimeSpan ($dbstrFile.LastWriteTime) $(Get-Date)
            $storeTime = $dbstrFile.LastWriteTime
            
            if ($strdiff.TotalMinutes -lt $SaveStore_Interval){
                $result = 'Pass'
            }
            else{
                $result = 'Fail'
                $message = "DBMon Save store not updated within $SaveStore_Interval minutes."
            }
        }Else{
            $result = 'Fail'
            $message = "Could not find DBMon Save Store file"
        }
        return StandardiseOutput "SaveStore_Update" $Result $Message
    }
        
    Function MainCheckDBMON($Server,$lckPath,$InputPath,$InstrumentationPath,$log_interval,$err_Interval,$SaveStore_Interval){
        # For clusters the network share isn't set up to point to the c drive of the host that the instance is sitting on.
        # need to find a way of getting the hostname of the host of the instance to check dbmon
        # the paths of the lock files etc should be standard so this could be hard coded into a variable
        $DBMonCheckArr = @()
        $DBMonCheckArr += CheckVersionDBMON $Server $lckPath $InstrumentationPath
        $DBMonCheckArr += CheckLogUpdatesDBMON $server $inputPath $log_interval
        $DBMonCheckArr += CheckErrorLogStabilityDBMON $Server $lckPath $InputPath $err_Interval
        $LockFileArr = CheckLockFileUpdatesDBMON $Server $lckPath
        foreach ($Item in $LockFileArr){
            $DBMonCheckArr += $Item
        }
        $DBMonCheckArr += CheckSaveStoreDBMON $Server $lckPath $SaveStore_Interval
        return $DBMonCheckArr
    }
    

    #get all nodes that the instance is hosted on.
    $serverList = New-Object System.Data.DataTable
    $col1 = New-Object system.Data.DataColumn ServerName,([string])
    $col2 = New-Object system.Data.DataColumn InstanceName,([string])
    $serverList.columns.add($col1)
    $serverList.columns.add($col2)
    $queryServerName = "
    IF SERVERPROPERTY('isclustered') = 1
    BEGIN
        SELECT NodeName AS ServerName
        FROM sys.dm_os_cluster_nodes
    END
    ELSE
    BEGIN
        SELECT serverproperty('computernamephysicalnetbios') AS ServerName
    END
    "

    $rawServerList = SQLSelectQuery $instance $queryServerName
    foreach ($server in $rawServerList) {
        $row = $ServerList.NewRow()
        $row.serverName = $server.ServerName
        $row.instanceName = $instance
        $serverList.Rows.Add($row)
    }

    #Collect intervals/config from a single file.
    $errorArray = @()
    foreach ($server in $serverlist) {
        $serverStartTime = Get-Date
        $Server = $object.ServerName
        $Instance = $object.Instance
        $lckPath = 'C$\usr\OV\dbspi'
        $InputPath = 'C$\usr\OV\dbspi\log'
        $InstrumentationPath = 'C$\Program Files\HP OpenView\Data\bin\instrumentation'
        $log_interval = 5
        $err_Interval = 5
        $SaveStore_Interval = 5

        write-host "Running DBMon Module for $Server $counter/$($ConfigFile.count)" -BackgroundColor white -ForegroundColor black 

        try{
            $Result = MainCheckDBMON $Server $lckPath $InputPath $InstrumentationPath $log_interval $err_Interval $SaveStore_Interval
        }Catch{
            $errors = ErrorCodes -13 $Instance
            Write-Host "$errors" -BackgroundColor Black -ForegroundColor Red
            $errorArray += $errors
        }
        try{
            SQLUpdateQuery $instance (BuildInsertCommand $Result)
        }catch{
            $errors = ErrorCodes -14 $Instance
            Write-Host "$errors" -BackgroundColor Black -ForegroundColor Red
            $errorArray += $errors
        }
        try{
            SQLUpdateQuery $instance (BuildUpdateCommand $Result)
        }catch{
            $errors = ErrorCodes -15 $Instance
            Write-Host "$errors" -BackgroundColor Black -ForegroundColor Red
            $errorArray += $errors
        }
    }
}
