<#
Name: Check-Disks
Inputs: $Instance
Outputs: Array of disk errors
Details: 
If instance is clustered
    gets all nodes of the cluster
Else
    get the name of the server that is hosting the instance
Stores all the names of servers for the instance into an array
For each server run the powershell command to bring back all disks
Query the instance for its entity settings for the list of disks
For each disk
    calulate the free space
    create warnings/critcals for issues
    store in array
return the array of disk errors
#>

Function Check-Disks ($instance) {
    
    $alerts = @()
    if ($null -eq $global:serverDisksChecked) {
        $global:serverDisksChecked = @{}
    }
    $serverList = New-Object System.Data.DataTable
    $col1 = New-Object system.Data.DataColumn ServerName,([string])
    $col2 = New-Object system.Data.DataColumn InstanceName,([string])
    $serverList.columns.add($col1)
    $serverList.columns.add($col2)
    $queryServerName = "
    IF SERVERPROPERTY('isclustered') = 1
    BEGIN
        SELECT NodeName AS ServerName
        FROM sys.dm_os_cluster_nodes
    END
    ELSE
    BEGIN
        SELECT serverproperty('computernamephysicalnetbios') AS ServerName
    END
    "
    
    $rawServerList = SQLSelectQuery $instance $queryServerName
    foreach ($server in $rawServerList) {
        $row = $ServerList.NewRow()
        $row.serverName = $server.ServerName
        $row.instanceName = $instance
        $serverList.Rows.Add($row)
    }
    
    
    foreach ($server in $serverList) {
        if(!($global:serverDisksChecked.ContainsKey($server.ServerName))) {
            $disks = get-wmiobject -computername $server.ServerName -class win32_volume -filter 'drivetype = 3' | Select-Object name, @{name='freespace'; Expression = {[math]::round($_.freespace/1mb,0)}}, @{name='capacity'; Expression = {[math]::round($_.capacity/1mb,0)}}, @{name='PercFree' ; Expression = {[math]::round(100*$_.freespace/$_.capacity,1)}}
            
            # getting the disk settings for the instance on the server
            $diskEntitySettingsQuery = '
            USE [GLIDE]
            SET NOCOUNT ON
            DECLARE @errorperc AS FLOAT
            DECLARE @warnperc AS FLOAT
            DECLARE @exclude AS VARCHAR(1)
            CREATE TABLE #disk_settings (
                name VARCHAR(50),
                exclude VARCHAR(1),
                warning FLOAT,
                error FLOAT,
                freespace INT,
                capacity INT,
                percfree FLOAT
            )'
            $diskEntitySettingsQuery += "`n`r"
            foreach ($disk in $disks) {
                $diskname = $disk.name.replace('\','_')
                $diskname = $diskname.replace(':','')
                #removes the trailing _ in the name
                $diskname = $diskname[0..($diskname.length -2)] -join ''
                if ($diskname.length -le 15){
                    $diskEntitySettingsQuery += "EXEC up_check_settings 'disk', '$($diskname)'`n`r"
                    $diskEntitySettingsQuery += "SET @warnperc = dbo.uf_get_setting('disk', '$($diskname)', 'warning_percent')`n`r"
                    $diskEntitySettingsQuery += "SET @errorperc = dbo.uf_get_setting('disk', '$($diskname)', 'error_percent')`n`r"
                    $diskEntitySettingsQuery += "SET @exclude = LEFT(dbo.uf_get_setting('disk', '$($diskname)', 'exclude'),1)`n`r"
                    $diskEntitySettingsQuery += "INSERT INTO #disk_settings (name, exclude, warning, error, freespace, capacity, percfree) SELECT '$($diskname)', @exclude, @warnperc, @errorperc, '$($disk.freespace)', '$($disk.capacity)', '$($disk.PercFree)'`n`r"
                }
            }
            $diskEntitySettingsQuery += "SELECT * FROM #disk_settings"
            try{
                $diskSettings = SQLSelectQuery $server.InstanceName $diskEntitySettingsQuery
                #checking if there are any issues
                foreach ($disk in $diskSettings) {
                    $diskname = $disk.name
                    $errorflag = $false
                    if ($disk.exclude -ne 'y'){
                        if ($disk.percfree -le $disk.error) {
                            $severity = "CRITICAL"
                            $threshold = $disk.error
                            $errorflag = $true
                        } elseif ($disk.percfree -lt $disk.warning) {
                            $severity = "WARNING"
                            $threshold = $disk.warning
                            $errorflag = $true
                        }
                        if ($errorflag) {
                            $alerts += "$($severity): $($server.ServerName) : Disk space on drive $diskname currently only $($disk.percfree)% is free ($($disk.freespace) out of $($disk.capacity)mb remaining). This is less than the $($threshold)% error threshold."
                        } else {
                            $alerts += "INFO: $($server.ServerName) : Disk space on drive $diskname currently $($disk.percfree)% is free ($($disk.freespace) out of $($disk.capacity)mb remaining)."
                        }
                    } else {
                        $alerts += "INFO: $($server.ServerName) : Disk excluded in entity setting : Disk space on drive $diskname currently $($disk.percfree)% is free ($($disk.freespace) out of $($disk.capacity)mb remaining)."
                    }
                }
                $global:serverDisksChecked.add($server.ServerName, $server.InstanceName)
            }
            catch {
                write-host "disk check failed $($server.servername) $($server.instancename)" -BackgroundColor Red -ForegroundColor Black
		throw $error[0]
            }
        } else {
            $alerts = "Disks checked on $($global:serverDisksChecked."$($server.ServerName)")"
        }
    }
    if ($alerts.count -ne 0) {
        return $alerts
    } else {
        return @("OKAY")
    }
}

