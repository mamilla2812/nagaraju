<#
Name: Check-Backups
Inputs: $InstanceListPath
Outputs: Array of backup errors
Details:
foreach instance
    if server is part of AOAG
        if primary replica
            check all backups
            if not backed up on primary
                check other nodes in AOAG
                if not backed up on other nodes
        else
            check non AOAG databases backups
    else
        check all backups
    create warnings/critcals for issues
    store in array 
return the array of backup errors
#>
Function Check-Backups ($instance) {

    $alerts = @()
    $queryHADRenabled = "
        SELECT SERVERPROPERTY('IsHadrEnabled') AS hadr_enabled
    "
    
    $queryAOAGDbs = "
        SELECT
	        @@servername as server_name,
	        bus.database_name,
	        CASE type
	    	    WHEN 'D' THEN 'FULL'
		        WHEN 'I' THEN 'DIFFERENTIAL'
		        WHEN 'L' THEN 'TRANSACTION LOG'
		        ELSE 'NONE'
	        END AS type,
	        DATEDIFF(HH, max(backup_finish_date), GETDATE()) as hours_since_last_backup
        FROM msdb..backupset bus
        INNER JOIN sys.availability_databases_cluster adbc ON bus.database_name = adbc.database_name
        GROUP BY bus.database_name, type
    "

    $queryAOAGNodes = "
        SELECT replica_server_name AS name
        FROM sys.dm_hadr_availability_replica_cluster_states
        WHERE replica_server_name <> @@SERVERNAME
    "
    $queryMaxThreshold = "
        SELECT CONVERT(INT, GLIDE.dbo.uf_get_setting('bkup_check','','maximum_days_backup_check')) AS max_threshold
    "

    $queryFullBackups = Get-Content "$PSSCriptRoot\SQL\backupsWithSettingsFull.sql" -raw
    $queryTlogBackups = Get-Content "$PSSCriptRoot\SQL\backupsWithSettingsTLog.sql" -raw
    $queryDiffBackups = Get-Content "$PSSCriptRoot\SQL\backupsWithSettingsDiff.sql" -raw

    $hadrEnabled = (SQLSelectQuery $instance $queryHADRenabled).hadr_enabled
    
    # dynamically add the filter to only show preferred backup replica for DBs in AOAG
    # this is so we dont check for backups that dont occur on non preferred backup replicas
    $queryBackups = $queryFullBackups
    if ($hadrEnabled -eq 1) {
        $queryBackups += ' HAVING sys.fn_hadr_backup_is_preferred_replica(vdb.name) = 1'
        $aoagNodes =  $null
    }
    $queryBackups += "`r`nUNION ALL`r`n"
    $queryBackups += $queryTlogBackups
    if ($hadrEnabled -eq 1) {
        $queryBackups += ' HAVING sys.fn_hadr_backup_is_preferred_replica(vdb.name) = 1'
        $aoagNodes =  $null
    }
    $queryBackups += "`r`nUNION ALL`r`n"
    $queryBackups += $queryDiffBackups
    if ($hadrEnabled -eq 1) {
        $queryBackups += ' HAVING sys.fn_hadr_backup_is_preferred_replica(vdb.name) = 1'
        $aoagNodes =  $null
    }

    $backups = SQLSelectQuery $instance $queryBackups
    $maxThreshold = (SQLSelectQuery $instance $queryMaxThreshold).max_threshold
    foreach ($backup in $backups) {
        $errorflag = $false
        if ($backup.ignore -eq 'y') {
            $alerts += "INFO: $instance : database $($backup.name) has its's $($backup.type) backup ignored in entity_settings"
        } else {
            $ignoreDays = 0
            if ($null -ne $backup.backup_days) {
                $backupDays = $backup.backup_days.ToUpper().split(',')
                while (!($backupDays.Contains((Get-Date).AddDays(-($ignoreDays)).ToString('ddd').ToUpper())) -and $ignoreDays -lt 7) {
                    $ignoreDays++
                }
            }
            $hoursSinceLastBackup = $backup.hours_since_last_backup - ($ignoredays*24)
            if ($hoursSinceLastBackup -ge $backup.critical_threshold -and $backup.critical_threshold -ne -1) {
                $severity = "CRITICAL"
                $threshold = "$($backup.critical_threshold) hours"
                $errorflag = $true
            } elseif ($hoursSinceLastBackup -ge $backup.warning_threshold) {
                $severity = "WARNING"
                $threshold = "$($backup.warning_threshold) hours"
                $errorflag = $true
            } elseif ($backup.hours_since_last_backup -eq '-1') {
                $severity = "CRITICAL"
                $threshold = "$maxThreshold days"
                $errorflag = $true
            }
            # if the aoag db backup failed
            if ($hadrEnabled -eq 1 -and $errorflag -eq $true) {
                if ($null -eq $aoagNodes) {
                    $aoagNodes = SQLSelectQuery $instance $queryAOAGNodes
                    $aoagDbs = New-Object System.Data.DataTable
                    foreach ($node in $aoagNodes) {
                        $aoagDbs.Merge((SQLSelectQuery $node.name $queryAOAGDbs))
                    }
                    $aoagDbsview = New-Object System.Data.Dataview($aoagDbs)
                    $aoagDbsview.sort = "database_name"
                }
                $aoagDbsView.RowFilter = ""
                if ($aoagDbsview.Find($backup.name) -ne -1) {
                    $aoagDbsview.RowFilter = "database_name = '$($backup.name)' and type = '$($backup.type)'"
                    # find the minimum non -1 value to find the most recent backup
                    # set the -1 values to the max threshold in hours
                    $aoagDbsview | %{
                        if ($_.hours_since_last_backup -eq -1){
                            $_.hours_since_last_backup = $maxThreshold * 24
                        }
                    }
                    # check for minimum backup time
                    $otherNodeLastBackup = ($aoagDbsview|Measure-Object -Property hours_since_last_backup -Minimum).Minimum
                    # critical threshold is -1 for non full backups
                    # only full backups have a critical threshold while all backups have warning thresholds
                    if ($backup.critical_threshold -ne -1) {
                        if ($otherNodeLastBackup -le $backup.warning_threshold) {
                            $errorflag = $false
                        } elseif ($otherNodeLastBackup -le $backup.critical_threshold) {
                            $severity = "WARNING"
                            $threshold = "$($backup.warning_threshold) hours"
                        }
                    } elseif ($otherNodeLastBackup -le $backup.warning_threshold) {
                        $errorflag = $false
                    }
                }
            }
        }
        if ($errorflag) {
            $alerts += "$($severity): $($instance): database `"$($backup.name)`" has not had a $($backup.type) backup performed in the last $threshold."
        }
    }

    if($alerts.count -ne 0) {
        return $alerts
    } else {
        return @("OKAY")
    }
}