$MainStoredProc = "dbo.up_daily_report_main"
$SQLSelectDatabases = "select name from master..sysdatabases"
$GlideVersion = "v4.0"


<#
Name: N/A
Inputs: $PSScriptRoot
Outputs: $PSScriptRoot
Details: 
Checks the variable $PSScriptRoot.
If the variable contains no information (ie. PowerShell version 2 or below) it will update it with the current script path.
#>
if (!($PSScriptRoot)) {
    $PSScriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
}


<#
Name: GetGlideDirectory
Inputs: N/A
Outputs: Path where GLIDE is running
Details: 
Returns the parent folder of where GLIDE is running
#>
Function GetGlideDirectory() {
    $Path = (get-item "$PSScriptRoot").Parent.FullName
    $path += "\"
    return $Path
}

# adding the functions in these scripts 
. "$PSScriptRoot\check-disks.ps1"
. "$PSScriptRoot\check-backups.ps1"

<#
Name: SQLSelectQuery
Inputs: $instance, $SQLSelectDatabases
Outputs: $Datatable or ErrorCodes -3
Details: 
Connects to SQL Server and runs the command stored in $SQLSelectDatabases.
This command will be a select statement, and therefore the function will return a table result. 
#>
Function SQLSelectQuery($instance, $SQLSelectDatabases) {
    
    $SqlConnString = "server=$instance;database=master;Integrated Security=true"
    $SqlTQSL = $SQLSelectDatabases
    
    $SQLConn = new-object System.Data.SqlClient.SqlConnection $SQLconnString
    try {
        
        $SQLConn.open()
        $SQLCommand = $SQLConn.CreateCommand()
        $SQLCommand.CommandText = $SqlTQSL
        $SQLCommand.CommandTimeout = 60
        
        $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $SqlCommand
        $DataTable = New-Object System.Data.DataTable
        
    } catch {
        throw ErrorCodes -1 $instance
        write-error $error[0]
    }
    
    try {
        $SqlAdapter.Fill($DataTable) |Out-Null
    } catch {
        throw ErrorCodes -2 $instance
    }
    
    $SQLConn.Close()
    
    if ($DataTable.rows.count -ge 0 ) {
        return ,$DataTable
    } else {
        throw ErrorCodes -3 $instance
    }
    
}

<#
Name: SQLUpdateQuery
Inputs: $instance, $SQLUpdateDatabases
Outputs: ErrorCodes -1, -9, -10
Details: 
Connects to SQL Server and runs the command stored in $SQLUpdateDatabases.
This command will be an update statement, and therefore the function will not return a table result. 
#>
Function SQLUpdateQuery($instance, $SQLUpdateDatabases) {
    
    $SqlConnString = "server=$instance;database=master;Integrated Security=true"
    $SqlTQSL = $SQLUpdateDatabases
    
    $SQLConn = new-object System.Data.SqlClient.SqlConnection $SQLconnString
    try {
        
        $SQLConn.open()
        $SQLCmd = new-object "System.data.sqlclient.sqlcommand"
        $SQLCmd.connection = $SQLConn
        $SQLCmd.CommandTimeout = 600000
        $SQLCmd.CommandText = $SqlTQSL
        
    } catch {
        throw ErrorCodes -1 $instance
    }
    
    try {
        $rowsAffected = $sqlcmd.ExecuteNonQuery()
    } catch {
        throw ErrorCodes -9 $instance
    }
    
    $SQLConn.Close()
    
    if ($rowsAffected -lt 1) {
        throw ErrorCodes -10 $instance
    }
    
}

<#
Name: CheckGlideDB
Inputs: $DataSet, $instance
Outputs: GLIDE, EDS, <Integer>, ErrorCodes -4 
Details: 
Checks if the given dataset contains a GLIDE or EDS database. 
Will prioritise GLIDE (ie will return GLIDE if both GLIDE and EDS exists in the dataset).
To check for more databases, add the following code to the "if ($Databasename -like "GLIDE") {" block:
elseif($Databasename -like "NEWDATABASENAME") {
    $temp = "NEWDATABASENAME"
}

If the dataset is a single number, which means that an error had occurred, the function will instead return it.
This will cause a failed report for that instance. 
#>
Function CheckGlideDB($DataSet, $instance) {
    $temp = $NULL
    if (!($DataSet -is [int])) {
        $temparr = @()
        foreach ($row in $Dataset) {
            $temparr += $Row.Name
        }
        foreach ($Databasename in $temparr) {
            
            if ($Databasename -like "GLIDE") {
                return $Databasename
            } elseif ($Databasename -like "EDS") {
                $temp = "EDS"
            }
            
        }
        if ($null -eq $temp) {
            throw ErrorCodes -4 $instance
        } else {
            return $temp
        }
    } else {
        return $DataSet
    }
    
}

<#
Name: CreateReport
Inputs: $instance, $Database, $MainStoredProc, $filepath, $ReportPrefix
Outputs: None, ErrorCodes -5
Details: 
Used to call the Stored procedure which calls the main stored procedure of GLIDE.
Insert functions and stored procedure calls here to add to the report.
The GLIDE report is stored at $filepath
#>
Function CreateReport($instance, $Database, $MainStoredProc, $filepath, $ReportPrefix) {
    
    try {
        RunStoredProc $instance $Database $filepath $MainStoredProc $ReportPrefix
    } catch {
        throw ErrorCodes -5 $instance
    }
}

<#
Name: RunStoredProc
Inputs: $instance, $GlideDB, $FilePath, $Query, $ScheduleTaskMessage
Outputs: append to $FilePath
Details: 
The output of this function is to a text file
This function connects to SQL, runs the given stored procedure and collects its message box, which it then outputs to a text file. 
#>
Function RunStoredProc($instance, $GlideDB, $FilePath, $Query, $ScheduleTaskMessage) {
    
    $SQLConnString = "Server=$instance;Database=$GlideDB;Integrated Security=SSPI;"
    $SQLConn = new-object System.Data.SqlClient.SqlConnection $SQLconnString 
    $SQLHandler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {param($sender, $event) Out-File -filepath $FilePath -inputobject $event.Message -Append};
    
    $SQLConn.add_InfoMessage($SQLhandler)
    $SQLConn.FireInfoMessageEventOnUserErrors = $true
    $SQLConn.Open()
    $SQLCmd = new-object System.Data.SqlClient.SqlCommand("$Query",$SQLConn)
    $SQLCmd.CommandTimeout=300
    $SQLCmd.CommandType = [System.Data.CommandType]"StoredProcedure"
    "INFO: $instance : Connection OK" >> $FilePath
    "" >> $FilePath
    $ReportPrefix >> $FilePath
    $SQLCmd.ExecuteNonQuery() | Out-Null
    $SQLConn.Close()
    
    "
    
------------------------------------------------------
-                                                     
-                  Backup Checks          
-                                                     
------------------------------------------------------
" >> $FilePath
    try {
        Check-Backups $instance | Foreach-Object{ $_ >> $FilePath}
    } catch {
        "CRITICAL: $instance : Backup check failed to run" >> $FilePath
    }
    "
------------------------------------------------------
-                                                     
-             Disk and Mountpoint Checks          
-                                                     
------------------------------------------------------
" >> $FilePath
    try {
        Check-Disks $instance | Foreach-Object{ $_ >> $FilePath}
    } catch {
        "CRITICAL: $instance : Disk check failed to run" >> $FilePath
    }
}

<#
Name: CheckDirectoryStructure
Inputs: $LocalFilepath
Outputs: None (folders are created)
Details: 
Checks for the correct directory structure for the report files in the installed path.
#>
function CheckDirectoryStructure($LocalFilepath) {
    
    $Year = (get-date).Year
    
    if (!(test-path "$LocalFilepath\Reports\ArchivedReports\$year")) {
        new-item "$LocalFilepath\Reports\ArchivedReports\$year" -ItemType Directory | out-null
    }
    if (!(test-path "$LocalFilepath\Reports\CurrentReports")) {
        new-item "$LocalFilepath\Reports\CurrentReports" -ItemType Directory | out-null
    }
    
    #Used to test if folders are missing
    if (!((Get-ChildItem -Path "$LocalFilepath\Reports\ArchivedReports\$year\").count -eq 13)) {
        $PresentDirectories = @()
        $ExpectedDirectories = @()
        $MissingDirectories = @()
        $presentDirectoriesArr = @()
        $PresentDirectories = get-childitem -path "$LocalFilepath\Reports\ArchivedReports\$year\"
        $ExpectedDirectories += "01JAN"
        $ExpectedDirectories += "02FEB"
        $ExpectedDirectories += "03MAR"
        $ExpectedDirectories += "04APR"
        $ExpectedDirectories += "05MAY"
        $ExpectedDirectories += "06JUN"
        $ExpectedDirectories += "07JUL"
        $ExpectedDirectories += "08AUG"
        $ExpectedDirectories += "09SEP"
        $ExpectedDirectories += "10OCT"
        $ExpectedDirectories += "11NOV"
        $ExpectedDirectories += "12DEC"
        $ExpectedDirectories += "OtherFiles"
        foreach ($element in $PresentDirectories) {
            $PresentDirectoriesArr += $element.Name
        }
        $MissingDirectories = $ExpectedDirectories | Where-Object {$PresentDirectoriesArr -notcontains $_}
        
        
        foreach ($Directory in $MissingDirectories) {
            new-item "$LocalFilepath\Reports\ArchivedReports\$year\$Directory" -ItemType Directory | out-null
        }
    }
    
}

<#
Name: ArchiveReports
Inputs: $LocalFilepath,$DATE,$GLIDEREPORTNAME
Outputs: None (Files are moved)
Details: 
Checks for the files present in the "CurrentReports" folder and moves those that are not from the current day to the matching archive directory 
#>
Function ArchiveReports($LocalFilepath,$DATE,$GLIDEREPORTNAME) {
    
    if ((Get-Date).DayOfYear -eq 1) {
        $year = ((get-date).Year) - 1
    }else {$Year = (get-date).Year}
    
    $Filelist = @()
    $Filelist = get-childitem -path "$LocalFilePath\Reports\CurrentReports\"
    $SourceDirectory = "$LocalFilePath\Reports\CurrentReports\"
    $DestinationDirectory = "$LocalFilepath\Reports\ArchivedReports\$year\"
    
    foreach ($file in $filelist) {
        
        if (!($file -like "*$DATE*")) {
            
            switch -Wildcard ($file.Name) {
                ("$GLIDEREPORTNAME*jan$year*.txt") {move-item "$SourceDirectory$file" "$DestinationDirectory\01JAN" -verbose}
                ("$GLIDEREPORTNAME*feb$year*.txt") {move-item "$SourceDirectory$file" "$DestinationDirectory\02FEB" -verbose}
                ("$GLIDEREPORTNAME*mar$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\03MAR" -verbose}
                ("$GLIDEREPORTNAME*apr$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\04APR" -verbose}
                ("$GLIDEREPORTNAME*may$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\05MAY" -verbose}
                ("$GLIDEREPORTNAME*jun$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\06JUN" -verbose}
                ("$GLIDEREPORTNAME*jul$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\07JUL" -verbose}
                ("$GLIDEREPORTNAME*aug$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\08AUG" -verbose}
                ("$GLIDEREPORTNAME*sep$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\09SEP" -verbose}
                ("$GLIDEREPORTNAME*oct$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\10OCT" -verbose}
                ("$GLIDEREPORTNAME*nov$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\11NOV" -verbose}
                ("$GLIDEREPORTNAME*dec$year*.txt*") {move-item "$SourceDirectory$file" "$DestinationDirectory\12DEC" -verbose}
                Default {move-item "$SourceDirectory$file" "$DestinationDirectory\OtherFiles" -verbose}
                
            }
        }
    }
    
}

<#
Name: CheckConnectivity
Inputs: $instance
Outputs: TRUE/FALSE
Details: 
Attempts to connect to the given instance.
If it fails, it pauses for 60 seconds before attempting again, repeating this 
#>
Function CheckConnectivity($instance) {
    if (test-connection -count 1 -ComputerName $instance -Quiet) {
        return $TRUE
    }
    else{
        Start-Sleep 60
        if (test-connection -count 2 -Delay 60 -ComputerName $instance -Quiet) {
            return $TRUE
        }
        return $FALSE
    }
    return $FALSE
    
}

<#
Name: CombineReports
Inputs: $filePathArray
Outputs: $CompleteReport
Details: 
Take a GLIDE report and formats it with a header + footer so the reader can distinguish where one report ends and the other begins
#>
Function CombineReports($filePathArray) {
    
    $CompleteReport = @()
    foreach ($FilePath in $filePathArray) {
        
        $CompleteReport += ""
        $CompleteReport += ""
        $CompleteReport += "+-+-+-+-+-START INSTANCE REPORT-+-+-+-+-+"
        $CompleteReport += ""
        $CompleteReport += ""
        $CompleteReport +=Get-Content $FilePath
        $CompleteReport += ""
        $CompleteReport += ""
        $CompleteReport += "+-+-+-+-+- END INSTANCE REPORT -+-+-+-+-+"
        $CompleteReport += ""
        $CompleteReport += ""
        
    }
    return $CompleteReport
}

<#
Name: TimeScript
Inputs: $StartTime
Outputs: "Elapsed Time of report: $ElapsedMins minutes $ElapsedSecs seconds"
Details: 
Takes in a start time variable and outputs a message based on the elapsed time. 
#>
Function TimeScript($StartTime) {
    
    $ElapsedTime = (get-date) - $startTime
    $ElapsedMins = $ElapsedTime.minutes
    $ElapsedSecs = $ElapsedTime.seconds
    return "Elapsed Time of report: $ElapsedMins minutes $ElapsedSecs seconds"
}

<#
Name: ProcessReport
Inputs: $CompleteReport, $ElapsedTime, $TotalInstanceArray, $ConnectedInstanceArray, $HostInstance
Outputs: $GlideReport
Details: 
Takes the main input of $CompleteReport and calculates the number of warning and critical messages.
It then calls BuildReport passing in the newly found parameters. 
After the report is built, it then attempts to email the report as per the configuration file. 
If the email fails, the report adds in a new message to the critical list and re runs the BuildReport function. 
#>
Function ProcessReport($CompleteReport, $ElapsedTime, $TotalInstanceArray, $ConnectedInstanceArray, $HostInstance) {
    
    $GlideReport = @()
    $Availability = New-Object System.Collections.ArrayList
    $Backups = New-Object System.Collections.ArrayList
    $DiskSpace = New-Object System.Collections.ArrayList
    $Jobs = New-Object System.Collections.ArrayList
    $AGStatus = New-Object System.Collections.ArrayList
    $Others = New-Object System.Collections.ArrayList
    
    
    #Parse the complete report and only take the Criticals and Warnings
    for ($i=0;$i -lt $CompleteReport.Length;$i++) {
        #Availability Checks
        if ($CompleteReport[$i] -like "*Unable to ping server. Server is unreachable*" `
        -or $CompleteReport[$i] -like "*Unable to open connection to SQL Instance*" `
        -or $CompleteReport[$i] -like "*Unable to connect*" `
        -or $CompleteReport[$i] -like "*No server specified*" `
        -or $CompleteReport[$i] -like "*CRITICAL*database*is in*mode*"`
        -or $CompleteReport[$i] -like "*CRITICAL*Unable to run stored proc:*") {
            
            $Availability.Add($CompleteReport[$i]) | Out-Null
            
            #Backup Checks
        } elseif ($CompleteReport[$i] -like "*has not had a*backup performed*" `
            -or $CompleteReport[$i] -like "*backup check failed to run*") {
            
            $Backups.Add($CompleteReport[$i]) | Out-Null
            
            #Disk Checks
        } elseif ($CompleteReport[$i] -like "CRITICAL*Disk space on drive*This is less than the*" `
            -or $CompleteReport[$i] -like "WARNING*Disk space on drive*This is less than the*" `
            -or $CompleteReport[$i] -like "*Disk check failed to run*") {
            
            $DiskSpace.Add($CompleteReport[$i]) | Out-Null
            
            #Job Checks
        } elseif ($CompleteReport[$i] -like "WARNING*job failed!*" `
            -or $CompleteReport[$i] -like "CRITICAL*job failed!*") {
            
            $Jobs.Add($CompleteReport[$i]) | Out-Null
            
            #AOAG/Mirroring Status
        } elseif ($CompleteReport[$i] -like "*Database Mirroring not synchronised*" `
            -or $CompleteReport[$i] -like "*Role Change Occurred at*" `
            -or $CompleteReport[$i] -like "*WARNING*NOT*HEALTHY*" ) {
            
            $AGStatus.Add($CompleteReport[$i]) | Out-Null
            
            #Other Alerts
        }elseif ($CompleteReport[$i] -like "CRITICAL*" -or $CompleteReport[$i] -like "WARNING*") {
            $Others.Add($CompleteReport[$i]) | Out-Null
        }
    }
    
    $Alerts = [ordered]@{
        'Availability' = ($Availability | Sort-Object -Unique);
        'Disk Space' = ($DiskSpace | Sort-Object -Unique);
        'Backups' = ($Backups | Sort-Object -Unique);
        'Jobs' = ($Jobs | Sort-Object -Unique);
        'AOAG\Mirroring Status' = ($AGStatus | Sort-Object -Unique);
        'Other Alerts' = ($Others | Sort-Object -Unique)
    }
    
    $Errors = [ordered]@{}
    $noIssues = @()
    $Alerts.Keys | ForEach-Object {
        $Errors.add("$_",$Alerts.Item("$_").Count)
        if ($Alerts.Item($_).count -eq 0) {
            $noIssues += "$_"
        }
    }
    
    $noIssuesArrayList = New-Object System.Collections.ArrayList
    $noIssuesArrayList.Add('No Issues Found') | Out-Null
    $noIssues | ForEach-Object {
        $Alerts.$_ = $noIssuesArrayList.Clone()
    }
    
    $EmailConfigurationFile = import-csv "$LocalFilepath\ConfigurationFiles\GLIDE_EmailConfiguration.csv"
    foreach ($EmailConfig in $EmailConfigurationFile) {
        if ($EmailConfig.SummaryOnly -like "y*") {
            $Report = ""
        }else{
            $Report = $CompleteReport
        }
        $GlideReport = BuildReport $Report $Alerts $Errors $TotalInstanceArray $ConnectedInstanceArray $ElapsedTime $HostInstance
        
        try {
            write-host "Attempting to send email" -BackgroundColor White -ForegroundColor Black
            EmailReport $GlideReport $EmailConfig $Errors
            write-host "Email sent" -BackgroundColor Green -ForegroundColor Black
        } catch {
            if ($Alerts.'Other Alerts' -eq 'No Issues Found') {
                $Alerts.'Other Alerts'.Clear() | Out-Null
                $Alerts.'Other Alerts' += "$(ErrorCodes -8 $env:COMPUTERNAME)"
                $Errors.'Other Alerts' = 1
            } else {
                $Alerts.'Other Alerts' += "$(ErrorCodes -8 $env:COMPUTERNAME)"
                $Errors.'Other Alerts' += 1
            }
            $GlideReport = BuildReport $CompleteReport $Alerts $Errors $TotalInstanceArray $ConnectedInstanceArray $ElapsedTime
            Write-Host "Email failed" -BackgroundColor Red -ForegroundColor Black
        }
    }
    return $GlideReport
}

<#
Name: BuildReport
Inputs: $GlideReport, $Criticals, $Warnings, $TotalInstanceArray, $ConnectedInstanceArray, $ElapsedTime, $HostInstance
Outputs: $GlideReport
Details: 
Takes in the compiled GlideReport and the list of warning and critical messages and out puts the complete report.
This is where the header + footer of the total report is added. 
#>
Function BuildReport($FullReport, $Alerts, $Errors, $TotalInstanceArray, $ConnectedInstanceArray, $ElapsedTime, $HostInstance) {
    
    $Summary = @()
    $FailedChecks = @()
    $FailedMessage = ""
    $FailedCount = 0
    $InstanceCount= $TotalInstanceArray.length
    $ConnectedInstanceCount = $ConnectedInstanceArray.length
    
    if (!($InstanceCount -eq $ConnectedInstanceCount)) {
        foreach ($item in $TotalInstanceArray) {
            $flag = $FALSE
            foreach ($item2 in $ConnectedInstanceArray) {
                if ($item -eq $item2) {
                    $flag = $TRUE
                }
            }
            if (!($Flag)) {
                $FailedChecks += $item
            }
        }
        $temp = $FailedChecks -join ", "
        $FailedCount = @($FailedChecks).Length
        $FailedMessage = "Failed Checks : $FailedCount ($temp)"
    }
    
    $Summary += "Glide $GlideVersion - Daily Report $TodayDate"
    $Summary += "----------------------------------"
    $Summary += ""
    $Summary += "Central Server: $HostInstance"
    $Summary += "Total Servers to be Checked: $InstanceCount"
    $Summary += "Actual Servers Checked: $ConnectedInstanceCount"
    $Summary += "`n"
    $Errors.Keys | ForEach-Object {
        $Summary += "$_ Issues: $($Errors.Item($_))"
    }
    
    if ($FailedCount -gt 0) {
        $Summary += $FailedMessage
    }
    
    #Run this after all warnings/criticals are pulled out of total report
    $GlideReport = $Summary 
    $GlideReport += "`n"
    $Alerts.Keys | ForEach-Object {
        $GlideReport += "******************************************"
        $GlideReport += "*   $_"
        $GlideReport += "******************************************"
        $GlideReport += $Alerts.Item($_)
        $GlideReport += "`n" 
    }
    $GlideReport += "`n" 
    $GlideReport += "INSTANCES CHECKED"
    $GlideReport += "================="
    $GlideReport += $TotalInstanceArray
    $GlideReport += $FullReport
    $GlideReport += $ElapsedTime
    $GlideReport += "`n"
    $GlideReport += "*********************`n"
    $GlideReport += "*    End Of Report`n"
    $GlideReport += "*********************"
    
    Return $GlideReport
}

<#
Name: EmailReport
Inputs: $GlideReport, $EmailConfiguration, $CriticalCount, $WarningCount
Outputs: None (Email is sent or error is thrown)
Details: 
Sends an email using the configuration specified in the $emailConfiguration variable.
Will throw an error if the email fails, and this will be reflected in the report
#>
Function EmailReport($GlideReport, $EmailConfiguration, $Errors) {
    
    $ServerGroup = $EmailConfiguration.ServerGroup
    $SMTPServer = $EmailConfiguration.SMTPServer
    $ToAddress = @($EmailConfiguration.ToAddress)
    $FromAddress = @($EmailConfiguration.FromAddress)
    $Customer = $EmailConfiguration.Customer
    
    $ErrorCount = 0
    $Errors.keys | Foreach-Object {
        $ErrorCount += $Errors.Item($_)
    }
    
    if ($ErrorCount -gt 0) {
        $ErrorLevel = "ISSUES FOUND"
    }else{$ErrorLevel = "No Issues"}
    
    $subject = "DBA Report : $Customer : $ServerGroup : $DATE : $ErrorLevel"
    
    $body = @()
    $body = $GlideReport
    
    $message = New-Object System.Net.Mail.MailMessage $FromAddress, $ToAddress
    $message.Subject = $subject
    foreach ($line in $body) {
        $message.body += $line + "`n"
    }
    $smtp = New-Object System.Net.Mail.SmtpClient($SMTPServer, 25)
    $smtp.Send($message)
}

<#
Name: SchTaskChecker
Inputs: $Server, $Instance, $DBName
Outputs: $SchChecker, ErrorCodes -11
Details: 
Runs a select statement on the GLIDE database to determine which scheduled tasks to check for.
Will then run an update query on the database to update those tasks which are present in the task scheduler on the host machine.
the main goal of this function is to update the scheduled_task_summary table in the database with the latest information.
#>
Function SchTaskChecker($Server, $Instance, $DBName) {
    
    try{
        $SchChecker = "Checking Scheduled tasks for $Instance`n"
        $command = "SELECT task_filename FROM $DBName.dbo.scheduled_task_summary"
        $GlideTaskNamesDataset = SQLSelectQuery $Instance $command
        $GlideTaskNames = @()
        foreach ($row in $GlideTaskNamesDataset) {
            $GlideTaskNames += $row.task_filename
        }
        
        $command = ProcessScheduledTasks (GetGLIDEScheduledTasks $Server $GlideTaskNames)
        SQLUpdateQuery $Instance $command
        $SchChecker += "INFO : Successfully updated scheduled tasks for $Instance"
    } catch {
        try {
            if ($Error[0].FullyQualifiedErrorId -like "*No Databases Detected.*") {
                throw ErrorCodes -11 $Instance
            }
            $SchChecker += $Error[0].FullyQualifiedErrorId
        } catch {
            $SchChecker += $Error[0].FullyQualifiedErrorId
        }
    }
    return $SchChecker
}

<#
Name: GetGLIDEScheduledTasks
Inputs: $ComputerName, $GlideTaskNames
Outputs: $GlideTasks
Details: 
Retrieves the last run time of the scheduled tasks listed in $GlideTaskNames (which is populated by the select query run in SchTaskChecker) 
#>
Function GetGLIDEScheduledTasks($ComputerName, $GlideTaskNames) {
    $header = "HostName,TaskName,Next Run Time,Status,Logon Mode,Last Run Time,Last Result,Author,Task To Run,Start In,Comment,Scheduled Task State,Idle Time,Power Management,Run As User,Delete Task If Not Rescheduled,Stop Task If Runs X Hours and X Mins,Schedule,Schedule Type,Start Time,Start Date,End Date,Days,Months,Repeat: Every,Repeat: Until: Time,Repeat: Until: Duration,Repeat: Stop If Still Running"
    $var = @()
    $var += $header
    $var += (schtasks.exe /query /fo csv /v | Where-Object {$_ -notlike "*HostName*TaskName*Next Run Time*Status*Logon Mode*Last Run Time*"}).Replace("\","")
    $var = ConvertFrom-Csv $var | Select-Object TaskName,"Last Run Time"
    $GlideTasks = @()
    foreach ($GLIDETask in $GlideTaskNames) {
        foreach ($Task in $var) {
            if ($Task -like "*$GLIDETask*") {
                $GlideTasks += $Task
            }
        }
    }
    return $GlideTasks
}

<#
Name: ProcessScheduledTasks
Inputs: $GlideSchTasks
Outputs: $command
Details: 
Build a dynamic update command based on the last run time of each scheduled task and returns it.
#>
Function ProcessScheduledTasks($GlideSchTasks) {
    
    $command = "--Update Scheduled Tasks
    USE [GLIDE]
    "
    
    foreach ($Task in $GlideSchTasks) {
        $SchDate = get-date ($Task."Last Run Time") -Format "yyyy-MM-dd HH:mm:ss"
        $TaskName = $Task.TaskName
        $command += "
        UPDATE [dbo].[scheduled_task_summary]
        SET [last_success] = '$SchDate'
        WHERE [task_filename] = '$TaskName'
        "
    }
    return $command
}

<#
Name: CheckSQLAgent
Inputs: $instance
Outputs: $DataTable."Current Service State"
Details: 
Connects to sql and runs the "xp_servicecontrol 'querystate', 'SQLSERVERAGENT'" command to determine the agent status of the instance.
This should be moved to the .sql script in the future.
#>
Function CheckSQLAgent($instance) {
    $DataTable = SQLSelectQuery $instance "xp_servicecontrol 'querystate', 'SQLSERVERAGENT'"
    return $DataTable."Current Service State"
}

<#
Name: CheckBackupServersDisks
Inputs: $backupServer
Outputs: n/a
Details: 
runs wmi commands to check the freespace of all disks on backup servers
#>
Function CheckBackupServersDisks($backupServer) {
    $diskerror = 5
    $diskwarning = 15 
    # get disks
    $alerts = New-Object System.Collections.ArrayList
    $disks = get-wmiobject -computername $backupServer -class win32_volume -filter 'drivetype = 3' | Select-Object name, @{name='freespace'; Expression = {[math]::round($_.freespace/1mb,0)}}, @{name='capacity'; Expression = {[math]::round($_.capacity/1mb,0)}}, @{name='PercFree' ; Expression = {[math]::round(100*$_.freespace/$_.capacity,1)}}
    foreach ($disk in $disks) {
        $diskname = $disk.name
            $errorflag = $false
            if ($disk.percfree -le $diskerror) {
                $severity = "CRITICAL"
                $threshold = $diskerror
                $errorflag = $true
            } elseif ($disk.percfree -lt $diskwarning) {
                $severity = "WARNING"
                $threshold = $diskwarning
                $errorflag = $true
            }
            if ($errorflag) {
                $alerts += "$($severity): $($backupServer) : Disk space on drive $diskname currently only $($disk.percfree)% is free ($($disk.freespace) out of $($disk.capacity)mb remaining). This is less than the $($threshold)% error threshold."
            } else {
                $alerts += "INFO: $($backupServer) : Disk space on drive $diskname currently $($disk.percfree)% is free ($($disk.freespace) out of $($disk.capacity)mb remaining)."
            }
    }
    return $alerts
}

<#
Name: ErrorCodes
Inputs: $ErrorValue, $Instance
Outputs: Text
Details: 
Should only be used in a throw statement. 
Will return text as an error based on the parameter it is passed.
This text can then be caught and accessed using $Error[0].Exception
#>
Function ErrorCodes($ErrorValue, $Instance) {
    
    Switch ($ErrorValue) {
        (-1) {"CRITICAL: $Instance : Unable to open connection to SQL Instance."}
        (-2) {"CRITICAL: $Instance : Unable to run: $SQLSelectDatabases."}
        (-3) {"CRITICAL: $Instance : No databases detected."}
        (-4) {"CRITICAL: $Instance : No GLIDE databases found."}
        (-5) {"CRITICAL: $Instance : Unable to run stored proc: $MainStoredProc."}
        (-6) {"CRITICAL: $Instance : Unable to find GLIDE Directory on local machine"}
        (-7) {"CRITICAL: $instance : Unable to ping server. Server is unreachable"}
        (-8) {"CRITICAL: $Instance : Unable to send email."}
        (-9) {"WARNING : $Instance : Unable to update Scheduled task table"}
        (-10) {"INFO : $Instance : No scheduled tasks were checked"}
        (-11) {"WARNING : $Instance : Scheduled_task_summary table not populated"}
        (-12) {"WARNING : $Instance : SchTask Check failed. Schedule.Service Object not found. "}
        (-13) {"CRITICAL : $Instance : DBMon Module Failed - Instance is unreachable or instance name was incorrect. "}
        default {"Unknown Error"}
    }
}

<#
Pseudocode for this function:

Get start time
Initialise variables
Ensure folder structure is correct
Import ServerList and host instance list
Foreach instance in the list:
Get servername and instance name
Generate the name of the output file
Check connectivity to the target server/instance
Check for the GLIDE (or EDS) database
Update the scheduled tasks on the database
Check if the SQL Agent is running
Run the GLIDE report
Add the instance to the successful list
Combine all reports (Both successful and failed)
Archive old reports
Display run time
Process report:
Collect critical + warning messages
Generate header of the total report
Combine all elements of the report together
Email report
(If email fails, Add in critical message about failed email)

#>
Function Main() {
    
    $StartTime = get-date
    
    $FilePathArray = @()
    $TotalInstanceArray = @()
    $ConnectedInstanceArray = @()
    $LocalFilepath = GetGlideDirectory
    CheckDirectoryStructure $LocalFilepath
    
    $InstanceFileName = "CompleteReport"
    $CompleteReportFilePath = $LocalFilepath + "Reports\CurrentReports\$GLIDEREPORTNAME$InstanceFileName"+"_$DATE.txt"
    
    try {
        $ServerListArr = import-csv "$LocalFilepath\ConfigurationFiles\GLIDE_ServerList.csv"
        $ServerCount = ($ServerListArr | Measure-Object).Count
        $HostInstance = (Get-Content "$LocalFilepath\ConfigurationFiles\GLIDE_HostInstance.txt")
        if (!($HostInstance)) {
            #Set host instance to the current instance if config file is blank
            $HostInstance = $env:COMPUTERNAME
        }
    } catch {
        throw ErrorCodes -6 $instance
    }

    # check the backup server disks
    $backupServerList = import-csv "$LocalFilepath\ConfigurationFiles\GLIDE_BackupServerList.csv"
    foreach ($backupServer in $backupServerList) {
        $backupServerName = $backupserver.name
        $alerts = CheckBackupServersDisks $backupServerName
        $FilePath = $LocalFilepath + "Reports\CurrentReports\$GLIDEREPORTNAME" + $backupServerName + "_$DATE.txt"

"******************************************************
*
*          GLIDE daily report version $GlideVersion
*          ------------------------------
*          server $backupServerName
*
*****************************************************
*
------------------------------------------------------
-                                                     
-                  Disk Checks          
-                                                     
------------------------------------------------------
" > $FilePath
        
        $alerts >> $FilePath

        # add filepath to filepath array if not a duplicate
        $uniqueFlag = $TRUE
            if ($FilePathArray.Length -eq 0) {
                $FilePathArray += $filepath
            }
            
            #checking for duplicates
            foreach ($element in $FilePathArray) {
                if ($element -eq $filepath) {
                    $uniqueFlag = $FALSE
                }
            }
            #if not a duplicate then
            if ($uniqueFlag) {
                $FilePathArray += $filepath
            }     
    }


    $ServerList = @()
    
    foreach ($row in $ServerListArr) {
        
        $ServerList += $row
        
    }
    
    if (!($ServerCount -eq 0)) {
        for ($i = 0; $i -lt $ServerCount; $i++) {
            
            $Server = $ServerList[$i].ServerName
            
            if (!($ServerList[$i].InstanceName -eq "" -or $null -eq $ServerList[$i].InstanceName)) {
                if ($ServerList[$i].InstanceName -like "*,*") {
                    if ($ServerList[$i].InstanceName -like ",*") {
                        $instance = $Server + $ServerList[$i].InstanceName
                    } else {
                        $instance = $Server + "\" + $ServerList[$i].InstanceName
                    }
                } else {
                    $instance = $Server + "\" + $ServerList[$i].InstanceName
                }
            } else {
                $instance = $Server
            }
            $TotalInstanceArray += $Instance
            $InstanceFileName = $instance.Replace("\","-")
            $GlideDB = $ServerList[$i].DatabaseName
            $filepath = $LocalFilepath + "Reports\CurrentReports\$GLIDEREPORTNAME" + $InstanceFileName + "_$DATE.txt"
            
            try {
                write-host "Starting report on $instance" -BackgroundColor white -ForegroundColor black
                "Checking Connectivity to $Instance" > $filepath
                if (CheckConnectivity $server) {
                    
                    if ($GlideDB -eq "" -or $null -eq $GlideDB) {
                        $GlideDB = CheckGlideDB (SQLSelectQuery $instance $SQLSelectDatabases) $instance
                    }
                    if (!($null -eq $GlideDB)) {
                        if ($HostInstance -eq $instance) {
                            $ScheduledTasksMessage = SchTaskChecker $Server $instance $GlideDB
                        } else {
                            $ScheduledTasksMessage = "INFO : Scheduled Tasks only checked on host server."
                        }
                        try {
                            $Result = CheckSQLAgent $instance
                            if ($Result -like "*Running*") {
                                $Result = "INFO: $instance : SQL Server Agent is $Result"
                            } else {
                                $Result = "CRITICAL: $instance : SQL Server Agent is $Result"
                            }
                        } catch {
                            $Result = "WARNING: $instance : Failed to run the following SQL command: 'xp_servicecontrol 'querystate', 'SQLSERVERAGENT' '"
                        }
                        
                        $ReportPrefix = "$ScheduledTasksMessage`n`nChecking SQL Agent status`n$Result"
                        CreateReport $instance $GlideDB $MainStoredProc $filepath $ReportPrefix
                        $ConnectedInstanceArray += $instance
                    } else {
                        throw ErrorCodes -4 $instance
                    }
                    
                } else {
                    throw ErrorCodes -7 $instance
                }
                
                write-host "Report Complete" -BackgroundColor green -ForegroundColor Black
                
            } catch {
                write-host "Report Failed" -BackgroundColor Red -ForegroundColor Black
                write-output $Error[0].Exception >> $filepath
            }
            
            # add filepath to filepatharray if not a duplicate
            $uniqueFlag = $TRUE
            if ($FilePathArray.Length -eq 0) {
                $FilePathArray += $filepath
            }
            
            #checking for duplicates
            foreach ($element in $FilePathArray) {
                if ($element -eq $filepath) {
                    $uniqueFlag = $FALSE
                }
            }
            #if not a duplicate then
            if ($uniqueFlag) {
                $FilePathArray += $filepath
            }        
        }
        #write-host $FilePathArray
        $CombinedReport = CombineReports $FilePathArray
        
    }else{
        $CombinedReport = @()
        $CombinedReport += "CRITICAL: GLIDE_ServerList.csv is empty"
    }
    
    write-host "Archiving old reports" -BackgroundColor White -ForegroundColor Black
    ArchiveReports $LocalFilepath $DATE $GLIDEREPORTNAME
    
    $ElapsedTime = TimeScript $StartTime
    ProcessReport $CombinedReport $ElapsedTime $TotalInstanceArray $ConnectedInstanceArray $HostInstance > $CompleteReportFilePath
    
}

$GlideDB = $NULL
$DATE = (Get-Date).ToString('ddMMMyyyy').ToUpper()#GetShortDate
$GLIDEREPORTNAME = "GLIDEREPORT_"
 
Main