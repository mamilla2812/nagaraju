DECLARE @db_name nvarchar(100)
DECLARE @sql nvarchar(max)

SET NOCOUNT OFF

IF CURSOR_STATUS('global','db_cursor')>=-1
BEGIN
	CLOSE db_cursor
	DEALLOCATE db_cursor
END
IF OBJECT_ID('tempdb..#tempusers') IS NOT NULL
BEGIN
    DROP TABLE #tempusers
END

CREATE TABLE #tempusers
(
    dbname nvarchar(100),
    username nvarchar(100),
    sid varbinary(85) 
)

DECLARE db_cursor CURSOR FAST_FORWARD FOR
    SELECT name FROM master.sys.databases
OPEN db_cursor

FETCH NEXT FROM db_cursor INTO @db_name

WHILE @@FETCH_STATUS = 0
BEGIN
    set @sql = 'USE [' + @db_name + ']
    INSERT into #tempusers
    SELECT ''' + @db_name + ''' as dbname, name, sid 
    FROM sys.database_principals 
    --WHERE name = ''test''
    '
    exec (@sql)

    FETCH NEXT FROM db_cursor INTO @db_name
END

select * from #tempusers

SELECT A.name
FROM master.sys.databases as A
LEFT JOIN #tempusers as B
ON A.name = B.dbname
WHERE B.dbname IS NULL

SELECT B.dbname
FROM sys.server_principals as A
RIGHT JOIN #tempusers as B
ON A.name = B.username
WHERE A.sid <> B.sid
    
    --Do comparisions here
    --first check if user is mapped to database
    --if user is mapped check the sid


IF CURSOR_STATUS('global','db_cursor')>=-1
BEGIN
	CLOSE db_cursor
	DEALLOCATE db_cursor
END

IF OBJECT_ID('tempdb..#tempusers') IS NOT NULL
BEGIN
	DROP TABLE #tempusers
END