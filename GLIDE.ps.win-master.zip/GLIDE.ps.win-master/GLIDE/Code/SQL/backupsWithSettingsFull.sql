DECLARE @a datetime
SET @a=DATEADD(hh,-CONVERT(INT, GLIDE.dbo.uf_get_setting('bkup_check','','maximum_days_backup_check'))*24,getdate())

SELECT 
	vdb.name,
	'FULL' AS type,
	CASE
		WHEN DATEDIFF(HH, max(bus.backup_finish_date), GETDATE()) >= 0 THEN DATEDIFF(HH, max(bus.backup_finish_date), GETDATE())
		ELSE -1
	END AS hours_since_last_backup,	GLIDE.dbo.uf_get_setting('database',vdb.name,'full_backup_ignore') AS ignore,
	GLIDE.dbo.uf_get_setting('database',vdb.name,'full_backup_days') AS backup_days,
	GLIDE.dbo.uf_get_setting('database',vdb.name,'full_backup_warning') AS warning_threshold,
	GLIDE.dbo.uf_get_setting('database',vdb.name,'full_backup_critical') AS critical_threshold
FROM GLIDE..valid_databases AS vdb
LEFT JOIN (SELECT * FROM msdb..backupset WHERE backup_finish_date > @a AND type = 'D') bus ON vdb.name = bus.database_name
WHERE vdb.name <> 'tempdb'
	AND DATABASEPROPERTY(vdb.name,'isinstandby')=0
	AND DATABASEPROPERTY(vdb.name,'isreadonly')=0
GROUP BY vdb.name, bus.type