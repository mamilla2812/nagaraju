﻿if (!($PSScriptRoot)){
    $PSScriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
}

$FileName = "Pulse_ExcludeFile"
$ConfigFolder = "ConfigurationFiles"
$Extn = ".cfg"

#DEBUG  VARIABLES
#$Path = "C:\Users\arthurca\OneDrive - Hewlett Packard Enterprise\Documents\AAAA-Projects\G in glide is for global\GLIDE_3.25\GLIDE_Pulse_Check\ConfigurationFiles\Pulse_ServerList.txt"
#$ServerList = gc $Path

Function GenerateDynamicCheckBoxForm($CheckBoxLabels){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $CheckBoxCounter = 1
    $RowCounter = 1
    $objForm = New-Object System.Windows.Forms.Form
    $button1 = New-Object System.Windows.Forms.Button
    $listBox1 = New-Object System.Windows.Forms.ListBox
    $InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState
    
    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "Pulse Configuration Manager"
    $objForm.Size = New-Object System.Drawing.Size(600,550) 
    $objForm.StartPosition = "CenterScreen"

    # When we create a new textbox, we add it to an array for easy reference later
    $CheckBoxes = foreach($Label in $CheckBoxLabels) {
        $CheckBox = New-Object System.Windows.Forms.CheckBox        
        $CheckBox.UseVisualStyleBackColor = $True
        $System_Drawing_Size = New-Object System.Drawing.Size
        $System_Drawing_Size.Width = 120
        $System_Drawing_Size.Height = 30
        $CheckBox.Size = $System_Drawing_Size
        $CheckBox.TabIndex = 2
        $CheckBox.Checked = $TRUE
        # Assign text based on the input
        $CheckBox.Text = $Label

        $System_Drawing_Point = New-Object System.Drawing.Point
        $System_Drawing_Point.X = 27 + (($RowCounter - 1) * 150) 
        # Make sure to vertically space them dynamically, counter comes in handy
        $System_Drawing_Point.Y = 113 + (($CheckBoxCounter - 1) * 31)
        If ($System_Drawing_Point.Y -gt 430){
            $RowCounter++
            $System_Drawing_Point.X = 27 + (($RowCounter - 1) * 150)
            $CheckBoxCounter = 1
            $System_Drawing_Point.Y = 113 + (($CheckBoxCounter - 1) * 31)   
        }
        $CheckBox.Location = $System_Drawing_Point
        $CheckBox.DataBindings.DefaultDataSourceUpdateMode = 0

        # Give it a unique name based on our counter
        $CheckBox.Name = "CheckBox$CheckBoxCounter$RowCounter"

        # Add it to the form
        $objForm.Controls.Add($CheckBox)
        # return object ref to array
        $CheckBox
        # increment our counter
        $CheckBoxCounter++

    }

    $Button1 = New-Object System.Windows.Forms.Button
    $Button1.Location = New-Object System.Drawing.Size(145,460)
    $Button1.Size = New-Object System.Drawing.Size(90,30)
    $Button1.Text = "Select"
    $Button1.Add_Click({
        $Script:InstanceArray = @()
        foreach($CheckBox in $CheckBoxes){
            if($CheckBox.Checked){
                $Script:InstanceArray += $CheckBox.Text
            }
        }
        $objForm.Close()
    })
    $objForm.Controls.Add($Button1) 

    $Button2 = New-Object System.Windows.Forms.Button
    $Button2.Location = New-Object System.Drawing.Size(255,460)
    $Button2.Size = New-Object System.Drawing.Size(90,30)
    $Button2.Text = "Select All"
    $Button2.Add_Click({
        foreach($CheckBox in $CheckBoxes){
            $CheckBox.Checked = $TRUE
        }
    })
    $objForm.Controls.Add($Button2)

    $Button3 = New-Object System.Windows.Forms.Button
    $Button3.Location = New-Object System.Drawing.Size(365,460)
    $Button3.Size = New-Object System.Drawing.Size(90,30)
    $Button3.Text = "De-Select All"
    $Button3.Add_Click({
        foreach($CheckBox in $CheckBoxes){
            $CheckBox.Checked = $False
        }
    })
    $objForm.Controls.Add($Button3)

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(120,45) 
    $objLabel.Size = New-Object System.Drawing.Size(450,80)
    $objLabel.font = New-Object System.Drawing.Font("Microsoft Sans Serif",12,[System.Drawing.FontStyle]::Regular)
    $objLabel.Text = "Please select the instances where you`n      wish to install/upgrade GLIDE.`n"
    $objForm.Controls.Add($objLabel)

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    #Show the Form
    [void] $objForm.ShowDialog()
    return $InstanceArray
}

Function OpenDialogBox($Message, $FileType){
    
    [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
    $result = [Microsoft.VisualBasic.Interaction]::MsgBox("$message", 'OKOnly,SystemModal,Question', "Pulse Configuration Manager")

    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    
    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $OpenFileDialog.filter = "$Filetype (*.$Filetype)| *.$Filetype"
    $OpenFileDialog.ShowDialog() | Out-Null
    if (!($OpenFileDialog.FileName -eq "")){
        return (gc $OpenFileDialog.FileName)
    }else{
        return -1
    }
}

Function GenerateExcludeFile($ServerList, $Template, $FileName, $ConfigFolder, $Extn){

    foreach ($Server in $ServerList){
        $Server = $Server.replace("\","-")
        $InstanceFileName = "$ConfigFolder\$FileName"+"_$Server$Extn"
        
        $Template > "$PSScriptRoot\$InstanceFileName"

    }

}

Function PromptUser(){
    return DrawMessageBox "Create" "Add" "Remove" "Welcome to the Pulse Configuration manager. What would you like to do?"

}

Function DrawMessageBox($ButtonText1,$ButtonText2,$ButtonText3, $text){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "PULSE Automatic Configuration Deployment"
    $objForm.Size = New-Object System.Drawing.Size(400,200) 
    $objForm.StartPosition = "CenterScreen"

    $objForm.KeyPreview = $True
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        {$objForm.Close()}})
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {$objForm.Close()}})

    $Button1 = New-Object System.Windows.Forms.Button
    $Button1.Location = New-Object System.Drawing.Size(50,100)
    $Button1.Size = New-Object System.Drawing.Size(90,30)
    $Button1.Text = $ButtonText1
    $Button1.DialogResult = "Yes"
    $Button1.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button1)

    $Button2 = New-Object System.Windows.Forms.Button
    $Button2.Location = New-Object System.Drawing.Size(150,100)
    $Button2.Size = New-Object System.Drawing.Size(90,30)
    $Button2.Text = $ButtonText2
    $Button2.DialogResult = "No"
    $Button2.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button2)

    $Button3 = New-Object System.Windows.Forms.Button
    $Button3.Location = New-Object System.Drawing.Size(250,100)
    $Button3.Size = New-Object System.Drawing.Size(90,30)
    $Button3.Text = $ButtonText3
    $Button3.DialogResult = "OK"
    $Button3.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button3)

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(55,45) 
    $objLabel.Size = New-Object System.Drawing.Size(295,95)
    $objLabel.font = New-Object System.Drawing.Font("Microsoft Sans Serif",10,[System.Drawing.FontStyle]::Regular)
    $objLabel.Text = "$Text`n"
    $objForm.Controls.Add($objLabel)

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    Return $objForm.ShowDialog()
}

Function BuildInputForm($Msg){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $OKButton_Click={
        $FLAG = $TRUE
        if ($objDescription.Text -eq ""){
            $FLAG = $FALSE
            $objLabelErrDesc.Visible = $True
        }elseif (!($objDescription.Text -eq "")){
            $objLabelErrDesc.Visible = $False
        }
        
        if ($FLAG){
            $Script:Result = @()
            foreach ($line in ($objDescription.Text).Split("`n")){
                $Script:Result += $line
            }
            $objForm.Close()
        }
    }

    $Script:Incident = New-Object -Type psobject
    $FormSizex = 600
    $FormSizey = 250

    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "Pulse Configuration Manager"
    $objForm.Size = New-Object System.Drawing.Size($FormSizex,$FormSizey) 
    $objForm.StartPosition = "CenterScreen"

    $objForm.KeyPreview = $True
    #$objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        #{$x=$objTextBox.Text;$objForm.Close()}})
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {$Script:Result=-1;$objForm.Close()}})

    $OKButton = New-Object System.Windows.Forms.Button
    $OKButton.Location = New-Object System.Drawing.Size((($FormSizex/2)-75),($FormSizey - 80))
    $OKButton.Size = New-Object System.Drawing.Size(75,23)
    $OKButton.Text = "OK"
    $OKButton.Add_Click($OKButton_Click)
    $objForm.Controls.Add($OKButton)

    $CancelButton = New-Object System.Windows.Forms.Button
    $CancelButton.Location = New-Object System.Drawing.Size(($FormSizex/2),($FormSizey - 80))
    $CancelButton.Size = New-Object System.Drawing.Size(75,23)
    $CancelButton.Text = "Cancel"
    $CancelButton.Add_Click({$Script:Result=-1;$objForm.Close()})
    $objForm.Controls.Add($CancelButton)
    
    $objTitle = New-Object System.Windows.Forms.Label
    $objTitle.Location = New-Object System.Drawing.Size((($FormSizex/2.5)-90),20) 
    $objTitle.Size = New-Object System.Drawing.Size(($FormSizex/1.2),40) 
    $objTitle.Text = "$msg"
    $objTitle.font = New-Object System.Drawing.Font("Microsoft Sans Serif",12,[System.Drawing.FontStyle]::Regular)
    $objForm.Controls.Add($objTitle)

###########################Building Form Elements###################################################
    $Ypos = 60
    $xPos = 25
    $xSize = $FormSizex - 75

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size($xPos,$yPos) 
    $objLabel.Size = New-Object System.Drawing.Size($xSize,20) 
    $objLabel.Text = "Exclusion Messages:"
    $objForm.Controls.Add($objLabel)
    
    $yPos += 20

    $objDescription = New-Object System.Windows.Forms.TextBox
    $objDescription.Multiline=$true
    $objDescription.Location = New-Object System.Drawing.Size($xPos,$yPos) 
    $objDescription.Size = New-Object System.Drawing.Size($xSize,60)
    $objForm.Controls.Add($objDescription)

    $yPos += 60

    $objLabelErrDesc = New-Object System.Windows.Forms.Label
    $objLabelErrDesc.Location = New-Object System.Drawing.Size($xPos,($yPos+3)) 
    $objLabelErrDesc.Size = New-Object System.Drawing.Size($xSize,20) 
    $objLabelErrDesc.Text = "Field cannot be blank"
    $objLabelErrDesc.ForeColor = "Red"
    $objLabelErrDesc.Visible = $FALSE
    $objForm.Controls.Add($objLabelErrDesc)

    $yPos += 20

 #####################################################################################

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    [void] $objForm.ShowDialog()

    return $result
}

Function LoadServerList(){

    $ServerList = OpenDialogBox "Please select the list of instances that you wish to use.`nFormat: ServerName\InstanceName`nFileType: .txt`n" "txt"
    if (!($ServerList -eq -1)){
        return $ServerList
    }Else{
        ExitScript "No Server List Found. Script will now exit"
    }

}

Function LoadConfigFile(){

    $ConfigFile = OpenDialogBox "Please select the config file you wish to model the individual instance files on.`nFormat: Regular expressions`nFile Type: .cfg" "cfg"
    if (!($ConfigFile -eq -1)){
        return $ConfigFile
    }Else{
        ExitScript "No Configuration File Found. Script will now exit"
    }

}

Function ExitScript($msg){

    [Microsoft.VisualBasic.Interaction]::MsgBox("$msg", 'OKOnly,SystemModal,Critical', "Pulse Configuration Manager") | Out-Null
    exit
    
}

Function Information($msg){
    [Microsoft.VisualBasic.Interaction]::MsgBox("$msg", 'OKOnly,SystemModal,Exclamation', "Pulse Configuration Manager") | Out-Null    
}

Function GenerateFiles(){

    try{
        GenerateExcludeFile(GenerateDynamicCheckBoxForm (LoadServerList)) (LoadConfigFile) $FileName $ConfigFolder $Extn
    }Catch{

    }
    
    Information "Creation Complete. Please confirm that the correct files were created."
}

Function ReverseString($String){
    $String = $String.ToCharArray()
    [array]::Reverse($String)
    return (-join $String)
}

Function GetListOfConfigFiles($FileName, $ConfigFolder, $Extn){
    $ServerList = @()
    $Path = "$PSScriptRoot\$ConfigFolder"
    $FileList = Get-ChildItem $Path
    foreach ($Item in $FileList){
        if ($item.Name -like "*$FileName*$Extn"){
            $ItemName = ReverseString ($Item.Name.Substring(0, $Item.Name.IndexOf(".")))
            $ItemName = ReverseString (($ItemName.Substring(0,$ItemName.IndexOf("_"))).Replace("-","\"))  
            If ($ItemName -eq "ExcludeFile"){
                $ItemName = "Template File"
            }
            $ServerList += $ItemName
        }
    }
    return $ServerList
}

Function AddEntries($FileName, $ConfigFolder, $Extn){
    $ServerList = GenerateDynamicCheckBoxForm (GetListOfConfigFiles $FileName $ConfigFolder $Extn)
    If (!($ServerList -eq -1)){
        $Regex = @()
        $Regex = BuildInputForm "Please input the lines you wish to add:"
        if (!($Regex -eq -1)){
            foreach ($server in $ServerList){
                if ($server -eq "Template File"){
                    $InstanceFileName = "$ConfigFolder\$FileName$Extn"
                }else{
                    $Server = "_" + $Server
                    $Server = $Server.replace("\","-")
                    $InstanceFileName = "$ConfigFolder\$FileName$Server$Extn"
                }
                
                if (Test-Path "$PSScriptRoot\$InstanceFileName"){
                    foreach ($line in $Regex){
                        write-host "$PSScriptRoot\$InstanceFileName"
                        $line >> "$PSScriptRoot\$InstanceFileName"
                    }
                }else{
                    write-host "Could not find config file at $PSScriptRoot\$InstanceFileName. No action was taken."
                }
            }
            Information "Lines added to config files. Please check the console for any errors."
        }
    }

}

Function RemoveEntries(){

}

Function Main(){

    Switch (PromptUser){
        "Yes" {
            GenerateFiles
            return $TRUE
        }
        "No" {
            AddEntries $FileName $ConfigFolder $Extn
            return $TRUE
        }
        "OK"{
            RemoveEntries
            return $TRUE
        }
        "Cancel"{
             return $FALSE
        }

    }

}

While (Main){}
