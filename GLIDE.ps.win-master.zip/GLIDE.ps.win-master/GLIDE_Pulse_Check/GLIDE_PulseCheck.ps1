﻿$METRIC = [int]15 #Minutes between pulse checks

$Version = "Pulse_Check.ps1 - v1.0"

<#
Name: N/A
Inputs: $PSScriptRoot
Outputs: $PSScriptRoot
Details: 
Checks the variable $PSScriptRoot.
If the variable contains no information (ie. PowerShell version 2 or below) it will update it with the current script path.
#>
if (!($PSScriptRoot)){
    $PSScriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
}

<#
Name: N/A
Inputs: None
Outputs: None
Details: 
Sets global variables for script. 
#>
$DATE = (Get-Date).ToString('dd-MMM-yyyy').ToUpper()
$TIME = (Get-Date).ToString('-HHmmss').ToUpper()
$logFileName = "PulseLog"
$LogDirPath = "$PSScriptRoot\Pulse_Log"
$FileExtn = ".log"
$Output = "$LogDirPath\$LogFileName$DATE$TIME$FileExtn"
$ServerListPath = "$PSScriptRoot\ConfigurationFiles\Pulse_ServerList.txt"
$ExceptionListPath = "$PSScriptRoot\ConfigurationFiles\Pulse_ExcludeFile.cfg"
$EmailConfiguration = import-csv "$PSScriptRoot\ConfigurationFiles\Pulse_EmailConfiguration.csv"

$LastRunFile = "$LogDirPath\$LogFileName-00-LastRunResult$FileExtn"
$Version>$LastRunFile
"--------------------">>$LastRunFile
"">>$LastRunFile

$SQLQuery = "exec sp_readerrorlog 0, 1"

<#
Name: LoadExceptionList
Inputs: Path of the exception List
Outputs: The Loaded Exception list. 
Details: 
This list should be in the form of standard regex, but is loaded as a string.
#>
Function LoadExceptionList($Path){

    return gc $Path

}

<#
Name: LoadErrorLog
Inputs: Instance Name, SQL Query
Outputs: SQL Error Log
Details: 
Runs the passed SQL Query on the target instance. 
If an error occurs, it will output an object that matches the structure of the sql error log message.
(Log date, Process info, text)
Returns this result. 
#>
Function LoadErrorLog($instance, $SQLQuery){

    Try{
        $ErrorLog = SQLSelectQuery $instance $SQLQuery
    }Catch{
        $ErrorLog = [pscustomobject]@{LogDate=(Get-Date);
                            ProcessInfo="Server";
                            Text=$Error[0].Exception.Message}
    }
    
    return $ErrorLog   
}

<#
Name: SQLSelectQuery
Inputs: $instance, $SQLSelectDatabases
Outputs: $Datatable or ErrorCodes 
Details: 
Connects to SQL Server and runs the command stored in $SQLQuerys.
This command will be a select statement, and therefore the function will return a table result. 
#>
Function SQLSelectQuery($instance, $SqlQuery){
    
    $SqlConnString = "server=$instance;database=master;Integrated Security=true"

    $SQLConn = new-object System.Data.SqlClient.SqlConnection $SQLconnString

    try{
        
        "-Attempting to connect to $instance">>$LastRunFile
        $SQLConn.open()
        $SQLCommand = $SQLConn.CreateCommand()
        $SQLCommand.CommandText = $SqlQuery
        $SQLCommand.CommandTimeout = 15
        $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $SqlCommand
        $DataTable = New-Object System.Data.DataTable

    }catch{
        "-Failed to connect to $instance">>$LastRunFile
        throw ErrorCodes -1 $instance
    }

    try{
        "-Connected to $instance">>$LastRunFile
        $SqlAdapter.Fill($DataTable) |Out-Null
    }Catch{
        throw ErrorCodes -2 $instance
    }

    $SQLConn.Close()

    if($DataTable | Select-Object name){
        return $DataTable
    }else{
        throw ErrorCodes -3 $instance
    }
    "-Error Log of $instance Successfully loaded">>$LastRunFile

}

<#
Name: CheckErrorLog
Inputs: SQL Error log as datatable, instance name, list of exclude messages in regex form as string
Outputs: Any lines matching the regex passed in
Details: 
First filters the input error log on the log time and the metric set at the top of the script.
If it was logged in the past (Metric) minutes, will compare to each line of the exclusion file. 
Any matches are formatted as per the following:
Instance Name, Log date (example 2018-05-03 18
#>
Function CheckErrorLog($ErrorLog, $instance, $Regex){
    $ReturnArray = @()
    foreach ($line in $ErrorLog){
        if ($line.LogDate -gt (Get-Date).AddMinutes(-$METRIC)){
            $FLAG = $FALSE
            $Seperator = ","
            $Text = $line.Text -replace '\r',' ' -replace '\n',' ' -replace '\t',' '
            $Returnline = ($line.LogDate).ToString('yyyy-MM-dd hh:mm:ss.ff') + $Seperator + $line.ProcessInfo + $Seperator + '"' + $Text + '"'
            $line = ($line.LogDate).ToString('yyyy-MM-dd HH:mm:ss.ff') + " " + $line.ProcessInfo + " " + $Text
            foreach ($RegexLine in $Regex){
                if ($line -match $RegexLine -and !($RegexLine -eq "")){
                    $FLAG = $TRUE
                }
            }

            if ($FLAG -eq $FALSE){
                $ReturnArray += $instance + $Seperator + $Returnline
            }
        }
    }
    return $ReturnArray
}

<#
Name: ErrorCodes
Inputs: $ErrorValue, $Instance
Outputs: Text
Details: 
Should only be used in a throw statement. 
Will return text as an error based on the parameter it is passed.
This text can then be caught and accessed using $Error[0].Exception
#>
Function ErrorCodes($ErrorValue, $Instance){
    Switch ($ErrorValue){
        (-1) {"Unable to open connection to SQL Instance."}
        (-2) {"Connected to instance but $SQLQuery did not run successfully"}
        (-3) {"No rows returned from error log."}
        default {"Unknown Error"}
    }
}

<#
Name: CombineErrorLogs
Inputs: Output path, exception list path
Outputs: Write to output path
Details: 
Loops thought the instance list and runs the LoadErrorLog function on each instance.
Will then concatenate the instance name to each error log entry.
Next will run CheckErrorLog on each returned errorlog and will output the matched rows to the output path.
Format of this output is Instance, Timestamp, Process info, Message Text 
#>
Function CombineErrorLogs($Output, $ExceptionListPath){

    $instanceList = gc $ServerListPath
    $ErrorLogArray = @()
    foreach ($instance in $instanceList){

        $ErrorLogArray += [pscustomobject]@{Instance=$instance;
                                            ErrorLog=(LoadErrorLog $instance $SQLQuery)}
    }
    $Regex = gc $ExceptionListPath
    $MatchedRows = @()
    foreach ($Entry in $ErrorLogArray){

        $MatchedRows += CheckErrorLog $Entry.ErrorLog $Entry.instance $Regex

    }
    if ($MatchedRows.length -gt 0){
        "Instance,Timestamp,Process Info,Message Text" >> $Output
        $MatchedRows >> $Output
    }
}

<#
Name: CheckLogDirStructure
Inputs: Log directory path
Outputs: creates directories if required.
Details: 
Checks if the correct directory structure and correct number of directories are present.
Create any that are missing.
#>
function CheckLogDirStructure($LogDirPath){

    $Year = (get-date).Year
    
    if (!(test-path $LogDirPath)){
        new-item $LogDirPath -ItemType Directory | out-null
    }
    if (!(test-path "$LogDirPath\Archive\$year")){
        new-item "$LogDirPath\Archive\$year" -ItemType Directory | out-null
    }


    #Used to test if folders are missing
    if (!((Get-ChildItem -Path "$LogDirPath\Archive\$year\").count -eq 13)){
        $PresentDirectories = @()
        $ExpectedDirectories = @()
        $MissingDirectories = @()
        $presentDirectoriesArr = @()
        $PresentDirectories = get-childitem -path "$LogDirPath\Archive\$year\"
        $ExpectedDirectories += "01-JAN"
        $ExpectedDirectories += "02-FEB"
        $ExpectedDirectories += "03-MAR"
        $ExpectedDirectories += "04-APR"
        $ExpectedDirectories += "05-MAY"
        $ExpectedDirectories += "06-JUN"
        $ExpectedDirectories += "07-JUL"
        $ExpectedDirectories += "08-AUG"
        $ExpectedDirectories += "09-SEP"
        $ExpectedDirectories += "10-OCT"
        $ExpectedDirectories += "11-NOV"
        $ExpectedDirectories += "12-DEC"
        $ExpectedDirectories += "OtherFiles"
        foreach ($element in $PresentDirectories){
            $PresentDirectoriesArr += $element.Name
        }
        $MissingDirectories = $ExpectedDirectories | where {$PresentDirectoriesArr -notcontains $_}


        foreach ($Directory in $MissingDirectories){
            new-item "$LogDirPath\Archive\$year\$Directory" -ItemType Directory | out-null
        }
    }
    
}
#################################################################################

<#
Name: ArchiveReports
Inputs: log directory path, date, file name of the log, extension of the file
Outputs: None (Files are moved)
Details: 
Checks for the files present in the "CurrentReports" folder and moves those that are not from the current day to the matching archive directory 
#>
Function ArchiveReports($LogDirPath,$DATE,$LogFileName,$FileExtn){

    if ((Get-Date).DayOfYear -eq 1){
        $year = ((get-date).Year) - 1
    }else {$Year = (get-date).Year}

    $Filelist = @()
    $Filelist = get-childitem -path "$LogDirPath\" | Where-Object {$_.Name -like "*.*"}
    $SourceDirectory = "$LogDirPath\"
    $DestinationDirectory = "$LogDirPath\Archive\$year\"

    foreach ($file in $filelist){

        if (!($file -like "*$DATE*" -or $file -like "*00-LastRunResult.log")){
            switch -Wildcard ($file.Name){
                ("$LogFileName*jan-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\01-JAN" -verbose}
                ("$LogFileName*feb-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\02-FEB" -verbose}
                ("$LogFileName*mar-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\03-MAR" -verbose}
                ("$LogFileName*apr-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\04-APR" -verbose}
                ("$LogFileName*may-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\05-MAY" -verbose}
                ("$LogFileName*jun-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\06-JUN" -verbose}
                ("$LogFileName*jul-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\07-JUL" -verbose}
                ("$LogFileName*aug-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\08-AUG" -verbose}
                ("$LogFileName*sep-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\09-SEP" -verbose}
                ("$LogFileName*oct-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\10-OCT" -verbose}
                ("$LogFileName*nov-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\11-NOV" -verbose}
                ("$LogFileName*dec-$year*$FileExtn") {move-item "$SourceDirectory$file" "$DestinationDirectory\12-DEC" -verbose}
                Default {move-item "$SourceDirectory$file" "$DestinationDirectory\OtherFiles" -verbose}
            }
        }
    }

}

<#
Name: StartTime
Inputs: None
Outputs: current date
Details: 
Returns the date
#>
Function StartTime(){

    return get-date

}
<#
Name: TimeScript
Inputs: StartTime, Output path
Outputs: appends to the output path
Details: 
Returns a message with the time between start and this function running
#>
Function TimeScript($StartTime, $Output){

    $EndTime = get-date
    $ElapsedTime = $EndTime - $StartTime
    $ElapsedMins = $ElapsedTime.Minutes
    $ElapsedSecs = $ElapsedTime.Seconds
    $ElapsedMilliSecs = $ElapsedTime.Milliseconds
    "">>$LastRunFile
    "######################################################################################" >> $LastRunFile
    "Elapsed Time was $ElapsedMins min $ElapsedSecs sec $ElapsedMilliSecs ms" >> $LastRunFile

}

Function CheckLogs($LogFile){
    "-Error Log checked and errors found. Please see log file">>$LastRunFile

    WriteToEventViewer (import-csv $logFile)

    try{
        "-Attempting to send email.">>$LastRunFile
        EmailLog $LogFile $EmailConfiguration
        $ToAddress = @($EmailConfiguration.ToAddress)
        "-Email sent to $ToAddress">>$LastRunFile
    }Catch{
        "-Email sending failed.">>$LastRunFile
    }
    TimeScript $StartTime $Logfile
}

Function WriteToEventViewer($logFile){
    "-Attempting to write to Event Viewer : Application Logs.">>$LastRunFile
    $EventSource = "GLIDE_PulseCheck"
    If (!([System.Diagnostics.EventLog]::SourceExists("$EventSource"))){

        New-EventLog -LogName Application -Source $EventSource

    }
    if ([System.Diagnostics.EventLog]::SourceExists("$EventSource")){
        foreach ($line in $logFile){
            if (!($line."Message Text" -like "*``[GLIDE``]*")){
                [string]$msg = $line.TimeStamp + " " +$line.Instance + " : " + $line."Message Text"
                Write-EventLog -LogName Application -Source $EventSource -Message $msg -EntryType Warning -EventId 1
            }
        }
        "-Successfully updated Event Viewer.">>$LastRunFile  
    }else{
        "-Unable to write to Event Viewer.">>$LastRunFile
    }
}

Function EmailLog($LogFile, $EmailConfiguration){
    
    $ServerGroup = $EmailConfiguration.ServerGroup
    $SMTPServer = $EmailConfiguration.SMTPServer
    $ToAddress = @($EmailConfiguration.ToAddress)
    $FromAddress = @($EmailConfiguration.FromAddress)
    $Customer = $EmailConfiguration.Customer

    $subject = "Pulse Log - New Errors Detected: $Customer : $ServerGroup : $DATE"

    $att = new-object Net.Mail.Attachment($LogFile)

    $body = @()
    $body = gc $LogFile
    
    $message = New-Object System.Net.Mail.MailMessage $FromAddress, $ToAddress
    $message.Subject = $subject
    foreach ($line in $body){
        $message.body += $line + "`n"
    }
    $message.Attachments.Add($att)
    $smtp = New-Object System.Net.Mail.SmtpClient($SMTPServer, 25)
    $smtp.Send($message)
}

Try{
    CheckLogDirStructure $LogDirPath
    ArchiveReports $LogDirPath $DATE $LogFileName
}Catch{
    "$ENV:COMPUTERNAME - Directory Creation Failed" > $Output
}
$StartTime = StartTime
CombineErrorLogs $Output $ExceptionListPath

if (Test-Path $Output){
    CheckLogs $Output
}else{
    "-No Errors found.">>$LastRunFile
    TimeScript $StartTime $Output
}

"Script Complete.">>$LastRunFile