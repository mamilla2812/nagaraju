﻿if (!($PSScriptRoot)){
    $PSScriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
}

$DATE = (Get-Date).ToString('dd-MMM-yyyy').ToUpper()
$TIME = (Get-Date).ToString('-HHmmss').ToUpper()

$FilePathServerList = "$PSScriptRoot\ConfigurationFiles\Pulse_ServerList.txt"
$FilePathEmailConfiguration = "$PSScriptRoot\ConfigurationFiles\Pulse_EmailConfiguration.csv"
$FilePathExcludeFiles = "$PSScriptRoot\ConfigurationFiles\Pulse_ExcludeFile.cfg"
$PulsePS1Path = "$PSScriptRoot\GLIDE_PulseCheck.ps1"
$InstallLog = "$PSScriptRoot\Pulse_Log\GLIDE_InstallLog_$date.txt"
##############################################################################################################################################
Function ValidateInput($ImportedFile, $FilePath, $Append){
    if ($Append -eq $NULL){
        $Append = $FALSE
    }
    $ServerList = @()
    foreach ($line in $ImportedFile){
        if ($line -match '[^a-z0-9\\]+'){
            write-host "$Line - not added to server list"
        }else{
            if (!($line -like "")){
                $ServerList += $line
            }
        }
    }
    if (!($Append)){
        $ServerList > $filepath
    }Else{
        $ServerList >> $filepath
    }
}

Function DrawMessageBox($ButtonText1,$ButtonText3,$LabelText){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "GLIDE Automatic Installation"
    $objForm.Size = New-Object System.Drawing.Size(400,200) 
    $objForm.StartPosition = "CenterScreen"

    $objForm.KeyPreview = $True
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        {$objForm.Close()}})
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {$objForm.Close()}})

    $Button1 = New-Object System.Windows.Forms.Button
    $Button1.Location = New-Object System.Drawing.Size(50,100)
    $Button1.Size = New-Object System.Drawing.Size(90,30)
    $Button1.Text = $ButtonText1
    $Button1.DialogResult = "Yes"
    $Button1.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button1)

    $Button3 = New-Object System.Windows.Forms.Button
    $Button3.Location = New-Object System.Drawing.Size(250,100)
    $Button3.Size = New-Object System.Drawing.Size(90,30)
    $Button3.Text = $ButtonText3
    $Button3.DialogResult = "OK"
    $Button3.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($Button3)

    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size(55,45) 
    $objLabel.Size = New-Object System.Drawing.Size(295,80)
    $objLabel.font = New-Object System.Drawing.Font("Microsoft Sans Serif",9,[System.Drawing.FontStyle]::Regular)
    $objLabel.Text = $LabelText
    $objForm.Controls.Add($objLabel)

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    Return $objForm.ShowDialog()

}

Function PopulateServerList($filepath){
    $ServerList = @()
    $ImportedFile = @()
    "" > $filepath

    $UserPrompt = DrawMessageBox "From File" "Line by Line" "How would you like to load the server list?"
    Switch ($UserPrompt){
        "Yes" {
            [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    
            $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
            $OpenFileDialog.initialDirectory = $initialDirectory
            $OpenFileDialog.filter = "txt (*.txt)| *.txt"
            $OpenFileDialog.ShowDialog() | Out-Null
            if (!($OpenFileDialog.FileName -eq "")){
                $ImportedFile = gc $OpenFileDialog.FileName
            }else{
                return -1
            }
            ValidateInput $ImportedFile $filepath
        }
        "OK"{
            write-host "Enter each line in the following format: ServerName\InstanceName" -BackgroundColor Yellow -ForegroundColor Black
            write-host "Strike enter with no input to complete the list." -BackgroundColor Yellow -ForegroundColor Black
            "">$filepath
            While($Input){
                $Input = @()
                $Input += read-host
                ValidateInput $input $filepath $TRUE
            }
            $output = gc $filepath
            if ($output.Length -gt 1){
                ($output)[1..($output.length - 1)] > $filepath
            }
        }
        "Cancel"{
             write-host "CANCEL" -BackgroundColor Red
        }

    }
}

Function PopulateEmailConfiguration($FilePath){

    write-host "Please enter the configuration required for emails." -BackgroundColor Yellow -ForegroundColor Black
    write-host "Syntax: ServerGroup,Customer,SMTPServer,`"To@Address1,To@Address2`",From@Address" -BackgroundColor Yellow -ForegroundColor Black
    $Input = read-host
    "ServerGroup,Customer,SMTPServer,ToAddress,FromAddress" > $filepath
    $input >> $filepath

}

Function Get-ScheduledTask($ComputerName){

    $var = @()
    $var += "TaskName,Next Run Time,Status"
    $var += (schtasks.exe /query /fo csv | where {$_ -notlike "*TaskName*Next Run Time*Status*"})
    $var = ConvertFrom-Csv $var
    return $var
}

Function CreateScheduledTasks($FilePath, $LogPath) {

    Write-Host "Creating the scheduled task" -BackgroundColor White -ForegroundColor Black
    $FilePath = "Powershell.exe " + $FilePath
    $TaskNameNew = "GLIDE_PulseCheck.ps1"
    $ComputerName = $env:COMPUTERNAME
    $AllTasks = Get-ScheduledTask $ComputerName
    $TaskExists = $AllTasks | Where-Object {$_.TaskName -like "*$TaskNameNew*"}

    if(!($taskExists)) {
        CreateTaskUserPrompt $TaskNameNew $FilePath $LogPath
    }      
} 

Function CreateTaskUserPrompt($TaskName, $FilePath, $LogPath){
 
    $Interval = BuildIntervalForm
    $Schedule = switch($Interval.TimeScope){
        "mins" {"MINUTE"}
        "hours" {"HOURLY"}
        "days" {"DAILY"}
    }
    $Modifier = $Interval.Interval
    $ServiceAccount = Get-Credential -Message "Please enter the account that the scheduled tasks will run under."
    $user = $ServiceAccount.UserName
    $servicePW = $ServiceAccount.GetNetworkCredential().Password
    schtasks.exe /create /tn $TaskName /ru $user /rp $servicePW /RL HIGHEST /sc $Schedule /MO $Modifier /tr $FilePath | out-file $LogPath
    schtasks.exe /run /tn $TaskName
}

Function BuildIntervalForm(){

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    $OKButton_Click={
        $FLAG = $TRUE
        if ("mins","hours","days" -notcontains $ObjPriority.Text){
            $FLAG = $FALSE
            $objLabelErrsvr.Visible = $True
        }else{
            $objLabelErrsvr.Visible = $False
        }
        if ($objServer.Text -eq ""){
            $FLAG = $FALSE
            $objLabelErrsvr.Visible = $True
        }if (!([bool]($objServer.Text -as [double]))){
            $FLAG = $FALSE
            $objLabelErrsvr.Visible = $True
        }
        if ($FLAG){
            $objLabelErrsvr.Visible = $False
        }
                
        if ($FLAG){
        
            $Script:Change | Add-Member -MemberType NoteProperty -Name "Interval" -Value $objServer.Text
            $Script:Change | Add-Member -MemberType NoteProperty -Name "TimeScope" -Value $ObjPriority.Text

            $objForm.Close()
        }
    }

    $Script:Change = New-Object -Type psobject
    $FormSizex = 425
    $FormSizey = 200

    $objForm = New-Object System.Windows.Forms.Form 
    $objForm.Text = "New Change Entry"
    $objForm.Size = New-Object System.Drawing.Size($FormSizex,$FormSizey) 
    $objForm.StartPosition = "CenterScreen"

    $objForm.KeyPreview = $True
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        {$x=$objTextBox.Text;$objForm.Close()}})
    $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {$objForm.Close()}})

    $OKButton = New-Object System.Windows.Forms.Button
    $OKButton.Location = New-Object System.Drawing.Size((($FormSizex/2)-75),($FormSizey - 80))
    $OKButton.Size = New-Object System.Drawing.Size(75,23)
    $OKButton.Text = "OK"
    $OKButton.Add_Click($OKButton_Click)
    $objForm.Controls.Add($OKButton)

    $CancelButton = New-Object System.Windows.Forms.Button
    $CancelButton.Location = New-Object System.Drawing.Size(($FormSizex/2),($FormSizey - 80))
    $CancelButton.Size = New-Object System.Drawing.Size(75,23)
    $CancelButton.Text = "Cancel"
    $CancelButton.Add_Click({$objForm.Close()})
    $objForm.Controls.Add($CancelButton)
    
    $objTitle = New-Object System.Windows.Forms.Label
    $objTitle.Location = New-Object System.Drawing.Size((($FormSizex/2)-90),20) 
    $objTitle.Size = New-Object System.Drawing.Size(($FormSizex/2),40) 
    $objTitle.Text = "Scheduled Task Interval"
    $objTitle.font = New-Object System.Drawing.Font("Microsoft Sans Serif",10,[System.Drawing.FontStyle]::Regular)
    $objForm.Controls.Add($objTitle)

###########################Building Form Elements###################################################
    $Ypos = 60
    $xPos = 25
    $xSize = 60
    $objLabel = New-Object System.Windows.Forms.Label
    $objLabel.Location = New-Object System.Drawing.Size($xPos,$yPos) 
    $objLabel.Size = New-Object System.Drawing.Size(300,20) 
    $objLabel.Text = "Please input the interval between checks"
    $objForm.Controls.Add($objLabel)

    $yPos += 20

    $objServer = New-Object System.Windows.Forms.TextBox 
    $objServer.Location = New-Object System.Drawing.Size($xPos,$yPos) 
    $objServer.Size = New-Object System.Drawing.Size($xSize,25)
    $objForm.Controls.Add($objServer)

    $ObjPriority = New-Object System.Windows.Forms.ComboBox
    $ObjPriority.Location = New-Object System.Drawing.Size(($xPos+$xSize),$yPos) 
    $ObjPriority.Size = New-Object System.Drawing.Size($xSize,25) 
    $ObjPriority.Height = 80

    [void] $ObjPriority.Items.Add("mins")
    [void] $ObjPriority.Items.Add("hours")
    [void] $ObjPriority.Items.Add("days")

    $ObjPriority.SelectedIndex = 0

    $objForm.Controls.Add($ObjPriority)

    $yPos += 20

    $objLabelErrsvr = New-Object System.Windows.Forms.Label
    $objLabelErrsvr.Location = New-Object System.Drawing.Size($xPos,($yPos+3)) 
    $objLabelErrsvr.Size = New-Object System.Drawing.Size(300,20) 
    $objLabelErrsvr.Text = "Please input a valid value"
    $objLabelErrsvr.ForeColor = "Red"
    $objLabelErrsvr.Visible = $FALSE
    $objForm.Controls.Add($objLabelErrsvr)


 #####################################################################################

    $objForm.Topmost = $True

    $objForm.Add_Shown({$objForm.Activate()})
    [void] $objForm.ShowDialog()

    return $Change
}


###############################################################################################################################################
if (Test-Path $FilePathServerList){

    Write-Host "Checking if server list exists" -BackgroundColor White -ForegroundColor Black
    
    [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
    $result = [Microsoft.VisualBasic.Interaction]::MsgBox("ServerList.txt detected. Would you like to rewrite it?", 'YesNo,Question', "Pulse Installation") 
    if ($result -eq "Yes"){
        PopulateServerList $FilePathServerList
    }

}else{
    PopulateServerList $FilePathServerList
}

if (Test-Path $FilePathEmailConfiguration){

    Write-Host "Checking if email configuration exists" -BackgroundColor White -ForegroundColor Black

    [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
    $result = [Microsoft.VisualBasic.Interaction]::MsgBox("EmailConfiguration.csv detected. Would you like to rewrite it?", 'YesNo,Question', "Pulse Installation") 
    if ($result -eq "Yes"){
        PopulateEmailConfiguration $FilePathEmailConfiguration
    }

}else{
    PopulateEmailConfiguration $FilePathEmailConfiguration
}

[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
$result = [Microsoft.VisualBasic.Interaction]::MsgBox("Would you like to create the scheduled task?", 'YesNo,Question', "Pulse Installation") 
if ($result -eq "Yes"){
    CreateScheduledTasks $PulsePS1Path $InstallLog
}

 <#
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')  
$result = [Microsoft.VisualBasic.Interaction]::MsgBox("Would you like to generate individual exclude files for each instance? This is used for fine tuning the installation.", 'YesNo,Question', "Pulse Installation") 
if ($result -eq "Yes"){
    GenerateInstanceExcludeFiles $FilePathExcludeFiles (gc $FilePathServerList)
}



#>